$ErrorActionPreference = 'Stop'
$work = $PSScriptRoot
$collector = 'C:\GZDooMProjects\CaelumArgenteum\build\tools\PresentMon-2.6.0-x64.exe'
$sessionName = 'Caelum318Stagger20261018'
$stopMarker = Join-Path $work 'stop-presentmon.signal'
$recordPath = Join-Path $work 'collector-state.json'
$record = [ordered]@{ started_utc = [DateTime]::UtcNow.ToString('o'); wrapper_pid = $PID; session_name = $sessionName; maximum_seconds = 7200 }
$arguments = @('--process_name','gzdoom.exe','--output_file',('"{0}"' -f (Join-Path $work 'presentmon.csv')),'--no_console_stats','--qpc_time_ms','--session_name',$sessionName,'--timed','7200','--terminate_after_timed')
$process = $null
try {
    $process = Start-Process -FilePath $collector -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $work 'collector-stdout.txt') -RedirectStandardError (Join-Path $work 'collector-stderr.txt')
    $record.collector_pid = $process.Id
    $record | ConvertTo-Json | Set-Content -LiteralPath $recordPath -Encoding UTF8
    while (!$process.WaitForExit(1000)) {
        if (Test-Path -LiteralPath $stopMarker) {
            $stopper = Start-Process -FilePath $collector -ArgumentList @('--session_name',$sessionName,'--terminate_existing_session') -WindowStyle Hidden -PassThru
            if (!$stopper.WaitForExit(10000)) { Stop-Process -Id $stopper.Id }
            if (!$process.WaitForExit(10000)) { Stop-Process -Id $process.Id }
            break
        }
    }
    $record.exit_code = $process.ExitCode
} finally {
    if ($process -and !$process.HasExited) { Stop-Process -Id $process.Id }
    $record.finished_utc = [DateTime]::UtcNow.ToString('o')
    $record | ConvertTo-Json | Set-Content -LiteralPath $recordPath -Encoding UTF8
}
