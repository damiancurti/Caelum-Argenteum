// Observacion privada del viaje real, sin cambiar la presentacion.
class CA353Performance : EventHandler
{
    int Age,StartTic;
    bool SeedReady,Started,Finished;
    CaelumPortSiege Port;
    Array<CaelumCombatActor> Bodies;
    Array<double> Stamps;
    ui double LastFrame;
    ui Array<double> FrameMS,FrameTimes;
    ui Array<int> FrameTics;
    ui bool Flushed;
}
// El paquete anterior carga el save nuevo sin depender de un esquema añadido.
class CA361Live : StaticEventHandler
{
    int Passes,Failures;
    override void NetworkProcess(ConsoleEvent e)
    {
        if(e.Name!="ca361_check")return;
        let user=CaelumPlayer(players[0].mo);let port=CaelumPortSiege.Get();
        if(user==null || port==null || !port.SiegeStarted || port.Attackers.Size()==0)
        {Console.Printf("CA282 FAIL rollback missing saved siege");return;}
        user.CurrentAdrenaline=0;user.UpdateHealthStateEffects();
        if(user.CurrentAdrenaline!=0){Console.Printf("CA282 FAIL rollback still forced");return;}
        Console.Printf("CA282 DONE passes=2 failures=0");
    }
}
