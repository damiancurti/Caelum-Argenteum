| Camera / runtime | Median FPS [run range] | Median p99 ms [run range] | Paired FPS change |
| --- | ---: | ---: | ---: |
| City / control | 39.85 [39.12-48.05] | 79.52 [66.40-81.07] | +0.00% |
| City / variant | 44.12 [39.67-47.25] | 65.42 [65.12-79.70] | +0.20% |
| Front / control | 32.32 [30.81-39.21] | 119.63 [110.85-124.31] | -0.00% |
| Front / variant | 32.93 [31.16-39.59] | 123.30 [109.90-131.36] | +2.95% |
