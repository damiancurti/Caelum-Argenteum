$ErrorActionPreference='Stop'
$work=$PSScriptRoot
$collector='C:\GZDooMProjects\CaelumArgenteum\build\tools\PresentMon-2.6.0-x64.exe'
$last=0
$deadline=[DateTime]::UtcNow.AddHours(2)
$principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
@{pid=$PID;started_utc=[DateTime]::UtcNow.ToString('o');administrator=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)} | ConvertTo-Json | Set-Content (Join-Path $work 'supervisor.json') -Encoding UTF8
while ([DateTime]::UtcNow -lt $deadline -and !(Test-Path -LiteralPath (Join-Path $work 'release-collector.signal'))) {
    $requestPath=Join-Path $work 'capture-request.json'
    if (!(Test-Path -LiteralPath $requestPath)) {Start-Sleep -Milliseconds 250;continue}
    $request=Get-Content -Raw -LiteralPath $requestPath | ConvertFrom-Json
    if ($request.sequence -le $last) {Start-Sleep -Milliseconds 250;continue}
    $name=[string]$request.name
    if ($name -notmatch '^[a-z0-9-]+$') {throw 'Invalid capture label'}
    $last=[int]$request.sequence
    $sessionName="Caelum353Retry03-$name"
    $record=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');wrapper_pid=$PID;session_name=$sessionName;maximum_seconds=3600;buffer_size=16384}
    $args=@('--process_name','gzdoom.exe','--output_file',('"{0}"' -f (Join-Path $work "$name.csv")), '--set_circular_buffer_size','16384','--no_console_stats','--qpc_time_ms','--session_name',$sessionName,'--timed','3600','--terminate_after_timed')
    $process=$null
    try {
        $process=Start-Process -FilePath $collector -ArgumentList $args -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $work "$name-stdout.txt") -RedirectStandardError (Join-Path $work "$name-stderr.txt")
        $record.collector_pid=$process.Id
        $record | ConvertTo-Json | Set-Content (Join-Path $work "$name-state.json") -Encoding UTF8
        while (!$process.WaitForExit(500)) {
            if ((Test-Path -LiteralPath (Join-Path $work "stop-$name.signal")) -or (Test-Path -LiteralPath (Join-Path $work 'release-collector.signal'))) {
                $stopper=Start-Process -FilePath $collector -ArgumentList @('--session_name',$sessionName,'--terminate_existing_session') -WindowStyle Hidden -PassThru
                if (!$stopper.WaitForExit(10000)) {Stop-Process -Id $stopper.Id}
                if (!$process.WaitForExit(10000)) {Stop-Process -Id $process.Id}
                break
            }
        }
        $record.exit_code=$process.ExitCode
    } finally {
        if ($process -and !$process.HasExited) {Stop-Process -Id $process.Id}
        $record.finished_utc=[DateTime]::UtcNow.ToString('o')
        $record | ConvertTo-Json | Set-Content (Join-Path $work "$name-state.json") -Encoding UTF8
    }
}
@{finished_utc=[DateTime]::UtcNow.ToString('o');pid=$PID} | ConvertTo-Json | Set-Content (Join-Path $work 'supervisor-finished.json') -Encoding UTF8
