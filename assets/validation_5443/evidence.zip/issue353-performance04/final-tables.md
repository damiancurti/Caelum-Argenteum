| Camera / runtime | Median FPS [run range] | Median p99 ms [run range] | Paired FPS change |
| --- | ---: | ---: | ---: |
| City / control | 34.40 [29.56-40.50] | 90.58 [79.36-106.05] | +0.00% |
| City / variant | 46.80 [37.81-49.47] | 71.26 [65.98-80.96] | +26.16% |
| Front / control | 20.58 [12.44-32.48] | 174.18 [143.93-256.71] | +0.00% |
| Front / variant | 32.20 [29.78-39.42] | 120.95 [113.56-136.69] | +70.70% |
