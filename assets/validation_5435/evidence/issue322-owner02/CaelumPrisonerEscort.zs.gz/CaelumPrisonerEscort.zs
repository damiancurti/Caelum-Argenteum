// Una sola autoridad de marcha. Las poses no buscan blancos ni ejecutan Chase.
// El recorrido se limita al alcance de recuperación ya aprobado y usa consultas
// locales del motor; jamás enumera la población completa del mapa.
class CaelumPrisonerEscort : Object play
{
    const REVISION=1;
    int Revision;
    CaelumPlayer Leader;
    Array<Vector3> Trail;
    CaelumEscortNavigation Path;
    double Acceleration;
    int RecoveryRetry;
    bool Controlled;

    void Observe(CaelumAnchoredResident body,CaelumPlayer leader)
    {
        if(Revision<REVISION || Leader!=leader)
        {
            Revision=REVISION;Leader=leader;Trail.Clear();Path=null;
            Acceleration=0;Controlled=false;RecoveryRetry=0;
        }
        if(leader==null)return;
        double spacing=Max(1.0,Min(body.Radius,leader.Radius)/2);
        if(Trail.Size()==0 || (leader.Pos-Trail[Trail.Size()-1]).Length()>=spacing)
        {
            Trail.Push(leader.Pos);
            int capacity=int(Ceil(CaelumConstants.PRISONER_FOLLOW_TELEPORT_DISTANCE/spacing))+1;
            if(Trail.Size()>capacity){Trail.Delete(0);Path=null;}
        }
    }

    bool Immobilized(CaelumAnchoredResident body)
    {
        return body.ForcedSleepTics>0 || body.CombatLucidityPhysicalStunRemaining>0
            || CaelumBolas.Restrained(body) || CaelumTelekinesisRules.Held(body);
    }

    void Pose(CaelumAnchoredResident body,bool moving)
    {
        State pose=body.FindState(moving?"EscortFollow":"EscortIdle");
        if(!body.InStateSequence(body.CurState,pose))body.SetState(pose);
    }

    void Hold(CaelumAnchoredResident body,bool showPose=true)
    {
        body.Vel.X=0;body.Vel.Y=0;Acceleration=0;Controlled=true;
        CaelumThermalMotion.SetVelocity(body);
        if(showPose)Pose(body,false);
    }

    void Yield(CaelumAnchoredResident body)
    {
        if(Controlled){body.Vel.X=0;body.Vel.Y=0;}
        Controlled=false;Acceleration=0;
    }

    double WalkingSpeed(CaelumAnchoredResident body)
    {
        // Misma marcha base, curva, carga, Aire y penalizaciones del jugador.
        // Los NPC no tienen hambre/sed/sueño metabólico: no crear esos recursos.
        int agility=body.CombatAgility+body.GetCombatArmorAttributeBonus(CaelumConstants.ATTRIBUTE_AGILITY);
        int strength=body.CombatStrength+body.GetCombatArmorAttributeBonus(CaelumConstants.ATTRIBUTE_STRENGTH);
        double capacity=body.Mass*CaelumGrowthRules.Multiplier(strength,2);
        double load=capacity>0?body.GetAttackCarriedWeight()/capacity:0;
        double air=body.MaximumCombatAir>0?body.CurrentCombatAir/body.MaximumCombatAir:0;
        double airFactor=air<=CaelumConstants.AIR_BREATHLESS_THRESHOLD?CaelumConstants.BREATHLESS_PERFORMANCE_MULTIPLIER
            :air<=CaelumConstants.AIR_TIRED_THRESHOLD?CaelumConstants.TIRED_PERFORMANCE_MULTIPLIER:1;
        return CaelumConstants.GZDOOM_BASE_MAX_WALK_SPEED*CaelumGrowthRules.Multiplier(agility,2)
            *(1-Clamp(load,0.0,1.0))*airFactor*body.CombatHealthPerformanceMultiplier
            *CaelumThermalEffects.Speed(body)*(body.ElementalStatus!=null?body.ElementalStatus.GetMovementMultiplier():1);
    }

    // Sólo para trayectos cortos de igual nivel. Los desniveles y esquinas
    // conservan su ruta local y el control de suelo del motor en cada paso.
    bool ClearSegment(CaelumAnchoredResident body,Vector3 goal)
    {
        vector2 delta=goal.XY-body.Pos.XY;
        double distance=delta.Length();
        if(distance<=CaelumConstants.PRISONER_FOLLOW_DISTANCE)return true;
        delta*=Max(0.0,distance-CaelumConstants.PRISONER_FOLLOW_DISTANCE)/distance;
        int steps=Max(1,int(Ceil(delta.Length()/Max(1.0,body.Radius))));
        for(int i=1;i<=steps;i++)
        {
            FCheckPosition fit;
            if(!body.CheckPosition(body.Pos.XY+delta*i/steps,false,fit)
                || fit.ceilingz-fit.floorz<body.Height
                || abs(fit.floorz-body.FloorZ)>body.MaxStepHeight
                || fit.floorz-fit.dropoffz>body.MaxDropOffHeight)return false;
        }
        return true;
    }

    void Follow(CaelumAnchoredResident body,CaelumPlayer leader)
    {
        if(Immobilized(body)) {Yield(body);return;}
        if(body.Distance2D(leader)>CaelumConstants.PRISONER_FOLLOW_TELEPORT_DISTANCE)
        {
            if(level.time>=RecoveryRetry)
            {
                RecoveryRetry=level.time+TICRATE;
                if(Recover(body,leader)){Trail.Clear();Observe(body,leader);Path=null;}
            }
        }
        double speed=WalkingSpeed(body);
        if(speed<=0){Hold(body);return;}
        double gap=body.Distance2D(leader)-CaelumConstants.PRISONER_FOLLOW_DISTANCE;
        if(gap<=0 && body.CheckSight(leader)){Hold(body);Trail.Clear();Path=null;return;}
        if(Trail.Size()==0)Trail.Push(leader.Pos);
        // El atajo es geométrico, no un único rayo de visión. Evita rodear una
        // ruta vieja cuando el jugador invierte el sentido en un pasillo libre.
        if(level.time%CaelumConstants.PRISONER_WALK_STATE_TICS==0 && ClearSegment(body,leader.Pos))
        {Trail.Clear();Trail.Push(leader.Pos);Path=null;}
        while(Trail.Size()>1 && (Trail[0].XY-body.Pos.XY).Length()<=speed)
        {Trail.Delete(0);Path=null;}
        Vector3 goal=Trail.Size()==1?leader.Pos:Trail[0];
        vector2 destination=goal.XY;
        if(Path!=null)destination=Path.Next(body,goal);
        vector2 delta=destination-body.Pos.XY;
        double distance=delta.Length();
        if(distance<=0.001){Hold(body);return;}
        double mass=Max(1.0,body.Mass+body.GetAttackCarriedWeight());
        double duration=CaelumConstants.MOVEMENT_ACCELERATION_SECONDS*mass/CaelumConstants.MOVEMENT_ACCELERATION_REFERENCE_KG;
        Acceleration=Min(1.0,Acceleration+1/(duration*TICRATE));
        double step=Min(distance,speed*Acceleration);
        if(Trail.Size()==1 && Path==null && gap>0)step=Min(step,gap);
        vector2 point=body.Pos.XY+delta/distance*step;
        if(!body.CheckMove(point,0))
        {
            if(Path==null)Path=new("CaelumEscortNavigation");
            if(level.time>=Path.RetryTic)Path.Build(body,goal);
            Hold(body);return;
        }
        body.Angle=VectorAngle(delta.X,delta.Y);
        body.Vel.X=delta.X/distance*step;body.Vel.Y=delta.Y/distance*step;
        CaelumThermalMotion.SetVelocity(body);Controlled=true;Pose(body,true);
    }

    bool Recover(CaelumAnchoredResident body,CaelumPlayer leader)
    {
        if(leader==null || Immobilized(body))return false;
        // Los doce candidatos y su margen proceden del recuperador anterior.
        // El radio del jugador ahora también forma parte de la separación.
        double spacing=body.Radius+leader.Radius+24;
        for(int attempt=0;attempt<12;attempt++)
        {
            double angle=leader.Angle+180+(attempt%8)*45;
            double distance=spacing*(1+attempt/8);
            vector3 point=(leader.Pos.X+Cos(angle)*distance,leader.Pos.Y+Sin(angle)*distance,leader.Pos.Z);
            let probe=Actor.Spawn("CaelumSummoningProbe",point,NO_REPLACE);
            if(probe==null)continue;
            probe.A_SetSize(body.Radius,body.Height);probe.FindFloorCeiling();
            bool free=probe.TestMobjLocation() && probe.Pos.Z>=probe.FloorZ
                && probe.Pos.Z+body.Height<=probe.CeilingZ;
            // La consulta nativa del teletransporte omite sólidos no disparables.
            // TestMobjLocation y la separación explícita los comprueban antes.
            let nearby=BlockThingsIterator.Create(probe,body.Radius);
            while(free && nearby.Next())
            {
                let other=nearby.thing;
                if(other==null || other==probe || other==body || !other.bSolid)continue;
                double reach=body.Radius+other.Radius;
                if(abs(point.X-other.Pos.X)<reach && abs(point.Y-other.Pos.Y)<reach
                    && point.Z<other.Pos.Z+other.Height && point.Z+body.Height>other.Pos.Z)free=false;
            }
            probe.Destroy();
            if(free && body.TeleportMove(point,false))
            {body.Vel=(0,0,0);body.ClearInterpolation();Acceleration=0;return true;}
        }
        return false;
    }
}
