# MAP01 — Prueba social de Argento, 4.33.0f

La especificación narrativa es `MAP01_HISTORIA_Y_PROGRAMACION_v1_0.txt`,
especialmente su sección 17. La elección posterior del autor para esta
implementación reemplaza los ejemplos de curvas incompatibles del capítulo
10 de la documentación anterior: Persuasión y Emoción Tipo 4; Labia Tipo 2.

| Interlocutor | Habilidad y atributo | Requisito | Alternativa |
| --- | --- | --- | --- |
| Rulo | Emoción / Empatía, Tipo 4 | Dificultad 120; luego respuesta respetuosa | Consejo de Argento tras fallar |
| Ronnie | Labia / Elocuencia, Tipo 2 | Labia >= 1 | Aprender el plan de Argento después de visitar a Ronnie |
| Caella | Persuasión / Carisma, Tipo 4 | Dificultad 120 | Consejo tras fallar y aceptación de condiciones |

Se reutilizan las funciones existentes de `CaelumDerivedStats`:

- Tipo 4: `100 + 2 × atributo × (atributo + 1) / 101`.
- Tipo 2: `atributo × (atributo + 1) / 101`.
- Probabilidad: redondear `habilidad × 100 / dificultad` al entero más próximo
  y limitar a 0..100. Reputación neutra porque estos residentes no tienen una
  facción asignada. No se toma la reputación de la Gendarmería.
- En 1..99%, dado uniforme de 1 a 100 y éxito cuando `dado <= probabilidad`.
  En 100% no se consume RNG; se registra éxito automático. En 0%, fallo.

Elocuencia 9 da Labia 90/101, insuficiente; Elocuencia 10 da 110/101,
suficiente. Empatía/Carisma 3 dan 84% frente a dificultad 120; nivel 100 da
éxito automático. No se modifica la curva general de otras habilidades.

Los índices estables de CheckOnceKey son Rulo=0 y Caella=2; Ronnie=1 no tira.
`MainM00SocialResult`, `Roll` y `Chance` registran el primer intento.
`MainM00ResidentMet` y `MainM00SocialAdvice` registran conocimiento nuevo.
Todo pertenece al Inventory persistente del personaje; los NPC y tokens USDF
no son la autoridad. Una visita repetida no suma ni vuelve a consumir RNG.

La ayuda de los residentes se representa con tres flags ya reservados y el
contador se deriva de ellos. Sólo Argento puede cerrar, sólo con 3/3 y sólo
desde etapa 30. El cierre lleva exactamente a 35, deja la misión activa y
habilita la siguiente conversación de Caella. No activa el tutorial mágico,
concede objetos ni completa la misión principal.

En UI se muestran probabilidades, la opción bloqueada de Ronnie y el estado
emocional privado [Preocupado]. El Diario muestra el objetivo actual y su
contador sin añadir seguimiento permanente al HUD. Los diálogos permanecen
en USDF nativo y el cierre Q hereda el menú ya aceptado.

El progreso cooperativo compartido sigue pendiente. Esta entrega conserva
estado por personaje y no convierte el conocimiento privado en información
de todos los jugadores.
