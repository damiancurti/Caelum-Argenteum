# Caelum Argenteum 4.0 — Implementation status


## MAP01 Argento social branch 4.33.0f

**Implemented; isolated GZDoom 4.14.2 state and dialogue checks passed;
author acceptance and save/load traversal pending.** The author accepted all
4.33.0e tests, closing the south lift-shaft correction.

Argento now offers the authored social task. Rulo requires understanding and
a respectful answer; Ronnie requires a concrete plan; Caella requires
persuasion or informed safety conditions. Failed checks persist and lead to
Argento's advice, opening deterministic alternatives. The Journal follows
0/3 through 3/3, requires returning to Argento, and then points to Caella at
exact phase 35. The magic tutorial at phase 40 remains a later slice.

The author's balance decision for this patch uses Type 4 for Emotion and
Persuasion, difficulty 120 for both checks, and Type 2 Labia with a minimum
of 1 for Ronnie's direct option. The option remains visible and gray below
the threshold and is independently guarded in play scope.

The isolated engine probe passed 1189 assertions over the actual persistent
class and action handlers, including six visit orders and four random-outcome
combinations. Native UI checks confirmed the gray/blocked Ronnie option,
private Rulo feedback, and consent through a real USDF action. Testing used a
reconstructed source tree with two unrelated missing-dependency fixtures;
it does not certify the unavailable complete 4.32.0o runtime. No fixtures are
included in the production source delta. See `docs/VALIDACION_4_33_0f.txt`.

All nine changed/new runtime files are listed with base and output hashes in
`PATCH_MANIFEST_4_33_0f.json`. The accepted MAP01 WAD is unchanged and is not
included again. Equipment artwork, weapons and commerce are outside this delta.

## MAP01 south lift-shaft texture correction 4.33.0e

**Accepted: the author confirmed all focused tests passed before 4.33.0f.** The author accepted every V4.33.0d test except the
invisible interior wall near `(1922,338,0)`, facing 270 degrees.

The south edge at `Y=272`, `X=1875..1959` reuses an older boundary whose floors
were initially both at zero. Its lift-facing sidedef 1637 retained an empty
lower texture, unlike the newly created west and east shaft edges. Lowering
the platform exposes that untextured surface. V4.33.0e assigns `CACVROCK` to
that lower texture, matching the adjacent shaft walls.

The runtime delta is exactly one sidedef property in `src/maps/MAP01.wad`.
Vertices, linedefs, sectors, Things, upper/middle textures, native lift calls
and all gameplay scripts remain byte-equivalent or semantically identical to
0d as applicable. The upper entrance remains open when both floors are at zero.

The original file-level checks remain in `docs/VALIDACION_4_33_0e.txt`.
The author has now accepted the visual and return checks. The next implemented
slice is Argento in 4.33.0f; later mission phases remain on the roadmap.

## Physical MAP01 lift, corrected secret facade and equipment art 4.33.0d

**Author validation passed except for the south interior lift-shaft texture,
corrected in V4.33.0e.** The author accepted the other V4.33.0c tests and
requested the corrections below.

- Both Unknown Voice answer pages now expose exactly one native Continue
  goodbye; the explicit duplicate choices are removed.
- The four residents and tangible Palomo return after 100 MU instead of 500.
  Their accepted coordinates and straight running return remain unchanged.
- A native mansion-textured facade at X=1842 runs parallel to the east wall.
  Its southern 96-MU section is pass-through; a second hidden midtexture crosses
  the 119-MU-wide passage at Y=-87. The rest of the facade blocks at ground level.
- The 84×88-MU platform centered at (1917,316) is a native sector floor. It
  descends continuously from 0 to -384 at 2 MU/tic, waits 175 tics, then rises.
  Native Use specials recall it from below. No player SetOrigin or map change
  exists in the production transport code.
- The lower tunnel joins a contiguous 1024×800-MU cave with three trees, one
  normal copper vein, one normal tin vein and one size-adaptive T1 sword.
  Fire harvests trees; AltFire pierces the veins. Normal vein classes retain
  their registered 3D models, fixing the invisible 0c subclasses. The hatchet,
  iron, coal and local blunt-harvesting exception are removed from this cave.
- New 3D slabs retain the original ground surfaces and roof tags above the
  excavation. Existing bottom-pegged railings receive height compensation so
  they remain at their accepted upper-floor heights. Cave rock reuses the
  project's granite texture.
- All 99 supplied PNGs are imported byte-for-byte: 49 T2, 49 T3 and the
  corrected base giant gauntlets. The existing tier resolver uses their same
  paths; they are equipment icons, not first-person animation frames.

An isolated runtime probe observed platform/player heights -70, -210, -384
and finally 0 at fixed X/Y. It also walked the player through the lower tunnel
into the cave at floor -384 / ceiling -64. A rendered GZDoom screenshot
confirmed that the copper vein is visible. The probe is excluded from the
delivered runtime. Narrative advancement still ends at the prepared Argento
phase; this correction does not implement the next dialogue branch.

## MAP01 resident placement and secret survival cave 4.33.0c

**Historical prototype; author feedback is corrected by V4.33.0d. All other
focused author tests passed.**

The complete V4.33.0b matrix was accepted by the author. This revision changes
only the reported dialogue duplication and the physical MAP01 preparation for
the already reserved phases 30–60; it does not advance the quest beyond the
prepared Argento state.

The Unknown Voice opening now exposes two explicit questions and one native
USDF goodbye labelled **[Guardar silencio.]**. The redundant explicit silence
choice was removed, so the visible option occurs exactly once while preserving
Q/Escape closure and the same persistent `UNKNOWN_VOICE_HEARD` fact.

MAP01 now contains one anchored story instance of each resident:

| Resident | Position | Angle |
| --- | ---: | ---: |
| Argento | `(1040, -378, 136)` | 90° |
| Caella | `(-290, -378, 136)` | 90° |
| Rulo | `(-290, 378, 136)` | 270° |
| Ronnie | `(1036, 378, 136)` | 270° |

These instances remain solid and tangible, but are friendly, invulnerable and
do not acquire targets. A displacement below 500 MU is tolerated. At 500 MU or
more they use their running animation and return in a straight line to the
exact stored spawn point and angle. Debug summons without `args[0]=1` retain
their accepted combat behavior.

The east side of MAP01 adds two mansion-textured, double-sided false wall
panels at `(1842,-360,0)` and `(1944,-87,0)`. They are visible but have no
collision. The solid back wall is centered at `(1842,366,0)`. An 84×88-MU
platform centered at `(1917,316,0)` connects, without a map or character
restart, to a closed lower cave and a return platform. Its footprint remains
inside sector 92 and exceeds the maximum XL character diameter of 42.67 MU.

The cave contains three renewable young trees, tutorial iron/coal/copper/tin
veins and exactly one T1 hatchet pickup. That pickup resolves its size from the
character at collection time, so XS through XL characters can equip the same
physical tool. Fire preserves the global slashing rule for trees; AltFire uses
the hatchet's blunt side on these four tutorial veins only. Ordinary world
veins continue to require piercing damage.

## Canonical MAP01 prologue foundation 4.33.0b

**Implemented; cumulative source reconstruction and deterministic audits passed;
the complete focused author matrix passed; accepted and extended physically by
V4.33.0c**

The supplied `MAP01_HISTORIA_Y_PROGRAMACION_v1_0.txt` is now part of the
project documentation and supersedes the test-only Palomo adventure. Quest ID
0 is renamed internally to `QUEST_MAIN_M00_THE_FOOL`, while its persistent
index and the accepted 32×8 storage layout remain stable. The full MAP01
sequence has named states from 00 through 100 and 64 reserved factual flags;
only phases 00–20 advance in this subpatch.

After character confirmation in MAP01, a stateless EventHandler begins
**Donde despiertan los perdidos**, applies a short black wake-up fade and opens
the Unknown Voice through GZDoom's native USDF conversation system. The voice
is represented only by a temporary invisible technical speaker. Hearing its
opening line is recorded once, independently of the optional answer or Q exit,
then reveals the anchored Palomo with a discreet alpha fade.

Palomo's foyer conversation replaces the old gift/shop tree. Four optional
questions are exhausted through persistent knowledge flags; mentioning the
woman's voice records Palomo's hallucination answer and exposes the prescribed
“The good ones never do” follow-up. Asking for guidance completes the initial
1/1 objective and advances exactly from phase 20 to the prepared Argento phase
30. An immediate second activation uses an ambient reminder; once Palomo leaves
every active field of view he disappears and a load reconstructs him as hidden.
No production route from Palomo opens commerce, negotiates a discount or grants
the Magic Box.

The accepted merchant implementation remains unchanged as reusable/debug
infrastructure for a future merchant NPC. `GrantMagicBoxFromPalomo()` is now
independent from quest advancement so an isolated grant cannot skip narrative
states. New characters remain without the Box; migrated development saves keep
their existing Box and contents but restart only the discarded quest record.
Faction and reputation behavior is unchanged.

The Journal shows the canonical title, localized current phase, broad milestone
objective and Palomo's derived hidden/foyer/hidden/upstairs placement. Visible
MAP01 text preserves the mystery and does not identify the location, the
speaker or the protagonist's prior fate.

## Persistent quests, reputation and faction registry 4.33.0a

**Implemented; cumulative source, deterministic audits and the complete focused
GZDoom 4.14.2 author matrix passed; accepted and superseded narratively by
V4.33.0b**

V4.33 begins with a deliberately content-light persistent foundation. The
travelling `CaelumPersistentCharacterState` now reserves 32 stable quest slots
with eight objective counters each. Every quest stores discovery/state, an
integer stage and objective known/progress/target fields. Only one production
identifier is currently defined: accepting Palomo's already-authored adventure
records an active quest, stage `Adventure accepted` and the completed factual
objective `Receive the Magic Box from Palomo`. Refusal still creates no
irreversible failure. Saves that already own the box migrate that fact into the
same quest record; new characters remain undiscovered until they accept.

The Journal's two former placeholder pages now read authoritative player
snapshots. Missions shows no entries before acceptance, then displays the
Palomo record and its 1/1 objective. Reputation lists four stable technical
domains—Gendarmeria, settlements, caravans and political actors—with separate
membership booleans and reputation integers clamped to -1,000..1,000. All begin
unaffiliated at zero. No political names, rewards, ranks, hostility thresholds
or starting allegiances were invented.

`CaelumFactionRules` provides an O(1) relation lookup: identity is friendly and
every unauthored cross-domain relation remains neutral. It performs no actor
iteration, line-of-sight test, pathing call or per-combatant global search. Five
zero-capacity, auto-activating debug actions allow Gendarmeria membership,
+25/-50 reputation and reset to be tested through `give`; none has a DoomEdNum
or remains in inventory, and normal gameplay has no provisional reputation
mutation.

Palomo's current location is no longer represented as an independent mutable
quest fact: `ResolvePalomoPlacement()` derives it from the quest record. The
only authorized result in 4.33.0a is his accepted mansion starting post, so the
physical MAP01 actor and 500-MU return-home behavior remain unchanged. Adding a
second map/stage destination and executing the one-instance move are explicitly
reserved for a later V4.33 revision after those coordinates and narrative
conditions are authored. Merchant stock, wallet and negotiated discount remain
in the same per-character record and therefore cannot reset when that move is
implemented.

## Author-accepted V4.32 closure 4.32.0o

**All focused GZDoom 4.14.2 tests passed; V4.32 is closed.**

The author confirmed rest, every attack frame, repeated strikes, Block and
equipment switching after the alpha-bounds pivot correction. The modular
Domingo sword/hand/shield implementation is now the accepted reference for a
later expansion to all weapons; that expansion is not a V4.33 blocker.

## Alpha-bounds compensated grip pivots 4.32.0o

**Implemented; deterministic source, alpha-geometry and package audits passed;
focused GZDoom 4.14.2 author validation passed**

The V4.32.0n screenshot exposed one duplicated-hand attack frame. `RHND` and
`RFNG` are complementary layers of the same right hand, but their rotations
separated because the previous pivot conversion used full transparent PNG
canvas dimensions while GZDoom evaluated the percentages against each
texture's different visible bounds.

The already accepted blade pivot remains `(0.55625,0.83)`. The palm pivot is
recalibrated to `(0.2091403904,0.2550892857)` and the foreground thumb/finger
pivot to `(1.0895833333,0.4095)`. With each layer's alpha box, `grAb` and the
blade's (-22,-32) translation included, all three resolve exactly to screen
point `(56.64375,84.57)`. Their 0→25-degree attack delta can therefore no
longer split the hand into two silhouettes.

No sprite, path point, timing, angle or gameplay source changed. The focused
visual check in `PRUEBAS_4_32_0o.txt` passed and closed V4.32; already approved
systems stay closed.

## Raised idle sword, complete thumb and synchronized grip 4.32.0n

**Height and complete-thumb assets retained; full-canvas pivot conversion
superseded by V4.32.0o**

The author accepted V4.32.0m except for three details in the right-hand rig:
the idle sword was slightly low, the foreground finger layer covered only part
of the thumb, and the hand translated with the sword but did not share its
changing rotation.

The sword is raised four logical units in every state. It now rests at
(260,0), and every attack point retains a constant (-22,-32) translational
registration to the already accepted hand path. `RFNGA0` gains exactly 443
visible pixels using the unchanged underlying `RHNDA0` thumb colours; 413 also
retain exact alpha and 30 use reduced alpha only at the antialiased boundary.
No existing foreground pixel is altered. `RFNGB0` is the exact (+1,+1)
counterpart.

Layers 25, 30 and 40 now use local pivots that resolve to the same screen-space
grip point (-4,102). The blade retains the absolute
18→21→24→31→38→43→39→31→24→18-degree sequence, while palm and foreground
thumb apply its 0→3→6→13→20→25→21→13→6→0-degree delta from idle. Position and
rotation therefore remain registered throughout the strike without changing
the approved idle hand pose, attack curve or straight-line return.

Held Block is unchanged from V4.32.0m: shield and its left hand remain on
layers 10/20, and the lower-right layers 25/30/40 are hidden. No gameplay,
equipment, persistence, HUD, map, dialogue, economy or crafting source changed.

## Correct Block hand and quadrupled blade adjustment 4.32.0m

**Block correction and horizontal blade registration retained; idle height,
thumb mask and attack-rig synchronization superseded by V4.32.0n**

The V4.32.0l screenshots showed that it removed the wrong Block hand. The
correct held composition is shield layer 10 plus its registered left-hand
layer 20, both at (160,100). V4.32.0m restores `CA_SwordLeftBlock` and clears
the lower-right main-hand assembly—layers 25, 30 and 40—on both normal Block
entry and equipment resynchronization. The obsolete right-hand Block states
are removed. Leaving Block reconstructs all normal main-hand layers.

V4.32.0l moved the blade four logical units left. This revision moves it an
additional sixteen units left, four times that previous adjustment. The blade
now rests at (260,4), twenty units left of its V4.32.0k position, while the
approved palm/fingers remain at (282,32). Every attack blade point receives
the same additional -16 X delta, producing a constant (-22,-28) blade-to-hand
registration.

All hand positions, Y coordinates, eight-tic timing, outgoing curve,
straight-line return and the
18→21→24→31→38→43→39→31→24→18-degree rotation sequence are unchanged. No
sprite bytes or gameplay systems changed.

## Single-hand Block and finger-covered sword grip 4.32.0l

**Blade adjustment retained as the first increment; Block-hand selection and
final blade registration superseded by V4.32.0m**

The author accepted V4.32.0k's complete attack motion and identified two final
composition details. Held Block showed a redundant hand at the lower-left
edge, and the sword needed a slight leftward registration change so the
foreground fingers cover more of its handle.

Layer 20 is now explicitly cleared on every entry into Block, including the
equipment-resynchronization path, and the unused `CA_SwordLeftBlock` state is
removed. The accepted shield, remaining hand, H(3)→I(-1) hold and (160,100)
Block framing are unchanged. Leaving Block restores the normal left-hand layer
when a valid shield remains equipped.

The normal blade and every attack blade point move exactly four logical units
left. Palm/finger positions, all Y coordinates, the eight-tic timing, the
five-point outgoing curve, straight return and
18→21→24→31→38→43→39→31→24→18-degree rotation sequence remain unchanged.
The blade-to-hand offset is therefore (-6,-28), keeping the accepted motion
while placing the handle farther beneath the foreground finger layer.

No sprite bytes, gameplay source, damage, Air, durability, Block rules,
equipment, HUD, persistence, Palomo, Magic Box, economy, crafting, dialogue or
map source changed.

## Coupled idle shield, registered grip and authored attack path 4.32.0k

**Attack path accepted; Block layering and blade registration superseded by
V4.32.0l**

The V4.32.0j screenshot exposed one misunderstood mark and one registration
problem. The idle shield was supposed to follow its left hand into the lower
blue zone, while the right hand and sword handle had separate blue targets.
The author also supplied a black reference path for the attack and requested a
straight-line return after impact, while explicitly accepting the changing
sword rotation.

Idle shield and left-hand layers now share (82,45). Held Block remains
unchanged at (160,100). The normal right palm/fingers rest at (282,32), while
the sword rests at (280,4); relative to V4.32.0j this moves the hand slightly
left/down and raises the handle by 24 logical units into its marked target.
Layer depth is unchanged: palm remains behind the blade and fingers remain in
front of its handle.

The eight-tic A-frame attack now samples five points along the marked curve:
(300,15), (318,-4), (287,-1), (236,11) and impact at (201,21). It then uses
three nearly collinear positions—(228,25), (255,28) and (275,31)—before rest
at (282,32). This produces the requested straight-line return instead of
retracing the outgoing arc. The blade keeps a constant (-2,-28) registered
offset from the palm path.

Rotation continues throughout the animation at
18→21→24→31→38→43→39→31→24→18 degrees. Thus the accepted visual endpoints
remain approximately 79 degrees at rest and 104 at impact. No gameplay timing,
damage, Air, durability, Block, equipment, HUD, persistence or map source
changed.

## Marked-zone hand placement and corrected Block hand 4.32.0j

**Block-hand orientation retained; idle placement and attack path superseded
by V4.32.0k**

The author accepted the V4.32.0i shield and identified two remaining visual
corrections. The horizontal hand visible beneath held Block was inverted, and
the normal hands/sword still occupied the red-marked positions rather than the
two marked blue zones. V4.32.0j changes only the sword selector's visual
offsets and the six H/I sublayers needed to reverse that Block hand.

Shield layer 10 remains exactly at (105,0) when idle and (160,100) while
blocking; `DSHDI0` is byte-identical to V4.32.0i. Left-hand layer 20 now has an
independent normal offset (82,45), so it can move down and left without moving
the shield. The complete right rig now rests at (288,28). Its accepted motion
deltas remain unchanged, producing (302,36), (260,10) and (276,21) during
retraction, extension and recovery.

`RHNDH0`, `RHNDI0`, `DSWDH0`, `DSWDI0`, `RFNGH0` and `RFNGI0` are each the
exact horizontal mirror of the corresponding V4.32.0f pixels. Mirroring the
three registered layers together makes the Block forearm enter from the left
without disconnecting palm, transitional blade or foreground fingers. Canvas,
RGBA encoding and `grAb (160,32)` remain unchanged.

The accepted 18/24/43/31-degree sword rotations, static H(3)→I(-1) Block,
orthographic 125% shield, panoramic arm, conditional shield visibility and all
gameplay systems remain unchanged.

## Raised variable-angle sword and orthographic Block 4.32.0i

**Shield and angle targets accepted; remaining hand presentation superseded by
V4.32.0j**

The author accepted the V4.32.0h mechanics and attack motion, then identified
three remaining presentation defects: the sword rig began too low, its strike
needed a small angular change from roughly 75–80 degrees at rest to 95–110
degrees at impact, and the held shield had neither the requested camera
perspective nor the correct vertical placement and proximity. V4.32.0i changes
only `CaelumSwordSelectorWeapon` and the held-I shield/left-hand artwork.

The complete right-hand rig now rests at Y=-18. Its existing translation deltas
are preserved at (174,-10), (132,-36) and (148,-25), while the absolute
grip-pivot rotation progresses through 24, 43 and 31 degrees before returning
to 18. Given the supplied blade's approximately 61-degree baked angle, those
states render near 85, 104, 92 and 79 degrees respectively. The same A artwork
still supplies all three attack phases, so the strike remains an
advance/retract motion and cannot expose the rejected E/F/G overturn.

Held Block remains a static H(3)→I(-1) sequence. I now places the shield layers
at X=160, Y=100. The shield reverse was redrawn in an orthographic,
straight-on camera view, then widened in source space to compensate Doom's 1.2
pixel aspect. Its 450×300 RGBA export uses `grAb (225,48)` and a 293×244
visible box: the 244-pixel displayed diameter is 125.1% of V4.32.0h's
195-pixel height, while 293/244 restores a circular screen silhouette. The
registered left-hand layer has a 213×169 visible box, the raster-equivalent
125% of 170×135. This makes the shield genuinely perpendicular, 25% closer and
low enough to leave the reference horizon unobstructed.

Idle shield X=105, conditional equipment visibility, the accepted extended
480×240 right arm, all layer depths and every combat/gameplay path remain
unchanged.

## State-specific Domingo first-person correction 4.32.0h

**Mechanics and motion accepted; remaining presentation superseded by
V4.32.0i**

The author's V4.32.0g test accepted every regression case but rejected its
visual composition. V4.32.0h therefore remains a presentation-only correction
and leaves the approved combat, Block, Air, durability, persistence, economy,
crafting, dialogue, HUD and map sources unchanged.

Idle and attack now place only shield layers 10/20 at X=105 while the right
hand, blade and finger layers stay based at X=160. Block returns the shield to
X=160. Its H raise lasts three tics and its enlarged, frontal I pose then holds
indefinitely instead of looping H/I. The I shield and left arm share an exact
118% transform and registered `grAb (160,48)` canvases.

The sword has one absolute 30-degree rotation about its grip, producing the
requested near-vertical pose. Attack no longer consumes the rotating E/F/G
art: the same A pose moves through (174,8), (132,-18) and (148,-7) for
retraction, extension and recovery, then returns to (160,0). Because blade,
right arm and foreground fingers receive each offset together, their depth and
grip remain registered and the blade angle cannot change during the strike.

`RHNDA0` and `RHNDB0` now use 480×240 RGBA canvases with
`grAb (160,72)`. Their 960×480 source extends the armored sleeve through the
panoramic edge, preventing the former 320-pixel canvas boundary from appearing
when the hand moves forward. The original fist and occlusion layer remain in
their accepted positions.

## Centered first-person rig and right-leaning sword 4.32.0g

**Mechanics/regressions accepted; visual proposal rejected and superseded by
V4.32.0h**

The author accepted every non-framing test from 4.32.0f. This follow-up changes
only the two reported visual defects. All five modular PSprite layers now use
one X=160, Y=0 placement helper, moving the registered 320-pixel rig exactly
half a logical canvas to the right. The layers remain attached to the main
weapon PSprite, so its accepted vertical raise/lower path and bob are inherited
unchanged.

`DSWDA0`, `DSWDB0`, `DSWDD0` and `DSWDG0` are exact horizontal pixel mirrors
around per-frame grip pivots. This keeps each hilt seated at the same point
between the unchanged palm and finger layers while making the idle blade point
up-right; D and G prevent a left-facing discontinuity at the end of selection
and attack recovery. C, E, F, H and I remain byte-identical to 4.32.0f, as do
all hands, shield art, timings and gameplay sources outside the sword selector.

The audit decodes the PNG scanlines with only the Python standard library and
proves each of the four changed images is the exact expected grip-pivot mirror,
retains 320×200 8-bit RGBA and preserves `grAb (160,32)`. It also proves that
the runtime delta from 4.32.0f is exactly the selector plus those four images,
and that removing the shared placement helper leaves the previous sword class
semantically unchanged.

## Real sword first-person layers and clarified travel semantics 4.32.0f

**Author test pass completed for dialogue, persistence, equipment, conditional
shield and combat regressions; its two framing defects are superseded by
4.32.0g.**

The revised Domingo delivery is connected to the real
`CaelumSwordSelectorWeapon`; the console-only `CA_DomingoFPSwordShield` test
weapon and its independent punch are removed. Fire and AltFire call the same
authoritative player attack paths as before, Zoom still toggles real Block,
and inherited Reload/User inputs remain unchanged. The HUD suppresses only its
two provisional first-person drawings while this real sword selector is ready.

Five native PSprite layers now provide actual depth: shield at 10, its left
hand at 20, right forearm/palm at 25, sword at 30 and a new right-finger
occlusion layer at 40. Nine `RFNG` frames were extracted from the corrected
right-hand art, so the blade and grip pass in front of the palm but behind the
curled fingers in every A–I pose. The 45 supplied revision-2 PNGs replace the
previous delivery byte for byte; together with the nine derived finger PNGs,
all runtime frames are 320×200 RGBA with the common `(160,32)` `grAb` origin.

The shield and its dedicated left hand are synchronized every tic with
`HasActiveBlockSource()`. They are absent without an equipped, compatible,
unbroken shield, appear when one becomes valid, and disappear immediately when
it ceases to be valid. Block H→I holds for the full authoritative Block state;
E→G starts only when a real sword attack actually begins its cooldown.

The reported Magic Box travel failure was also reclassified after reproduction:
the `map MAP02` console command starts a new game/player, whereas the map's
normal Exit and `changemap MAP02` preserve the accepted travelling record.
The redundant schema-2 three-source reconciliation from 4.32.0e is removed;
`CaelumPersistentCharacterState` again remains the single persistent source,
with the live flag and USDF marker derived from it. Schema-2 saves retain their
stored boolean because version 2 already satisfies the original version-1
initialization guard.

## Native Palomo dialogue, persuasion and tier icons 4.32.0d

**Implemented; source, dialogue, pricing and supplied-asset audits passed;
focused GZDoom 4.14.2 author acceptance pending**

Palomo now enters GZDoom's native USDF conversation system instead of switching
directly between a gift and the custom merchant panel. Before ownership, he
introduces himself as the pigeon who owns the mansion and asks whether the
player wants an adventure. Yes grants the Magic Box; No opens the requested
confirmation, whose reconsideration also grants it and whose definitive Yes
ends with “Qué lástima”. A later interaction reoffers the undecided branch, so
refusing does not create an unauthorized permanent quest failure.

After ownership, the native menu offers Trade and Talk. A third reply is shown
only when raw Eloquence is strictly greater than 50 and disappears permanently
after success. It displays difficulty 50 and the current chance calculated
from the accepted Dialogue Skill formula
`Eloquence × (Eloquence + 1) / 101`. Dialogue Skill at or above 50 succeeds
automatically; otherwise the chance is `floor(skill / 50 × 100)`. A successful
check is stored per character and changes Palomo's lot margins to 140% charged
and 60% paid, preserving ceiling/floor rounding. Failure has no invented
persistent penalty and may be attempted again.

`CAPALOMO` is loaded with the native `GameInfo.AddDialogues` path on every map.
The interaction synchronizes invisible native-inventory requirement markers,
temporarily assigns conversation ID 43200 to the actor and calls
`Actor.StartConversation`. This keeps USDF's native replies, item conditions,
page links and give-item transactions while retaining per-player gift and
discount authority. It also means V4.33 can move or recreate Palomo without
copying the dialogue or resetting merchant state.

The supplied art replaces 23 corrected T1/base PNGs and adds 49 T2 plus 49 T3
PNGs. One `CaelumIconResolver` maps all 20 weapons, 16 armor variants, four
shields, four amulets and five seals, and is used by equipment selection,
crafting preview, jewelry inventory icons and the active-weapon display. The
complete runtime icon tree matches the supplier checksums and contains 255 PNGs.

## Accepted Palomo interaction corrections 4.32.0c

**Author test pass completed: every focused interaction, Sell filter,
return-home and regression case succeeded.**

The merchant navigation now uses Left/Right to move bidirectionally through
lots 1/5/20/50/100 and Space/X to toggle Buy/Sell. Sell mode builds a compact
authoritative view containing only catalog products with at least one
unreserved player unit and enough Palomo cash for a one-unit purchase; an
explicit empty state replaces irrelevant rows.

The shared folklore interaction latch now belongs to the player and remains
armed while the merchant panel is open. Closing with Q, Tab, Escape or B cannot
reopen Palomo under the crosshair during the same physical Use press; a new
interaction requires closing and then releasing Use. The anchored MAP01
instance also records its spawn as home: displacement below 500 MU is tolerated,
while displacement at or above 500 MU makes Palomo return at the actor's normal
running speed and stop at the original post. Quest-stage relocation remains a
V4.33 responsibility.

## Palomo merchant and persistent Magic Box acquisition 4.32.0b

**Author test pass completed: startup, gift, persistence, prices, physical
transactions and regressions succeeded. Four interaction details are
superseded by the focused V4.32.0c correction above.**

New characters begin without the Magic Box: it contributes zero weight, has
zero slots and rejects every direct or automatic storage route. Palomo is now
an anchored NPC 64 map units in front of the MAP01 player-1 start. The shared
`CaelumInteractiveFolkloreActor` contract edge-triggers `Use`, so the first
interaction grants the box once and a later interaction opens commerce. The
accepted 10 kg structure and aggregate `floor(raw weight / maximum slots)`
rule begin only after that reward. Confirmed pre-4.32.0b profiles migrate as
owners so previously boxed inventory remains accessible.

Palomo trades food, water, wood, raw copper and raw tin in both directions.
The player selects lots of 1/5/20/50/100; the existing 150% charge and 50%
payment apply once to the whole lot. Transactions consume the player's real
fifteen currency classes, accept mixed metal/denominations and materialize
canonical physical change. Stock, player ownership, both cash balances,
crafting reservations, final carry load and Magic Box slots are checked before
commit. The initial test balance is 20 food, 20 water, 100 wood, 50 raw copper,
50 raw tin and a 200-copper merchant wallet.

Merchant stock/cash is stored in each character's persistent inventory record,
not in the MAP01 actor. This keeps server authority isolated per player and is
the compatibility seam for V4.33: Palomo may later move or respawn according
to quest stage without resetting or duplicating the trade state. The current
actor remains stationary because `arg0 = 1` marks the narrative merchant
anchor; unanchored debug summons retain their former wandering behavior.

The Inventory category uses the silver coin image, while copper/silver/gold
totals retain their own icons. The supplied 64×64 RGBA Magic Box sprite appears
next to its status and is dimmed before acquisition. Trade input and rendering
reuse `CaelumJournalOverlay`; the authoritative mutations remain play-scope
network events and the player cannot move while the merchant panel is open.

## ZScript startup-scope compatibility 4.32.0a-r4

**Accepted by the author after the complete cumulative GZDoom 4.14.2 test
pass; deterministic source and package audit passed**

GZDoom 4.14.2 rejected r3 during `LoadActors` because
`CaelumEconomyRules.GetInventoryUnitBaseValue`, a function compiled in data
scope, called `play` methods on live currency, consumable and special-item
instances. R4 explicitly declares the three inventory-dependent pricing
helpers as `play static`, including the stack wrapper and equipment helper, and
adds a build-audit requirement for those declarations.

This is a startup-only compatibility correction. Economy values, recipes,
merchant margins, currency, Magic Box behavior, UI, maps, resources, crafting,
equipment and save data remain identical to r3. The r4 package supersedes r3.

## Permanent proportional-weight Magic Box 4.32.0a-r3

**Accepted by the author in r4 after the complete cumulative GZDoom 4.14.2
test pass; deterministic source and package audit passed**

The Magic Box remains a permanent character capability rather than a new
inventory actor. It cannot be dropped, sold, destroyed or stored, and its
structure always contributes 10.000 kg to carried load, including while empty.
Its Intelligence-derived maximum slot count is the weight divisor: all real
weights inside are summed, divided once by the current maximum slots and then
rounded downward to the game's 0.001-kg precision. The base 10 kg is never
divided. Stacks still consume one slot regardless of Amount, but every unit
contributes before the aggregate division.

Load transitions are prospective. New pickups, additions to boxed stacks,
retrieval, direct equipping, processing/component output, final-equipment
assembly and disassembly compare the complete resulting load against carrying
capacity. Retrieval subtracts the item's former reduced share before adding its
full personal weight. Splitting weight across piles cannot exploit per-stack
rounding because only the total box content is rounded.

The existing storage whitelist is unchanged. Native keys, arrows and bolts
remain outside the box; all previously admitted equipment and stacks retain
their behavior. If Intelligence lowers capacity beneath current occupancy,
contents remain intact and the reduced weight is recalculated with the new
divisor. Further deposits are blocked until enough slots are freed. The Journal
Inventory line now displays used/maximum slots plus total box weight, while the
selected item continues to display its unreduced real weight. Exact rules and
examples are recorded in `docs/MAGIC_BOX.md`.

## Physical currency and recursive economy foundation 4.32.0a-r2

**Accepted by the author in r4 after the complete cumulative GZDoom 4.14.2
test pass; deterministic source and package audit passed**

Copper, silver and gold now exist as fifteen physical, stackable native
inventory items: each metal has nominal denominations 1, 5, 20, 50 and 100.
One silver unit equals 200 copper units and one gold unit equals 200 silver
units (40,000 copper). Every physical coin weighs 0.001 kg regardless of metal
or denomination. Coins cannot be crafted, minted or smelted by the player; the
face-value ladder is deliberately independent from material prices. The five
denominations of a metal reuse its accepted 64x64 icon and world sprite and
remain distinguishable through localized inventory names and pickup messages.

The Journal Currency filter enumerates every denomination and shows, beside
Load and Magic Box, the total copper-equivalent balance plus aggregate physical
coin counts for copper, silver and gold. Money stored in the Magic Box remains
owned and visible in the total. The former zero-weight storage contract in this
r2 historical entry is superseded by the proportional rule in 4.32.0a-r3.

The authored raw-material anchors now set wood to 2; plant fiber and cow hide
to 3; coal, copper and tin to 5; iron to 7; silver to 100; every current raw gem
(opal, topaz, emerald, sapphire and ruby) to 500; and gold to 1,000 copper per
0.001 kg unit. Food and water rations receive authorized per-item values of 4
and 6. Natural-resource hardness and abundance still control extraction but no
longer overwrite these monetary choices. Processing uses each real recipe at
100% material efficiency and adds 25%. Components then use processed-material
values and add 25%, 50% or 100% according to their cumulative T1/T2/T3 station
network. Final equipment values its manufactured components and existing
precious-metal details, then applies the same tier markup once for assembly.

Merchant helpers pay 50% of the complete lot value, rounded down to whole
copper, and charge 150%, rounded up. The actual NPC interaction, merchant
stock and transfer transaction remain the next V4.32 increment; this revision
does not invent dialogue or place merchants. Consumables other than food and
water, ammunition, keys and key items intentionally remain unpriced until they
receive an authorized recipe or base value. No crafting quantity, efficiency,
operation time, repair, disassembly, resource or map changes in this revision.

## Potable-water constant restoration 4.31.0j

**Accepted by the author after the complete cumulative GZDoom test pass;
deterministic reference, source and package audit passed**

Version 4.31.0i rebuilt its constants file from an incomplete source snapshot
and omitted `POTABLE_WATER_THIRST_RECOVERY_RATIO_PER_SECOND`, although the
player code retained the potable-water thirst call introduced in 4.31.0h.
GZDoom therefore rejected ZScript before entering a map. Version 4.31.0j
restores the exact `0.01` ratio: one percentage point of Thirst per second while
fully submerged in a sector explicitly marked as potable.

The corrective runtime delta contains only `CaelumConstants.zs`. A new audit
enumerates every `CaelumConstants.*` reference across the complete PK3 and
rejects the build if any referenced member is undeclared. It also requires the
candidate constant catalogue to equal the 4.31.0i catalogue plus exactly the
restored potable-water member. Crafting efficiency, recursive repair, UI,
maps, models, sounds, recipes, resources and save data remain byte-identical
to 4.31.0i.

## Independent operation efficiency and recursive repair 4.31.0i

**Implemented; deterministic source and package audit passed; focused
GZDoom 4.14.2 author acceptance pending**

The efficiency selected for a recipe node now multiplies only that node's own
work. Its 25%/50%/100% material rule and 1x/10x/100x time factors remain
unchanged, but no factor is inherited by descendants. Material waste still
propagates naturally: a less efficient parent requests more child units and a
less efficient child requests more raw input. The theoretical tree and the
current-inventory direct plan share the same rule:

```text
OperationTime(node) = AdjustedInputUnits(node)
                    * ComplexityTics(node)
                    * EfficiencyFactor(node)
                    / 35
                    * 100 / DexterityType1Percent

FullTime = Sum(OperationTime(executed node))
```

This supersedes the inherited branch multiplication introduced in 4.30.0i.
Changing a handle or blade component can still alter descendant quantities,
but it can no longer multiply the independently selected duration of every
subrecipe below it.

Repair now uses the same recursive material resolver as direct weapon
creation. It reserves finished components already owned, derives only the
missing portion from known recipes and raw materials, adds each required
intermediate operation once to the repair duration and consumes the complete
reservation atomically on success. Explicit cancellation continues to release
the reservation without spending material or changing durability. A failed
repair reports a repair-specific material error instead of the misleading
generic fabrication error.

The Journal's crafting help is split into two readable lines and explicitly
shows `B` for material/component batches and `C` for cancelling an active task.
Final equipment remains a single output unless its header says otherwise.
The former root label `x3000`, which actually meant three thousand material
units rather than three thousand objects, now displays both units and kilograms
as `material used: 3000 u (3.000 kg)`. No map, model, sound, inventory item,
recipe quantity, resource source or save schema changes in this patch.

## Potable-water hydration and combat timeout correction 4.31.0h

**Implemented; deterministic source, map and package audit passed; focused
GZDoom 4.14.2 author acceptance pending**

Complete submersion now restores Thirst at a net rate of one percentage point
per second only when the current sector carries the UDMF
`user_ca_potable_water` marker. The seventeen target sectors of MAP01's pool
receive that marker. The existing WaterLevel-3 breathing rule, progressive Air
cost, drowning damage and three-second respiratory-debt recovery are unchanged.
This explicit marker prevents future saltwater, polluted water or other liquid
volumes from becoming drinkable merely because they support swimming.

Combat still lasts thirty seconds after the latest confirmed action. The
countdown now advances before checking whether CurrentAdrenaline is positive;
therefore an attack that grants no Adrenaline, or a reserve that reaches zero,
can no longer freeze the combat state and indefinitely block crafting. Once the
countdown reaches zero, positive Adrenaline continues to decay at the existing
ten points per second.

`CaelumMaterialPickup` now overrides the native pickup-message method and
combines the localized material name with the exact incoming stack amount.
The underlying item class, type, tier, weight, stacking and crafting ownership
remain unchanged. Tin continues to originate from `CaelumVeinTin`,
`CaelumVeinTin2` and `CaelumVeinTin3` (DoomEdNums 18509–18511). MAP01 changes
only by adding the seventeen potable flags; all vertices, lines, sides,
sectors, Things and every other runtime asset are preserved.

## Explicit Young names and resource corrections 4.31.0g

**Implemented; deterministic source, geometry and package audit passed;
focused GZDoom 4.14.2 author acceptance pending**

The 48 pre-adult actors belonging to the sixteen enlarged tree species now
expose `Young`, `Young2` and `Young3` editor/class names. Their historical
class names remain valid aliases and their existing DoomEdNums are reassigned
without changing mesh, scale, collision or mass. Together with the five age
families introduced in 4.31.0f, the editor therefore presents 63 Adult and 63
Young tree actors across all twenty-one species.

Successful harvesting no longer calls the attack-thrust path for rooted
sources. Trees still release wood and wear the melee weapon, but only a source
whose `IsEnvironmentMovable()` contract returns true can receive push. Mineral
deposits retain their previous mass-dependent movement. Coal variant 3, silver
variant 1 and gold variant 2 omit only the three long ore bands that protruded
outside their host rock; their nine irregular inclusions, actor data, collision,
capacity and yield are unchanged. Every other mineral mesh remains byte-identical.

Crafting-station help once again exposes `F` repair and `D` dismantle, and the
crafting page displays equipment-action rejection messages when no task starts.
Repair remains an operation on the exact object selected in Inventory: it must
be damaged and unequipped, with the complete recipe station network and scaled
materials available. MAP01, MAP02, resource balance and regeneration do not
change. The shipped capacity catalogue records the exact mass-derived maximums:
117,000–669,509,000 wood units and 287,540–35,946,000 mineral units; scenic
rocks remain at zero.

## Renewable trees and compact mineral veins 4.31.0f

**Implemented; deterministic source, geometry and package audit passed;
focused GZDoom 4.14.2 author acceptance pending**

The author accepted all fourteen 4.31.0e checks. Version 4.31.0f turns every
tree family into a persistent renewable wood source and introduces eleven
distinct mineral deposits: iron, mineral coal, copper, tin, silver, gold,
opal, topaz, sapphire, ruby and emerald. Each mineral has three deterministic
3D outcrop variants, for 33 new actors, 33 OBJ meshes, eleven 256x256 original
materials and eleven transparent model anchors. No mineral node is placed in
MAP01 or MAP02; Buenos Aires therefore retains the agreed mining scarcity.

Extraction is connected only to the authoritative physical melee trace.
Trees accept slashing damage and have hardness 2.5; deposits accept piercing
damage. The released amount uses `strike damage × (1 - hardness/10) ×
abundance`. Fractions are stored on the source rather than rerolled or lost,
so rare deposits remain deterministic. Ranged attacks, magic, thrown
javelins, blunt attacks and the five generic scenic rock families never
produce materials. A successful resource strike still wears the equipped
weapon and can transmit physical push to a movable deposit, but it does not
create combat activity or Adrenaline.

Maximum recoverable units derive from the physical cylinder mass and the
resource concentration; the mapper can replace that maximum by supplying
whole kilograms in actor argument 4. Since one material unit weighs 0.001 kg,
the conversion remains dimensionally consistent. Every loaded partially
depleted source recovers exactly 0.1% of its own maximum over the canonical
24-hour game day (24 x 180 real seconds), in staggered one-second updates.
Source capacity, remaining units and fractional carry are ordinary serialized
actor fields and therefore survive save/load.

Cardon, churqui, chanar, espinillo and ceibo now expose their approved current
sizes under `Adult`, `Adult2` and `Adult3` names. Their previous class names
remain valid compatibility aliases, while existing DoomEdNums point at the
new adult names without changing appearance or collision. Fifteen new
`Young` actors reuse the same three branch meshes at exactly half scale and
use DoomEdNums 18460-18474. Mineral nodes use 18500-18532. All 78 previously
approved environmental OBJ files and both maps remain byte-identical.

## Adult vegetation and environmental impact bodies 4.31.0e

**Implemented; deterministic structural and package audit passed; focused
GZDoom 4.14.2 author acceptance pending**

The author accepted all twelve 4.31.0d tests. Version 4.31.0e preserves every
existing environmental mesh, texture, class scale and DoomEdNum, then adds 48
adult tree actors for sixteen species. Names use `Adult`, `Adult2` and
`Adult3`; their target sizes remain 100/75/125% around species-specific adult
heights from 8 to 32 metres. Cardón, churqui, chañar, espinillo and ceibo keep
only their original three variants because those already occupy useful real
size ranges. Adult actors use DoomEdNums 18412–18459 and reuse the existing
three OBJ meshes of each species through `MODELDEF`; no visual file is copied
or regenerated.

All 186 environmental actors now store a rounded kilogram mass derived from
their collision cylinder using the project scale of 32 MU per metre and a
nominal density for the represented rock or species. The generated range is
449–303,009,143 kg and remains inside the signed 32-bit actor-mass range.
Trees are rooted static targets: player and combat-actor collision resolves
through the same `ResolveStatic` path as a wall, applies the normal Caelum
impact damage curve and never changes tree velocity. Rocks are dynamic targets:
`ResolveBodies` transfers action and reaction according to both masses. Use
interaction requires `PhysicalPushMultiplier >= mass/100` and scales received
thrust inversely with mass. Passive callbacks from a moving rock are accepted
by player/NPC receivers so a rock can initiate the collision.

The generator produces 75 rock actors, 111 tree actors, 186 unique class/model
records and 186 unique environmental DoomEdNums: 26 historical base numbers
plus 160 generated assignments in 18300–18459. Automated checks
confirm exact preservation of all 78 OBJ and 26 environmental PNG assets,
unchanged MAP01/MAP02 bytes, valid model paths, finite scales, adult height
ratios, cylinder masses and stable DoomEdNums 18041–18070/18300–18459.

Harvesting remains disabled. Only-melee extraction, cutting trees, piercing
mineral deposits, hardness/rarity/depth rules, new menas, algae and marine
biomes are now an explicit Version 5 track. Its fixed decisions are recorded
in `V5_RESOURCES_AND_MARINE_BIOMES.md`; no provisional drops or probabilities
enter the 4.31.0e runtime.

## Environmental variants, south hill and progressive drowning 4.31.0d

**Implemented; exact GZDoom 4.14.2 compile, MAP01 load and drowning audit
passed; accepted by the author after all twelve focused tests**

The regional library now contains 63 tree actors and 75 rock actors. Every one
of the twenty-one accepted tree species retains its original class and adds a
75% variant suffixed `2` plus a 125% variant suffixed `3`; their branch or
crown distribution changes deterministically without changing the species'
basic silhouette or material. The five rock forms now combine five nominal
size tiers (0.5×, 1×, 2×, 5× and 20×) with the same three 75/100/125% visual
variants. All variants share the material of their source form.

The runtime therefore exposes 138 solid environmental actors backed by 78 OBJ
meshes and 44,976 faces. Historical base DoomEdNums 18041–18045 and
18050–18070 remain unchanged; the 112 new actors use 18300–18411. The sauce's
hanging branches now originate continuously at the trunk, and the ciprés,
guindo and pehuén trunks terminate inside their crowns instead of projecting
through the top. Collision scales with each actor, but remains GZDoom's simple
rock/trunk cylinder rather than triangle-accurate OBJ collision.

Once Caelum Air reaches zero, continuous submersion deals one pulse per second
equal to 1% of the character's current maximum-health capacity. Each following
second adds 0.1 percentage points until the pulse reaches 10%; surfacing or
otherwise breathing resets the progression. Damage keeps the established
environmental path: it ignores armor and does not award Adrenaline or begin
combat. The developer command `ca_debug_empty_air` makes the first pulses
testable without waiting for the complete Air reserve to drain.

MAP01 adds a native UDMF floor-slope prototype centred at `(600, -1100)` in an
empty part of the south lawn. Eight continuous sloped sectors rise from z=0 to
a 48-MU-high, roughly 192-MU-wide flat top inside a 640-MU octagonal footprint.
The original MAP01 text blocks remain byte-identical and the hill appends 16
vertices, 24 linedefs, 48 sidedefs and 9 sectors without new Things. MAP02 is
byte-identical to 4.31.0c. Reproducibility, actor/model/material references,
editor-number uniqueness, finite mesh geometry, map references, sector
ownership and all slope-edge heights passed automated structural checks.

The complete 3,896-file candidate also compiled and loaded MAP01 without a
map, MODELDEF or ZScript warning in exact GZDoom 4.14.2. A temporary runtime
audit measured the rounded damage sequence `18/20/21/178` at 1.0/1.1/1.2/10%
for a 1,780-health profile and confirmed that breathing resets the next pulse
to 18. The audit helper is not included in the release.

## Progressive underwater breathing and Argentine environment set 4.31.0c

**Implemented and internally validated in exact GZDoom 4.14.2; focused author
timing and visual-scale validation pending**

The author accepted all twelve 4.31.0b swimming, drowning, stash, persistence
and regression checks. Version 4.31.0c replaces the provisional fixed
underwater cost with a continuous no-breath ramp. A full submersion starts at
5 base Air per second, adds 1 base Air per second after each complete
continuous second and stops increasing at 20. Body mass and carried load still
multiply the resulting rate through the one existing
`AirConsumptionMultiplier`; Resilience still expands capacity rather than
creating a second breath resource.

The HUD and debug view display `sin oxígeno` for the entire interval in which
the character's head is fully submerged. Performance penalties remain derived
from the actual Air ratio, so the label itself does not add a hidden debuff.
Every unit actually removed by this state is recorded as respiratory debt.
When the head leaves the water, that debt alone is returned evenly over
exactly 105 tics (three seconds), without consuming Hunger or Thirst. Running,
jumping, blocking, attacks and any Air missing before submersion are not
included in the fast repayment; normal eight-minute recovery resumes
afterwards. Re-entering the water pauses the repayment and preserves its debt.

The first regional environment library adds five distinct solid rock models
and twenty-one solid vegetation models: three for desert, jungle, tundra,
mountain, plains, coast and city. The silhouettes, OBJ meshes and 26 runtime
materials are original project assets; a generated source atlas and the
deterministic Pillow-based model generator are included outside the runtime.
All objects are summonable and have DoomEdNums 18041–18045 and 18050–18070.
Their collision follows the rock core or trunk, not the full tree crown.

This increment deliberately does not assign harvesting, yields, tools,
depletion states or regeneration. The actors are physical/editor-ready visual
prototypes until those author-controlled values are supplied. Automated
checks passed the 5/6/20 rate steps, exact cumulative loss, no-oxygen state,
three-second debt-only repayment, unchanged Hunger/Thirst and all 26
MODELDEF/material/collision paths. MAP01 and MAP02 remain byte-identical to
4.31.0b.

## Shared underwater Air and first 3D stash prototype 4.31.0b

**Accepted by the author after all twelve focused swimming, stash and
regression checks**

Fully submerged swimming now spends the authoritative Caelum `CurrentAir`
resource at 50 base units per second multiplied by the existing body-mass and
carried-load `AirConsumptionMultiplier`. With mass 100, no carried load and
Resilience 0, the 1,000-unit reserve lasts 20 seconds; Resilience 100 raises
the reserve to 3,000 and therefore lasts 60 seconds under the same conditions.
Air cannot regenerate while `WaterLevel == 3` and resumes its existing
eight-minute recovery route as soon as the player's head leaves the water.

The parallel native GZDoom breath timer is reset silently every tic, so it can
no longer damage the player while the Caelum meter still has Air. Once
`CurrentAir` reaches zero, Caelum preserves the native drowning cadence: one
damage pulse every 32 tics, starting at 2 and increasing with elapsed
breathless time. Drowning updates health, pain and cast interruption but is
explicitly environmental: it neither starts combat nor grants adrenaline.

Entering the pool from the air no longer leaves movement acceleration at zero.
Ordinary airborne jumps still preserve momentum without adding acceleration,
while `WaterLevel > 0` and native flight remain controllable media. The exact
A/B audit measured acceleration `0` before touching bottom on 4.31.0a and a
progression from `0.055464` to `0.99` before bottom on 4.31.0b.

The first original 3D stash prototype is present without third-party or Doom
assets. Its closed/open/locked OBJ meshes contain 242/254/266 low-poly faces
and use four generated project textures for wood, iron, interior and the
visible lock. One solid authoritative `CaelumStashChest` actor owns state and
interaction; a non-solid visual helper displays exactly one static mesh. The
locked subclass uses LOCKDEFS 201 with the existing reusable
`CaelumSilverKey`. A failed interaction shows a stash-specific localized
message; a successful one permanently unlocks the actor, opens it and leaves
the key in personal inventory.

The prototype deliberately has no contents, capacity or ownership service and
is not placed permanently in MAP01. It can be tested with
`summon CaelumStashChest`, `summon CaelumLockedStashChest` and
`give CaelumSilverKey`. MAP01 remains byte-identical to accepted 4.31.0a.

Exact-engine automated checks passed for: 50-unit rate including the existing
multiplier, suppression of premature native damage, two progressive drowning
pulses, zero drowning adrenaline, recovery after surfacing, OBJ/material load,
all three visual states, solid collision, rejection without a key, successful
unlock and reusable-key retention. The model generator is deterministic and
ships as a development helper; installing/running the patch requires no
Python.

## Rear mansion pool and V4.31 world-source direction 4.31.0a

**Pool implemented and validated in exact GZDoom 4.14.2; focused author
visual/traversal acceptance pending; resource nodes and stashes remain design
only**

MAP01 now has a formal pool behind the eastern/rear façade. Its water footprint
is exactly 1,280×1,440 MU (`x=2200..3480`, `y=-720..720`), the main basin floor
is z=-256 and the water surface is z=0. A 96-MU terrace surrounds a raised
32-MU stone coping. A centered 512-MU-wide entrance uses sixteen 32-MU treads
whose floors descend in 16-MU increments from z=-8 to z=-248, ending at the
deep basin without an impassable rise.

The water is a translucent, fogged `Sector_Set3DFloor` type-2 volume targeting
all seventeen basin/stair sectors through tag 940. The new `CAPOOL01` 256×256
flat is an original project asset derived from the color language of the
author-supplied `CMPW01`; it is mirror-tiled at its four edges and registered
as liquid terrain. An attempted `ANIMDEFS` warp was rejected after the exact
engine control test isolated an early-exit regression to that one directive;
the accepted surface is static while swimming, translucency and underwater
fog remain active.

The map grows from `(1419, 1983, 3544, 618, 322)` to
`(1469, 2049, 3672, 638, 322)`. All original vertex, linedef, sidedef, sector
and Thing blocks remain byte-identical; the 322 Things and all accepted mansion
railings are unchanged. There are no orphan sectors, invalid references,
zero-length/coincident lines or mismatched bilateral flags. The final MAP01
SHA-256 is
`815f2ed0cd6f52fb03e63eaab3f8b8db560fc9b96c4fbe63a87b1e94e7ef8e60`.

An exact-engine smoke run loaded MAP01 without map/resource warnings. A
runtime audit resolved `CAPOOL01` as 256×256 and measured `WaterLevel=3` at the
basin floor with `floorz=-256`; four exterior/underwater captures confirmed
the rim, stairs, bottom and water volume. The remaining gate is the author's
Windows/Doom II walk, especially entry/exit over the first step and visual
scale from the rear doors.

V4.31's resource direction is now fixed at the architecture level: natural
sources and stashes use semirealistic CC0 3D models, while harvested/dropped
inventory objects retain their existing sprites. Sources enter an available
model state, spawn authoritative sprite pickups when used, then enter a
depleted model state until their saved respawn time. Hides instead originate
from authored animal/monster death tables. Chest ownership, locks, capacity,
refill behavior, node yields, required tools and respawn intervals still need
author values before implementation; no provisional balance was added here.

## Audio package 05 and V4.30 acceptance 4.30.0j

**V4.30 completely accepted by the author, including package-05 sound tests**

The author confirmed the complete 4.30.0i result: both corrected balcony
routes, railing heights, menu typography/sounds, all eleven earlier crafting
checks and the cumulative branch-time relation behave correctly. V4.30's
craft → use → deteriorate → repair/disassemble → recover-materials milestone
is therefore accepted. No 4.30.0j file changes those mechanics, MAP01, MAP02,
textures or interface code.

Package 05 adds 14 OGG Vorbis resources at 48 kHz to the runtime library and
registers 14 direct logical names plus the random
`caelum/weather/thunder` alias. They cover crowd, river/coast, localized fire,
fountain, blacksmith, sewer water, four rain intensities, wind and three
thunder variants. Their loop state, attenuation, volume and map placement are
deliberately left to the future environmental/weather emitters rather than
being invented by this asset patch.

Ten license-compatible but unassigned package-05 sounds are retained under
`assets/audio_stock/pack05/`, outside `src` and therefore outside the PK3. Two
additional files with unresolved third-party provenance are omitted entirely.
The runtime build now contains 71 OGG effects/ambiences plus two MP3 music
tracks. Including the external reserve, the project has 83 approved audio
files (82 unique contents). `docs/INVENTARIO_AUDIO.md` enumerates every file
and separates current automatic events, registered destinations, stock and
music. Credits for package 05 ship in
`src/licenses/AUDIO_PACK_05_CREDITS.md`.

The author subsequently completed the focused GZDoom 4.14.2 listening matrix:
the 14 direct names, randomized thunder alias and all loop candidates passed
without an unknown-sound warning or audible seam. V4.30 is therefore closed;
4.30.0j is the accepted baseline for V4.31.

## Focused railing traversal and branch-weighted crafting 4.30.0i

**Implemented, audited and accepted by the author on Windows/GZDoom**

**Historical note:** its inherited branch-time equation is superseded by
4.31.0i after the author isolated repeated multipliers in deep component trees.
All railing work and the 25%/50%/100% material/time values remain valid.

The author's three traversal observations are applied directly to existing
MAP01 linedefs. The 96-MU first-floor railing at `y=-383, x=1209..1305` is
removed. At the eastern second-floor stair, the obstructing route
`x=1697, y=-128..64` is removed and the protected edge becomes
`x=1689, y=-320..-64`. The missing western edge is filled at
`x=-569, y=-92..92`. The result has 41 first-floor and 82 second-floor railing
linedefs, spanning 7,364 and 6,476 MU respectively. All bases remain exactly
at z=136 or z=264. Vertex, linedef, sidedef, sector and Thing counts remain
`(1419, 1983, 3544, 618, 322)`; no sector is orphaned. MAP01 SHA-256 is
`dc5eb73f7b876d5c70b9b2ae7862ac21c617b2c10ef879d508b89c096281a36e`.

Crafting retains independent 25%/50%/100% choices, material waste and
1×/10×/100× factors. The time of a recursive branch is now evaluated as:

```text
BranchTime(node) = EfficiencyFactor(node)
                 * (OwnMaterialTime(node) + Sum(BranchTime(child)))
```

Consequently, the final weapon's factor also covers every component and
refining step that it requires from raw materials; a selected child factor is
then accumulated inside that branch. The current-inventory route omits child
work for components already owned. Using the author's rounded dagger readings
as a regression fixture changes the full-from-raw preview from
`270.0 / 155.0 / 177.5 s` to approximately
`270.0 / 1350.2 / 6761.0 s` when only the weapon layer changes from
25% to 50% to 100%. This closes the reported inversion while preserving the
actual material quantities and Type-1 Dexterity scaling.

## Railing height, 25/50/100 crafting and menu legibility 4.30.0h

**Implemented; superseded cumulatively by 4.30.0i; texture-resource audit,
MAP01 topology/railing-height audit and crafting formula/source audit
completed; author passed the complete 11-point Windows/Doom II matrix**

The mansion environment now uses the author-supplied v2 package as one
canonical 58-PNG set. The previous 85-file collection is not mixed into the
new folder. `TEXTURES` registers every supplied exterior wall, stone floor,
interior wall, wood floor, terrain, stair, door, gate, railing, carpet,
pool/fountain wall, stable, terrace and detail resource through the project's
Windows-safe `graphics/caelum/textures/mansion` path. Historical MAP01 names
that the v2 package retires resolve only through explicit v2-based
compatibility composites; no retired PNG remains in the complete PK3.

MAP01 places an iron railing derived from supplied `CMRL02` on existing balcony
boundary linedefs. Its logical module is 32×48 MU. Three one-pixel-offset
layers preserve the supplied image while keeping its fine bars visible under
world-texture filtering. V4.30.0g removes every provisional 4.30.0f railing
and snaps the author's 23 supplied viewpoints to the actual inner balcony
edges. The first-floor route covers 42 linedefs/7,460 MU and the second-floor
route covers 76 linedefs/6,228 MU. The western central opening and eastern
stair access stay open. V4.30.0h compensates `offsety_mid` for the composite's
2.583333 vertical texture scale: GZDoom now resolves every first-floor base to
z=136 and every second-floor base to z=264 instead of dividing the intended
world displacement by the texture scale. No vertex, sector, Thing or navigable
floor was added or removed: MAP01 remains `(1419, 1983, 3544, 618, 322)` and
now has SHA-256
`aef653d161697746883ddd5d74c71ac1bac35ba01191e3325b28c3e7f1a8c578`.

Inventory text now uses `CaelumMono`, the same physically doubled monospaced
face used by the HUD, so its character spacing no longer collapses relative to
the surrounding interface. Inventory movement/filter events play
`caelum/ui/menu_move`; accepted inventory, storage and drop actions play
`caelum/ui/menu_select`. V4.30.0h connects the same two events to every
crafting navigation/option and accepted-action branch that was still silent.
`CaelumSmall` also raises `SpaceWidth` from 5 to 8, matching the main menu's
word-space metric without changing glyph art, line height or kerning.

The per-material crafting model from 4.30.0e is retained, but efficiency now
uses 25%/50%/100% while preserving the explicit time factors
25%=1×, 50%=10× and 100%=100×. The
factor is applied independently to every executed recipe layer after material
waste and operation complexity are known, and before Dexterity Type-1 speed is
applied. For an otherwise identical 100-unit layer, material use is
400/200/100 while its own work scales as 400/2,000/10,000 before Dexterity.
Creation, direct recursive routes and repair use the selected
layer/tier factor; disassembly has no efficiency selection and remains on the
1× baseline. Common standalone processing/component batches now use four
theoretical units at x1, yielding exactly 1/2/4 at 25/50/100; alloy lot sizes
and ratios remain unchanged.

## Recursive layered crafting and material work 4.30.0e

**Implemented; exact-engine load, formula audit, complete recipe-tree audit and
visual capture passed in GZDoom 4.14.2; efficiency percentages and time
relation superseded by the 4.30.0i branch-weighted regime above; the author
later passed the complete 11-point Windows/Doom II matrix on 4.30.0h**

Journal → Crafts now expands the selected recipe through every producible
component and processing dependency until it reaches raw materials. Each
material row includes its owned/required amount. The view shows four
scrollable rows, keeps the final operation and every craftable
intermediate selectable with Up/Down, and changes only the selected layer's
25%/50%/100% efficiency with X. It presents both the route that uses current
inventory and the theoretical route from raw materials. Direct physical and
elemental weapon plans continue to consume existing components first and now
carry the selected efficiency, input-unit count, complexity and duration for
each missing layer.

Fixed ten-second transactions are removed. Each executed recipe layer costs
one, two, three or four engine tics per employed material unit and then applies
`100 / Type1DexterityPercent`. Type-1 remains
`100 + Dexterity * (Dexterity + 1) / 2`, so Dexterity 100 supplies 5150% and
completes the same material work 51.5 times faster than Dexterity 0. Simple
processing, structural parts and ordinary blade/pole weapons use one tic;
bows and flails use two; armor, shields, giant gauntlets and crossbows use
three; essence/gem/jewelry work, elemental implements, amulets, seals and the
carbine use four.

Standalone processing and component batches use their 25%/50%/100% output
yield. Indivisible assembly and repair always complete the result and apply
efficiency as material waste: each theoretical input becomes
`ceil(input * 100 / efficiency)`, and the extra units also add time. Repair
uses the reserved proportional inputs and the item's complexity. Disassembly
keeps its durability-scaled 50% recovery and now uses the corresponding item
complexity instead of the retired fixed duration.

The `ca_debug_advance_crafting_time` network command and its Customize
Controls entry subtract exactly 600 seconds from a valid attended active task.
It respects the normal station, distance, infrastructure and pause checks and
uses the same atomic completion path when the remainder reaches zero. T invokes
it directly while the Crafts station page is open.

The exact 4.14.2 audit measured a 51.500 speed ratio, verified independent
layer preview changes, verified that 50% doubles the final-operation inputs,
and verified a 1000-second task becoming 400 seconds after one debug advance.
All 129 catalogue recipes at all three tiers built valid recursive trees; the
largest used 16 of the 32 reserved nodes and the invalid count was zero. An
offscreen Journal capture confirmed that the tree, selected-layer highlight,
two time previews and task status fit the 640×360 virtual layout. The test PK3
loaded MAP01 and remained running for the bounded smoke interval. MAP01,
MAP02, actors and art are unchanged by this patch.

## Player start-weapon repair 4.30.0d

**Implemented; crash reproduced and repair smoke-tested in exact GZDoom
4.14.2; focused Windows/Doom II confirmation pending**

The post-4.30.0c report no longer contains orphan-sector warnings, but retains
the same address-`0x58` access violation. Symbols for the exact engine build
place the failure in `PlayerPawn.BringUpWeapon`: `ReadyWeapon.GetReadyState()`
receives GZDoom's `WP_NOCHANGE` sentinel instead of a real `Weapon`.

`CaelumPlayer.GiveDefaultInventory()` formerly called the DoomPlayer method
and then removed its inherited Pistol. Removing the selected weapon can finish
the fallback selection with `PendingWeapon = WP_NOCHANGE`; `PlayerReborn`
subsequently copies `PendingWeapon` into `ReadyWeapon` before psprite setup.
The sentinel is a valid generic `DObject`, but it has no `Weapon` virtual entry
for `GetReadyState`, which produced the null function access.

V4.30.0d declares `Player.StartItem "Fist"` in `CaelumPlayer.Default`. The
first subclass start-item declaration replaces DoomPlayer's inherited list,
so Pistol and Clip are never granted and no active weapon is removed during
rebirth. The redundant `TakeInventory` calls and override are gone. A control
run reproduced the crash with the cumulative 4.30.0c PK3; the corrected PK3
loaded MAP01, initialized the safe direct-start profile and remained alive for
the complete bounded smoke interval on GZDoom 4.14.2. MAP01, MAP02, gameplay
systems and assets are otherwise unchanged.

## MAP01 orphan-sector compaction 4.30.0c

**Implemented and independently structurally validated; runtime warnings
cleared, superseded by the 4.30.0d player-start correction above**

The first V4.30.0b MAP01 runtime attempt reached level setup after successful
ZScript parsing, then reported 17 sector records with no lines before the
player was initialized. They were sector indexes 30, 31, 33, 34, 75, 82, 84,
94, 96, 244, 245, 268, 271, 322, 323, 346 and 349, carrying the residual tags
510, 546, 580, 581 and 562. The thick-wall carving had removed their complete
boundaries but had not compacted the sector table.

V4.30.0c removes exactly those unreferenced records and remaps every live
sidedef sector index in original order. Independent before/after validation
confirms that all 1,419 vertices, 1,983 linedefs, 3,544 sidedefs and 322 Things
are retained; vertex, linedef and Thing blocks are byte-identical, and every
retained sector and every non-index sidedef property is unchanged. All 618
remaining sectors have at least one sidedef. There are no invalid front/back,
vertex or sector references, no orphaned/shared sidedefs, no zero-length or
coincident linedefs and no `sideback`/`twosided` disagreement. Corrected MAP01
SHA-256 is
`b333acc001de94d9d1342f62c92596e7e521ff007da620432e0bbdabbfabddfe`.

`tools/rebuild_4_30_0c_maps.py` accepts only the exact rejected V4.30.0b WAD or
the exact corrected WAD, performs an atomic replacement and is idempotent.
This patch changes no ZScript, LANGUAGE, crafting, inventory, actors, MAP02 or
assets. Its next load removed every orphan-sector warning and exposed the
independent ready-weapon failure corrected in V4.30.0d.

## Journal crafting, exact weapon cycling and solid mansion walls 4.30.0b

**Implemented and statically validated in 4.30.0b; fixed-duration behavior
superseded by the 4.30.0e material-work regime above**

The V4.30.0a runtime report is addressed in one incremental candidate. Missing
Journal inventory, filter, weight and help strings now have English and Spanish
LANGUAGE entries. Using a connected station opens Journal → Oficios directly;
the former debug presentation no longer intercepts or renders crafting. The
Oficios page displays the selected output icon, recipe, tier, size, batch,
efficiency, material availability, cumulative infrastructure, direct-route
steps and running/paused task state.

In 4.30.0b every normal craft, refinement or component transaction took 10
seconds at all three efficiencies and all four batch multipliers. Candidate
4.30.0e replaces that provisional duration with the per-unit complexity model
documented above. In both versions, an active task only
advances while its Journal station session remains open, the player is within
96 MU, the snapshotted infrastructure is still available and the player is out
of combat. Closing/leaving, missing infrastructure or later combat pauses the
clock; none consumes inputs or cancels the task. Its exact reservations remain
blocked until the player resumes and completes it or explicitly cancels it.

Physical and elemental weapon assembly can consume a recursively resolved
primary-material plan when direct components are missing. Existing components
are used first and the complete primary input route is reserved atomically.
The path requires the same cumulative stations and does not create intermediate
inventory objects. In 4.30.0e, independently selected material work replaces
the former ten-second increment for every skipped component/refining recipe.

Inventory Left/Right walks filters and Right enters Personaje after the last;
F always advances the filter. Numeric slot 2 cycles exact equipped small-family
instances by `ItemId`, so equal daggers with different durability or finish are
distinguishable in the active-weapon HUD. The inherited Doom Pistol and Clip are
removed from every default inventory grant.

MAP01 converts the 31 remaining thin mansion `CMIN01` panels into 19 closed,
8-MU-thick z=0..128 wall volumes. Doors, stairs, the 91 material piles, upper
floor occupancy/profile and MAP02 are unchanged. MAP01 now contains 1,419
vertices, 1,983 linedefs, 3,544 sidedefs, 635 sectors and 322 Things; SHA-256 is
`ebc4c8aa654bdfc7c3ccd4eb60a8aa9bc4a745f85715189325612cf7bdec6f90`.
The reconstruction is deterministic and idempotent.

## Version 5 thermal exposure design

**Author-approved and scheduled; not implemented**

V5.1.0 will consume the stable weather snapshot planned for V4.35 after the
V5.0.0 modular transition. The approved player model combines ambient climate,
tagged indoor/outdoor environmental zones, activity derived from real Air
expenditure, wind, persistent 0–100 wetness, exact equipped-item thermal
properties and temporary food/drink effects. Resilience widens the base
comfort band.

Thermal excess accumulates with recovery and hysteresis across comfortable,
mild, intense and extreme states. Heat increases Thirst loss, drains Lucidity
and slows Air recovery. Cold increases Hunger loss, drains Anima and increases
Health lost when damaged. Exact degrees, curves, multipliers and caps remain
author-controlled numeric gates and must not be invented during implementation.

The initial system affects only the player at a bounded low update frequency,
persists exposure and wetness, recalculates the local environment after load,
and displays normal HUD feedback only outside the comfortable band.

The author also approved activity/ventilation-driven sweat and delayed cooling;
shelter, heating and drying supplied by camps and properties; thermal effects
on rest; bounded gradual acclimatization across seasonal change; data-driven
species/race climate profiles; Fire/Water/Ice/Air environmental interaction;
and reduced equipment thermal protection as durability falls. Persistent
medical conditions remain unapproved. Detailed design is recorded in
`docs/V5_THERMAL_EXPOSURE_DESIGN.md`.

## Atomic crafting and durability loop 4.30.0a

**Implemented and runtime-tested by the author; superseded by the focused
4.30.0b corrections above**

One serializable task now owns the complete refine/component/assembly/repair/
disassembly transaction. It snapshots recipe configuration and infrastructure,
reserves exact type+tier input amounts and any required Magic Box output slot,
and blocks the exact repair/disassembly `ItemId`. Only explicit cancellation
releases the reservation; completion consumes and produces atomically.

The 129-entry recipe book preserves indices 0–78 and appends 50 component
recipes at 79–128. Component recipes use one base material and the cumulative
station network of their equipment family. Their exact Minor-Arcana sources
remain deliberately unassigned; `ca_debug_crafting_learn_all_recipes` is the
QA-only unlock.

MAP01 receives 91 non-solid 10,000-unit material stacks in six ground-floor
clusters. Vertex, linedef, sidedef and sector digests are unchanged from
4.29.0bd, MAP02 remains byte-identical, and no character sprite or unrelated
asset is part of this candidate.

Focused acceptance requires: all 25/50/100 efficiencies at all four batch
sizes, start-in-combat rejection, manual cancellation, save/load and map travel
during a task, carry/Box overflow, every equipment family at tiers 1–3 and
sizes 1–5, proportional repair, durability-scaled disassembly, duplicate item
IDs, elemental outputs, decorative silver/gold and zero-durability recovery.

## HUD-03 laurels, selected audio v3 and parser repair 4.29.0ay

**Implemented and structurally validated; focused runtime GZDoom validation
remains pending**

The reported GZDoom 4.14.2 parser failure is repaired at its exact source:
`action` was a reserved token and is no longer used as the equipment-action
parameter. HUD-03 contributes exactly four final runtime PNGs. Resource
laurels decorate Health, Anima, Adrenaline, Lucidity and Air after their fills;
the normal/selected Journal laurels compose behind each navigation frame.

Selected-audio v3 supersedes v2 without duplicating its shared files. Thirteen
new OGG assets complete the twenty-file author package. Event-bound sounds have
bounded lifetime or replay rules; the three `caelum/stock/*` names are declared
only for future use. `TERRAIN` plus the native `PlayerPawn.MakeFootsteps` flag
select the grass step sound without a per-tic custom scanner.

Focused validation for this candidate is:

1. Start GZDoom 4.14.2 and require ZScript to load past
   `CaelumJournalOverlay.zs` with no parser or unknown-resource error.
2. Open the Journal and visit all six pages; require the active gold laurel and
   inactive silver laurels to stay behind the original frame/icon layers.
3. Inspect the five left resource bars at 16:9 and 4:3; require both laurels to
   align without changing the bar fill geometry.
4. Exercise each connected sound once, including held-use on a locked door,
   and require no per-tic repetition or lingering burn/Zupay loop.
5. Run `playsound` for the three stock names, but require no automatic caller.

MAP01 and MAP02 remain outside this patch and preserve their 4.29.0ax hashes.

## Formal inventory and per-piece identity 4.29.0ax

**Implemented and structurally validated; focused runtime GZDoom validation
remains pending**

`Actor.Inv` remains the sole authoritative source for ownership. Every
`CaelumEquipmentItem` now carries a persistent positive `ItemId`, allocated by
the character's travelling state and preserved through native copies, drops,
pickups, crafting, migration, saves and map travel. Equal equipment recipes no
longer collapse into one ownership flag: several identical pieces can coexist
and their active armor/shield/weapon/accessory references retain the exact ID.

Materials, consumables and ammunition remain amount-based native stacks. A
material stack is keyed by type+tier and occupies one Magic Box slot regardless
of amount; a non-stackable piece occupies one slot. The Journal Inventory page
now reads a play-scope snapshot of the real chain, displays six rows at a time,
filters all eight authored categories, and sends synchronized actions for
equip/use, storage and dropping. It no longer depends on the debug catalogue
selector and does not invent unowned entries.

Focused validation for this candidate is:

1. Create or collect two identical equipment pieces; require different stable
   `#ID` values and independent durability/storage state.
2. Save, load and travel between maps; require both IDs and the selected active
   piece to remain unchanged.
3. Put material stacks of different type/tier in the Magic Box; require one
   slot per stack and no slot increase when `Amount` increases.
4. Exercise every Journal filter and the equip/use, transfer and drop actions;
   require actions to affect only the selected real entry.
5. Recheck crafting with a duplicate recipe; require a new piece instead of a
   duplicate rejection.

MAP01 and MAP02 are outside this patch. Their hashes remain the exact 0aw
values, so the next coordinate-guided MAP01 pass can be applied independently.

## Solid north walls and lower-U removal 4.29.0aw

**Implemented and deterministically validated; focused visual GZDoom
traversal remains pending**

The two supplied north-wing views identify complementary missing closures: the
surviving thin curtain beside door 804 with its cleared continuation, and the
exterior wall that must meet the eastern flight. The door-side replacement is
a real z=0..128 wall, 24 MU thick, extending from the existing x=1113 jamb to
the stair face at x=1306. Its four physical footprints share one new lower-wall
profile while retaining the exact z=128..136 and z=256..264 slabs. Every
coplanar middle texture is empty, including the former line-608 `midtex3d`
curtain.

The exterior north closure uses seven existing 8-MU footprints arranged as
three continuous runs: x=1201..1209/y=391..544,
x=1201..1689/y=383..391 and x=1689..1697/y=320..391. They receive only the
z=0..128 wall profile and meet the eastern flight without altering any stair
sector. The five curtains at x=1697..1969, y=-272..272 that formed the lower
eastern U are empty, and the two group-807 leaves are removed. The group-913
leaves remain unchanged at z=136.

The deterministic rebuild from an exact 0av MAP01 is idempotent. MAP01 now has
1,052 vertices, 1,448 linedefs, 2,606 sidedefs, 441 sectors and 223 Things;
SHA-256 is
`e704fa8f8e9419839ae1dc0a5081001bb5ef0c3286f80f3f0b50a61d3e270fb1`.
The stair digest remains `5862699c73c2511c4db249c483b6a198b82ab8b3ea7ca467d52df6442fc04b76`
and first-/second-floor occupancy remains
`cde1b9a7074268a0643bc6375cb65b8babff3c617847c67c5db66f58bd0420b0`.
The previously reported grass appearance is deliberately unchanged.

Focused validation for this candidate is:

1. Inspect both north-wall viewpoints; require a solid 24-MU door-to-stair
   wall and a continuous 8-MU exterior closure with no thin duplicate panel.
2. Walk the former eastern U and group-807 opening; require no curtain,
   collision, door leaf or HOM at ground level.
3. Recheck both stair flights and group 913 at z=136.
4. Recheck the first and second floors and require no material, wall, floor or
   collision change. The grass defect remains outside this pass.

## Legacy-curtain removal and door alignment 4.29.0av

**Implemented and deterministically validated; focused visual GZDoom
traversal remains pending**

The 0au profile audit did not model two-sided 3D middle textures, so 36
ground-level `CMIN01` curtains around the rear stair flights and two exterior
continuations remained visible and collidable. V4.29.0av clears exactly these
38 `midtex3d` flags and their 76 middle textures. Each source line was
lower-unpegged between floor-zero hosts, making the removed curtain occupy
z=0..128. No sector, vertex, stair tread or upper profile changes.

The two group-807 leaves move from x=1413 to x=1693 while retaining y=-32/+32,
z=0, orientation, group and motion arguments. They now sit directly below the
group-913 leaves and align with the eastern stair landing. The lower door ends
before the preserved z=128..136 slab and group 913 begins at z=136.

The complete sector and vertex digests remain identical to 0au, and the
first-/second-floor occupancy digest remains
`cde1b9a7074268a0643bc6375cb65b8babff3c617847c67c5db66f58bd0420b0`.
MAP01 stays at 1,045/1,438/2,590/437/225 and has SHA-256
`fb9c487be494c70ec309b68a180ab781f631185aa0f82aa817a0f0760f4a0ec0`.
The grass appearance remains explicitly deferred.

Focused validation for this candidate is:

1. Walk through all former panels surrounding both stair flights and the two
   exterior continuations; require no curtain, collision or HOM.
2. Verify the two stair flights and all necessary step/landing faces remain
   textured and usable.
3. Verify door 807 is at the eastern landing axis directly below group 913.
4. Recheck the first and second floors and require no geometry, material or
   collision change; ignore the separately deferred grass defect.

## Complete rear ground-floor opening 4.29.0au

**Implemented and deterministically validated; focused visual GZDoom
traversal remains pending**

V4.29.0au removes every remaining wall shown in the two author captures while
the rear ground floor awaits reconstruction. The complete south, north and
east perimeter U and both stepped exterior joins are open throughout z=0..128.
The two leaves of door group 807 remain at x=1413, y=-32/+32, and sectors 1–12
of the two stair flights remain unchanged.

The solid-profile change covers 18 physical sectors. The same mask touches 102
two-sided linedefs, whose 204 `CMIN01` middle textures are now empty; all eight
associated `midtex3d` flags are removed so no visual or collidable curtain
survives the opening. Profiles, materials and occupancy from z=128 upward are
identical to 0at, including the first and second floors. The exterior-grass
visual defect is explicitly deferred and receives no additional change here.

The deterministic MAP01 result remains 1,045 vertices, 1,438 linedefs, 2,590
sidedefs, 437 sectors and 225 Things; SHA-256 is
`835e1f113fa24b8b646f2dfccd712f603d1de91d8434c72b48a1b1367560fb74`.
MAP02 remains byte-identical at
`47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

Focused validation for this candidate is:

1. Walk through every former north/east/south wall and both exterior joins at
   ground level; require no collision, visible middle-texture curtain or HOM.
2. Confirm both 807 leaves and both stair flights remain present and usable.
3. Recheck the first and second floors and require no material, wall, floor,
   cover or collision change.
4. Ignore the outstanding exterior-grass appearance until its later focused
   pass; it is outside 0au.

## Ground-floor rear correction 4.29.0at

**Implemented and deterministically validated; focused visual GZDoom
traversal remains pending**

V4.29.0at corrects the inversion found in the 0as author test. The two group
807 leaves are restored at their original x=1413, y=-32/+32 positions, while
the four surrounding wall and jamb hosts remain open throughout z=0..128.
No other ground-floor barrier exists inside the rear room outside the two
existing stair flights.

The exposed corner in the supplied capture was the pair of stepped 8-MU joins
at x=1201..1209, y=-544..-391 and y=391..544. Their former profile contained
only the z=128..256 upper wall. Each join now reuses the existing profile 516,
closing z=0..128 with the same `CMIN01` material while preserving identical
occupancy from z=128 upward. The adjacent exterior ground sectors 19 and 22
now use `CMGR01A`; their z=128..136 `CMWD01` slabs are unchanged. MAP01's
first- and second-floor occupancy digest remains
`cde1b9a7074268a0643bc6375cb65b8babff3c617847c67c5db66f58bd0420b0`.

The deterministic MAP01 result is 1,045 vertices, 1,438 linedefs, 2,590
sidedefs, 437 sectors and 225 Things; SHA-256 is
`13e931502f0385e5115c32189f603ad32fefe92d2f10d4ab1d3819ad732f1d90`.
MAP02 remains byte-identical at
`47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

Focused validation for this candidate is:

1. Verify both leaves of door 807 remain usable while no wall or jamb crosses
   the rear ground-floor room.
2. Inspect both stepped exterior joins from ground level and require continuous
   wall, collision and no floating upper volume.
3. Verify the adjacent exterior base floors show `CMGR01A` with no checkerboard
   or HOM; their first-floor wood surfaces must remain wood.
4. Recheck the first and second floors and require no geometric, collision or
   material change.

## Rear-room shell and actor balance 4.29.0as

**Implemented and deterministically validated; focused visual/combat GZDoom
traversal remains pending**

The author capture proved that the wall still crossing the rear ground-floor
room was the historical group-807 construction, not the group-914 divider
removed by 4.29.0ar. Its two long sectors used a base floor of 136 MU and its
two jamb sectors used a base floor of 128 MU, so they remained opaque and
solid below the first floor despite the newer 3D-floor profiles.

V4.29.0as removes both 807 leaves and lowers only those four host floors to
zero. The former top surface is replaced by the same `CMWD01` z=128..136 slab,
and the z=256..264 cover is retained. A band-by-band occupancy digest across
every induced cell confirms no first- or second-floor volume changed. The rear
ground-floor interior now contains no barrier outside the two accepted stair
flights, while its north, east and south perimeter is continuously solid from
z=0 to 128. The group-913 and group-915 doors, stairs, upper walls, balconies
and gabled room remain unchanged.

The deterministic MAP01 result is 1,045 vertices, 1,436 linedefs, 2,586
sidedefs, 435 sectors and 223 Things; SHA-256 is
`8a4e55a4808002ccb0aa5ae3c4c66b94750a68b38874aef939148cfaaae1f1da`.
MAP02 remains byte-identical at
`47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

The Bull retains its existing charge and now applies a direct profiled gore at
the end of that advance. Its authored base damage is 45. Physical and
technical attributes are all 20; social and mental attributes remain 2.
Zupay's ground slam retains base 66, 192-MU falloff and +8 vertical launch,
but its state lasts 20 tics instead of 10: 12 before impact and 8 after.

Focused validation for this candidate is:

1. Traverse the rear ground-floor room and require an uninterrupted interior,
   with no group-807 wall or leaves and no new seam at the former wall line.
2. Inspect the complete exterior north/east/south shell from both sides and
   require continuous wall and collision at z=0..128.
3. Recheck the first and second floors, especially the old wall footprint;
   floor, cover, stairs, doors and movement must be unchanged.
4. Summon a Bull and verify the charge ends with a 45-base gore and that its
   six physical/technical attributes report 20.
5. Summon Zupay and verify the same slam effect now takes twice as long.

## V4.30 material-processing and durability definition through 4.29.0aw

**Author-specified design only; no V4.30 transaction is implemented**

The design now fixes directional 0.001-unit rounding, complete-transaction
batch timing, exact alloy ratios, zero-spend/zero-output cancellation,
missing-durability repair time, Minor-Arcana learning, persistent wood tiers,
decorative-metal proportionality, the javelin exception boundary and the lack
of durability on amulets/seals. A task cannot begin in combat and, once active,
only an explicit user order cancels it. Disassembly uses exactly the crafting
time and station network of the corresponding object. Each component recipe
uses the cumulative station network of the target equipment recipe. Exact
component-to-card assignments are deliberately deferred until the Tarot-card
implementation. Required inputs are calculated and locked as a reservation
when the task starts. They cannot be used by another transaction and are
consumed only on atomic completion; explicit user cancellation releases the
full reservation without spending anything or generating output. All rules
needed for the V4.30 transaction are now defined. The authoritative formulas
and mappings remain in
[`V4_30_CRAFTING_DESIGN.md`](V4_30_CRAFTING_DESIGN.md).

## MAP01 topology cleanup and folklore gameplay profiles 4.29.0ar

**Implemented and deterministically validated; focused visual GZDoom
traversal remains pending**

The MAP01 correction is deliberately limited to the defects shown in the
three author captures. It removes the isolated floating floor fragment, closes
two open profiles so their visible planes remain within the intended house
footprint, restores the affected floor material and surrounding closure,
closes the exposed exterior section and removes the unintended wall crossing
the rear ground-floor room. The rear room remains a single continuous space;
the second-floor room, gabled-roof orientation, balconies, stairs and existing
door groups are not redesigned by this pass. The final output is 1,045
vertices, 1,436 linedefs, 2,586 sidedefs, 435 sectors and 225 Things; SHA-256 is
`35e52122f54ce9490005e2de8e574afd02fc9dcf4a0f40fb0374e16f37bd79ce`.
Only its focused visual traversal in GZDoom remains pending.

The supplied character package still contributes 380 individual runtime
frames: 224 for Palomo, 54 for Mandinga and 102 for Zupay. Ten atlas images
remain review sources outside the PK3; eight README/manifest files remain
auditable under `docs/assets/characters`. The package importer continues to
validate paths, dimensions, RGBA format, manifest totals and the exact
224/54/102 distribution before generating runtime aliases.

The three actor profiles now use the playable-character statistical model:

| Actor | Collision | Mass | Twelve attributes | Authored behavior |
| --- | --- | ---: | ---: | --- |
| Palomo | `Height 56`, `Radius 16` | 700 | 100 | Historical 4.29 behavior: wanders autonomously and has no attack. V4.32.0b anchors the MAP01 merchant; V4.32.0c makes it run home after a displacement of at least 500 MU. |
| Mandinga | `Height 51.644444`, `Radius 14.755556` | 66 | 6 | Melee base 66; ranged action reuses the tier-1 Fire staff behavior. |
| Zupay | `Height 93.333333`, `Radius 26.666667` | 666 | 33 | Ground slam base 66, 192-MU linear-falloff radius and +8 vertical launch; ranged action temporarily reuses the tier-1 Earth statuette behavior. |

`CaelumPalomo`, `CaelumMandinga` and `CaelumZupayColossus` retain editor
numbers 18036–18038 and their console summon names. In historical 4.29.0ar none
received a faction, loot table or MAP01/MAP02 placement. V4.32.0b places only
Palomo as the initial MAP01 merchant and V4.32.0c adds bounded return behavior;
the faction system remains a
separate roadmap feature.

Focused validation for this candidate is:

1. Inspect the three reported MAP01 viewpoints and require no floating piece,
   runaway plane, checkerboard/missing material, HOM or open exterior seam.
2. Traverse the complete rear ground-floor room and require one continuous
   interior with no crossing divider; recheck the adjacent stairs, doors,
   balconies and roof access.
3. Summon each actor and verify collision height/radius, mass and all twelve
   attributes. Palomo must move without producing an attack.
4. Confirm Mandinga's 66-base melee and tier-1 Fire-staff ranged behavior.
5. Confirm Zupay's 66-base slam, 192-MU linear falloff, +8 vertical launch and
   tier-1 Earth-statuette ranged behavior.
6. Build the PK3 without parser or missing-resource errors and verify MAP02
   remains byte-identical to its accepted all-sewer source.

## V4.30 material-processing and durability definition through 4.29.0ar

**Author-specified design only; no V4.30 transaction is implemented**

The complete current definition, recipe-family mapping and unresolved gates
are maintained in [`V4_30_CRAFTING_DESIGN.md`](V4_30_CRAFTING_DESIGN.md).

Refinement and equipment-material fabrication offer 25%, 50% and 100%
material yield. For a fixed base-material input `B`, their outputs are
`0.50B`, `0.75B` and `1.00B`; elapsed-time factors are ×1, ×3 and ×9. The
test environment uses a 9-second base, so the three unaccelerated durations
are 9, 27 and 81 seconds. Effective duration will later be divided by the
Dexterity Type-1 physical-precision task-speed percentage; its test modifier
is currently neutral.

Every equipment component is fabricated from exactly one base-material type.
Metal components, including bells, use their corresponding ingot; elemental
essences use their assigned gem; staffs, statuettes and sticks use wood; books
and cords use fiber; straps use the simplest leather; and armor uses the
leather grade corresponding to its tier. This restriction does not redefine
multi-input alloy-refining recipes.

Repair reuses the complete item recipe and the same station infrastructure,
with material cost scaled by missing durability:

`RepairInput = BaseRecipeMaterial × (MaximumDurability - CurrentDurability) / MaximumDurability`.

Disassembly always returns half of the base recipe, then scales that recovery
by remaining durability:

`DisassemblyOutput = BaseRecipeMaterial × 0.50 × CurrentDurability / MaximumDurability`.

Elemental weapons return their corresponding recipe materials. The established
0.001 material unit remains the quantity convention, but rounding proportional
results to integer inventory units is still undefined. Batch timing,
interruption/cancellation and the other gates listed in the design document
also remain open. Existing immediate processing and repair/debug foundations
remain unchanged in 4.29.0ar.

## Exact eastern roof and stair-run walls 4.29.0ap

**Implemented and statically validated; focused author QA pending**

V4.29.0ap preserves both symmetric transverse walls from 0ao and adds the two
8-MU stair-run walls leading from them to the 128-MU group-913 opening. Its
z=256..264 cover is rebuilt as the exact x=1209..1697, y=-328..328 interior
slab plus the existing landing and two upper stair treads. Side balconies and
all lower treads remain outside the slab. MAP01 is
`(1029, 1424, 2578, 431, 227)` with SHA-256
`d7c54872c3de2f7bf4dc1800bded68909cf3484ddb6e82fb00812cf203ec46d7`.
MAP02 remains byte-identical at
`47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

The author accepted the character-creation flow, sound mix/event mapping and
the final non-house MAP01/MAP02 smoke before this saved house revision. Only
focused traversal of the latest stair walls and exact roof remains pending;
the V4.30 rules above are still definition-only.

## Open balcony perimeter, gabled roof and selected audio 4.29.0am

**Implemented and runtime-loaded; focused author QA pending**

V4.29.0am preserves the approved x=-371..1055 upper room, group-915 door at
x=1051, direct corridor, lower shell, exterior stairs, tunnel and door groups.
The latest capture identified the remaining obstruction as the long outer
balcony wall, not only the two terminal sectors corrected in 0al. The north,
east and south sectors of that U now retain the z=0–128 ground-floor facade and
z=128–136 walkable floor while omitting every z=136–256 wall and z=256–264
cover. The western joins and two lower 8×8 corner closures remain unchanged.

The same upper-room footprint now carries a two-slope roof with an east-west
ridge, perpendicular to the eastern balcony. Each solid plane is 8 MU thick:
the eaves occupy z=392..400 at y=±391 and the author-selected 64-MU rise places
the ridge at z=456..464 on y=0. The exterior face uses `CMRF01`; the underside
uses `CMCL01`. The room split at y=0 increases its exact closed partition from
186 to 188 target sectors without moving its walls, floor, doorway or actors.

The former three-band grass repeat is no longer assigned to MAP01. The world
sector uses standalone `CMGR01A`; `CMGR01B` and `CMGR01C` are separately named
128×128 variants for later worn and dry sectors.

Eight OGG effects have stable logical names and active callers: menu open and
confirmation, first recipe unlock, ordinary and multi-leaf sliding doors,
carbine discharge, item pickup and local low-health heartbeat. The heartbeat
uses a 42-tic timer for its 1.055-second file, plays only in the existing badly
wounded state and stops on recovery, death or character creation. Mandatory
CC BY 4.0 attribution and CC0 traceability ship in
`src/licenses/AUDIO_CREDITS.md`; preview files remain development assets until
their authenticated Freesound originals replace them before release.

Deterministic map outputs are:

- MAP01 `(927, 1286, 2362, 382, 227)`, SHA-256
  `1fbc9638c7b0b454ed7b443e64b50989ee89d854e19ed730433eb44cf0e26cc7`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

The clean-base reconstruction, second execution, topology/references, exact
roof equations and resource decoders pass. GZDoom 4.14.2 compiles the complete
ZScript/SNDINFO set, enters MAP01 without loader errors and renders the open
outer wall and both roof slopes in automated viewpoints. Author acceptance
must still traverse the complete balcony, inspect the interior roof collision
and verify every sound at the intended mix before this candidate is accepted.

## Open first-floor balcony ends 4.29.0al

**Implemented and statically validated; focused author QA pending**

V4.29.0al preserves the accepted 4.29.0ak second-floor room at
x=-371..1055, group-915 double door at x=1051, roof, direct corridor, exterior
grass, closed lower corners, ground-floor rooms, stairs, tunnel and existing
door groups.

The screenshot from the 0ak visual pass identified the remaining blockers as
the symmetric 8×96-MU sectors at x=1689..1697, y=-391..-295 and y=295..391.
They stood across the ends of the two side balconies before the eastern
exterior platform. Their new profile retains the z=0–128 mansion wall below
the balcony and the z=128–136 walkable wood slab, but contains no z=136–256
wall and no z=256–264 cover. The lower facade therefore remains closed while
the first-floor route and sky become continuous.

Validation samples cover both terminal sectors and the platform side of the
x=1697 seam. They independently require the lower wall, balcony floor, open
first-floor volume and absence of overhead cover. The parsed 227-Thing table
is unchanged from 0ak, including the accepted second-floor door coordinates.
Deterministic outputs are:

- MAP01 `(940, 1297, 2368, 384, 227)`, SHA-256
  `fa51876850a0ab2ca2ec13cdb75e5e0cba989d6c65abce39313ec6137a658719`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

The count increase from 0ak is restricted to two off-map 3D-floor control
sectors and their eight vertices/linedefs/sidedefs. Runtime acceptance is
limited to walking both balcony ends and confirming the already approved
second floor remains visually unchanged.

## Free balconies, closed lower corners and western upper room 4.29.0ak

**Implemented and statically validated; focused author QA pending**

V4.29.0ak reconstructs MAP01 directly from the exact clean 4.29.0ad WAD. It
preserves the accepted lower rooms, ground divider and group-914 door,
external stairs and landing, tunnel, group-913 access, mansion materials and
`CMGR01` exterior terrain.

The complete 1426×782-MU upper room moves exactly 150 MU west from its 0aj
position: x=-371..1055, y=-391..391. Its floor, 8-MU perimeter, roof and
centered eastern opening move as one unit. The two group-915 leaves are now at
`(1051,-32,264)` and `(1051,32,264)`; every other Thing is unchanged. The
128-MU-wide direct corridor covers x=1055..1697 and continues to the unchanged
stair landing.

The six inherited pieces at x=1306..1689, y=±287..295 and x=1306..1314 no
longer produce z=128–256 walls. Their complete footprints share the open-
balcony profile: a z=128–136 wood floor, no obstruction above it and no
z=256–264 cover. Both 96-MU balconies therefore connect across their full
width instead of through a single narrow opening.

The two missing lower corner cells at x=1201..1209, y=-391..-383 and
y=383..391 now use the same z=0–256 exterior-wall profile as their adjacent
perimeter. This closes the ground-floor shell symmetrically without adding an
internal wall to either expanded rear room.

The room's 186 closed rectangular targets cover exactly 1,115,132 MU². The
corridor's eight targets cover exactly 82,176 MU². Both partitions stay inside
their declared bounds, contain no positive-area overlap and fill their
rectangles exactly. Deterministic outputs are:

- MAP01 `(932, 1289, 2360, 382, 227)`, SHA-256
  `378c8de65607ccb7a135f25a063e06daeb495b1c52b4102e09c3d76aade7005e`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

The constructor validates both corner links, every balcony transition sample,
the room/roof/door displacement, closed target topology, references and
idempotence. Runtime acceptance is restricted to these MAP01 geometry points;
MAP02 and all gameplay systems are unchanged.

## West-shifted upper room, uncovered balconies and grass 4.29.0aj

**Implemented and statically validated; focused author QA pending**

V4.29.0aj reconstructs MAP01 directly from the exact clean 4.29.0ad WAD. It
preserves the accepted ground-floor and first-floor walls, rooms, balcony
passages, external stairs, tunnel and groups 913/914. An exhaustive cell
comparison against 0ai finds zero changes in physical coverage at z=0–128,
128–136 and 136–256.

The complete 1426×782-MU upper room moves exactly 100 MU west, from
x=-121..1305 to x=-221..1205. Its floor, 8-MU perimeter, roof and centered
eastern opening move as one unit. The two group-915 leaves move from x=1301 to
x=1201 at y=-32/32 and z=264; every other Thing remains identical to 0ai. The
128-MU-wide direct corridor now covers x=1205..1697 and joins the unchanged
stair landing.

The two lateral first-floor balconies are again exterior and uncovered. Four
dedicated physical targets retain only the z=128–136 wood slab; they contain no
z=136–256 obstruction and no z=256–264 upper cover. The middle platform,
stair landings and direct corridor retain their upper walking surface.

MAP01's world sector now uses the project-owned 128×128 `CMGR01` grass-and-soil
terrain master. `TEXTURES` registers it as a native flat, and no MAP01 sector
retains Doom's `FLOOR0_1`. Interior floors and all mansion 3D floors remain on
their existing mansion materials.

The room's 193 closed rectangular targets cover exactly 1,115,132 MU². The
corridor's seven targets cover exactly 62,976 MU². Both partitions stay inside
their declared bounds, have zero positive-area overlap and exactly fill their
rectangles. Deterministic outputs are:

- MAP01 `(976, 1335, 2412, 396, 227)`, SHA-256
  `f743acf7a08a27d5e511bd067218a00a8ea1bf19376bb6703dbd8866ec843858`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

An independent reconstruction from 4.29.0ad reproduces both WADs byte for
byte, a second execution is idempotent and the complete development PK3 passes
its ZIP/UDMF gates. Runtime acceptance is limited to the room position and
group-915 door, both uncovered balconies and the exterior grass. MAP02 and all
gameplay systems are unchanged.

## Restored upper platform and rear-aligned room 4.29.0ai

**Implemented and statically validated; focused author QA pending**

V4.29.0ai corrects the two regressions observed in the 0ah runtime capture. It
again reconstructs MAP01 directly from the exact clean 4.29.0ad WAD. The
accepted ground-floor and first-floor shell from 0ah is byte-semantically
preserved: exterior walls remain z=0–256, balcony returns remain z=128–256,
both centered balcony passages stay open and groups 913/914 keep their actors,
positions and arguments.

The 1426×782-MU upper room moves another 40 MU toward the rear, from
x=-161..1265 to x=-121..1305. This restores its structurally aligned eastern
edge at x=1305, a total rearward correction of 104 MU from the rejected 0ag
position. Its complete footprint receives floor z=256–264 and roof z=392–400;
the 8-MU perimeter receives wall z=264–392 except for the centered y=-64..64
opening. Group-915 leaves move with that facade to `(1301,-32,264)` and
`(1301,32,264)`.

The eastern upper platform is no longer reduced to the central corridor. Every
legacy platform sector and every lower-shell profile again includes the
z=256–264 walkable slab. The 128-MU corridor remains the direct route from
x=1305 to the accepted landing at x=1697, but lateral platform floor is also
present. The constructor does not recreate any room target west of x=-121, so
the obsolete strip associated with the earlier x=-225 room position is absent.

The room's 180 closed rectangular targets cover exactly 1,115,132 MU². The
corridor's five targets cover exactly 50,176 MU². Each partition remains inside
its declared bounds, has zero positive-area overlap and exactly fills its
rectangle. A cell-by-cell comparison across the eastern platform finds no
upper-floor omission relative to 0ag; the only two differences add floor where
the rear-aligned room now overlaps the platform. Separate lower-volume
comparisons against 0ah find zero differences at z=0–128, 128–136 and 136–256.

Deterministic outputs are:

- MAP01 `(950, 1282, 2302, 373, 227)`, SHA-256
  `7c5514798969abc83fce0faf6702af99fbb359b1f8aa39d6e19fb18b427f9d01`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

An independent reconstruction from 4.29.0ad reproduces both WADs byte for
byte, and a second execution is idempotent. Runtime acceptance is limited to
walking the restored upper platform, confirming the room's new position,
opening group 915 from both sides and inspecting the underside for only the
intended platform. MAP02 and all gameplay systems are unchanged.

## Rebuilt lower shell, upper door and removed legacy awning 4.29.0ah

**Implemented and statically validated; focused author QA pending**

V4.29.0ah rejects the wall heights and extended upper slab from 4.29.0ag and
reconstructs MAP01 directly from clean 4.29.0ad. Existing rooms, both balcony
footprints, the ground-floor group-914 divider, external stair pair, tunnel,
shared landing and group-913 gate preserve their coordinates and arguments.

The eastern exterior shell now uses one consistent z=0–256 profile across its
north, south and east perimeter pieces. The west divider remains z=0–128 with
its centered group-914 door. The two x=1306 balcony returns are no longer
ground-floor walls: they occupy only z=128–256, so the rooms connect beneath
the balconies while the first-floor corners close. Each y=±291 interior wall
contains a centered x=1512..1576 passage into its balcony.

The upper room keeps 1426×782 MU but moves one 64-MU module toward the rear to
x=-161..1265. Its z=264–392 perimeter has a centered y=-64..64 eastern opening
with group-915 leaves at `(1261,-32,264)` and `(1261,32,264)`. A six-sector
128-MU-wide corridor runs from x=1265 to 1697 and joins the accepted landing.
Every other z=256–264 target east of x=1265 is removed.

The room's 190 rectangular targets cover exactly 1,115,132 MU²; the corridor's
six targets cover 55,296 MU². Neither partition has overlap or escapes its
bounds, and an exhaustive target audit finds no legacy upper slab outside the
corridor. Deterministic outputs are:

- MAP01 `(946, 1297, 2356, 383, 227)`, SHA-256
  `faf38441d47a3bc0db36d5b069aff082451e4ddabeb38251cf996396f16ed2f3`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

An independent clean reconstruction matches both WADs byte for byte. The
3,314-entry development PK3 passes the ZIP and UDMF structural gates.

Runtime acceptance is limited to MAP01: inspect the ground and first-floor
shell, all balcony corners and passages, the room position and group-915 door,
and the complete underside of the new corridor. No crafting, creator,
`changemap`, MAP02, IA or perception test needs repetition for this map-only
corrective increment.

## Closed upper perimeter and continuous eastern platform 4.29.0ag

**Implemented and statically validated; focused author QA pending**

V4.29.0ag supersedes only the second-floor room and eastern upper-platform
surfaces from 4.29.0af. It is reconstructed directly from the clean 4.29.0ad
WAD, not incrementally from the rejected visual result. The first-floor rooms
already accepted by the author, both balconies, the ground divider and its
group-914 door, the exterior stairs, tunnel, shared landing and group-913 door
retain their geometry and actor arguments.

The 1426×782-MU upper room moves 104 MU west to x=-225..1201 and remains
y=-391..391. Its complete 8-MU perimeter now receives the finite z=264–392
wall volume; there is no remaining east-side opening. Floor z=256–264 and roof
z=392–400 cover the full footprint. The resulting 179 physical rectangles
cover exactly 1,115,132 MU², have no positive-area overlap and stay inside the
intended bounds.

The eastern platform no longer relies on profiles that stopped below the
upper level. Six explicit profile families cover its ground walls, lower
balcony returns, full walls, upper walls, open balconies and floor-only strips.
All 26 corrected target sectors now include the z=256–264 floor. The balcony
returns retain walls only at z=0–128, so their lower corners close while the
z=136–256 balcony passages remain open.

Deterministic outputs are:

- MAP01 `(898, 1231, 2252, 362, 225)`, SHA-256
  `4efe597c8a5b632e8211d4afca6699db001d548e4145c4546491888f5adbd57e`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

The remaining runtime gate is visual and local: confirm the reported wall is
closed, the shifted upper room is fully supported, the eastern upper platform
has no floating strips or floor gaps, and both balcony corners close below
without blocking passage. MAP02 and all gameplay systems are unchanged and do
not require functional repetition for this corrective patch.

## Rear-wing closure, lower divider and centered second floor 4.29.0af

**Implemented and statically validated; focused author QA pending**

V4.29.0af supersedes the rejected MAP01 construction from 4.29.0ae and is
rebuilt directly from the clean 4.29.0ad geometry. The accepted external stair
pair, its shared landing, the tunnel beneath it and the group-913 double door
retain their positions, heights and arguments.

The missing return at x=1201..1209 now closes both rear wings through z=0–256.
The wall segments at x=1306 no longer block either balcony: the northern and
southern 96-MU strips retain only their z=128–136 walkable slab. The lower
outer corners use finite z=0–128 walls, so the spaces below those slabs belong
to the rear ground-floor rooms instead of reading as unsupported awnings.

The two former fins between the lower rooms are replaced by one continuous
divider along x=1201..1209. It is solid from z=0 to 128 except for a centered
y=-64..64 opening. Two 64-MU leaves at `(1205,-32,0)` and `(1205,32,0)` form
one group-914 sliding door; obsolete group 915 is absent.

The second-floor room no longer occupies the eastern edge. Its structural
rectangle is x=-121..1305, y=-391..391, centered within approximately 20 MU
of the main building axis and more than three times the rejected room's
length. An 8-MU perimeter receives finite z=264–392 walls. The complete area
receives a z=256–264 floor and z=392–400 roof, while the central 128-MU east
opening remains aligned with the accepted stair landing. The four internal
stair landings remain open inside the room rather than becoming wall volumes.

MAP02 keeps the same 112 vertices, 110 linedefs, 212 sidedefs, nine sectors and
16,508 Things. Every sector floor now uses `CASWRFLR`; every non-empty upper,
middle and lower wall face uses `CASWRWAL`. Its sky ceilings, actors, arguments
and all non-texture geometry are unchanged.

Deterministic outputs are:

- MAP01 `(884, 1206, 2206, 352, 225)`, SHA-256
  `dc56f1b681bb9d80bedaaa5ce37734f8137b2aabee3fe0c1f05dd1f3e4d36334`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `47e0804417f03e7e913fd2aab47cc7654c61e280f3d42671fd4287e90557cffe`.

The constructor consumes only the exact 4.29.0ad hashes. Its 180 physical
upper-room subdivisions collapse unused hosts and preserve canonical sector,
sidedef and vertex references. An independent clean reconstruction matched
both WADs byte for byte; a repeated execution is idempotent. The development
PK3 contains 3,314 entries and passes the ZIP and UDMF structural gates.

Focused runtime validation remains: inspect both closed lower returns, open
and traverse the group-914 divider door, enter both balconies without hitting
an invisible wall, verify the centered upper room and its eastern opening, and
inspect every MAP02 room for sewer surfaces. Creator, `changemap`, recipes,
inventory, crafting and AI behavior do not require repetition because this
increment changes only maps and public status files.

## Rear-room perimeter, balconies and second-floor room 4.29.0ae

**Implemented and statically validated; focused author QA pending**

V4.29.0ae supersedes only the rejected MAP01 partitions/perimeter from
4.29.0ad. Door groups 914/915 and their two internal divider walls are gone.
The ground-floor rear room now extends through both northern and southern
wings and is closed at its true exterior boundary by finite z=0–128 walls. No
wall control for that perimeter reaches into the balcony or upper floors.

The first-floor side walls are inset at y=±295. Beyond them, four sectors form
two symmetric 96-MU uncovered balconies with only the z=128–136 walkable slab.
The accepted external stair pair, shared landing, tunnel and group-913 double
door are unchanged. The thin internal contours left by the rejected dividers
remain only as harmless sector boundaries and receive no wall volume.

One new room is centered on the stair axis and aligned to the structural
rectangle x=1306..1697, y=-295..295. Its usable floor is z=264, its clear
interior reaches z=392 and its roof slab occupies z=392–400. Finite west,
north, south and east wall volumes enclose it. The central east strip remains
open above the existing lintel, providing a direct entrance from the
second-floor landing without adding another door group.

MAP02 again uses `CASWRWAL` and `CASWRFLR`. Its Things digest and non-texture
geometry digest remain unchanged, and the WAD matches the accepted 4.29.0ac
sewer version byte for byte. Deterministic outputs are:

- MAP01 `(756, 1017, 1904, 252, 223)`, SHA-256
  `d0e50dea403b8b1291a4b5ba513d6c3bd014735804e73f3687b1077ba75bf107`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `88956e5074fe4e0ae097cfb539b67a4e0a3b6f33407bddcfcdfb7b73ce8180a9`.

The constructor accepts only the exact 4.29.0ad WAD hashes, validates every
new control range and closed wall sector, and reproduced both maps byte for
byte in an independent clean rebuild. The complete development PK3 passes its
ZIP and UDMF structural gates. Because no ZScript, MENUDEF, persistence or
crafting source changed, the accepted `Nuevo personaje`/`changemap` result and
crafting cases 5–13 do not require repetition.

Focused manual validation remains: inspect both lower wings as one continuous
rear room, verify both balconies from above and below, traverse the second-
floor room and its centered entrance, and confirm MAP02 presents sewer
surfaces. Any HOM, floating face, internal solid cut or asymmetric balcony
rejects this architecture.

## First-floor tunnel, mansion materials and pre-game creator 4.29.0ad

**Implemented and statically/runtime-load validated; focused author QA pending**

MAP01 no longer places the new eastern door at the second-floor landing. The
two group-913 leaves stand at z=136 inside an opening from z=136 through 256.
The shared stair landing has a thin traversable floor at 128–136 and an upper
landing/ceiling at 256–264, so its underside is a tunnel instead of a solid
pedestal. The upper 264–392 facade volume is gone, removing the reported
floating bars.

Rear-room sectors 160/161 and the ten false retraction/fin sectors are part of
the rooms again. The side U closes the exterior perimeter. Two first-floor
dividers occupy y=-286..-278 and y=278..286 with centered 64-MU openings and
independent door groups 914/915. Their topology is validated against the
correct adjacent room sectors and is forbidden from touching world sector 0.

MAP01 uses `CMIN01`, `CMWD01`, `CMCL01` and `CMDR03` instead of its inherited
Doom ground-floor surfaces. MAP02 changes only sewer material fields to the
mansion wall/floor set; a semantic digest proves its 16,508 Things and its
diagnostic geometry are unchanged. Deterministic outputs are:

- MAP01 `(696, 942, 1798, 226, 225)`, SHA-256
  `7bc0519a11adf058848a7986e456cd0ea8a97457f7e6ec963310a1ed3dbbc3a2`.
- MAP02 `(112, 110, 212, 9, 16508)`, SHA-256
  `2f4568f60512ff3656476f32c506ac2547f6b4949b58b20d2f9b6de8c5fc0b54`.

The title-screen `Nuevo personaje` action now opens
`CaelumCharacterCreationMenu`, not the native Doom class/episode/skill chain
and not the old in-game overlay. It collects all eight existing creation pages
before starting MAP01. A one-use user-CVar draft bridges UI scope to the first
`CaelumPlayer`; committed persistent state always has priority. `map MAP02`
remains a new developer session and therefore receives a safe test profile,
whereas normal exits and `changemap` preserve the current character. Native
save loading supplies `Cargar personaje`.

The new code parses and its menu Drawer executes under GZDoom 4.14.2. An
automated keyboard pass completed all eight pages, verified the one-use CVar
draft and loaded MAP01. Both maps also load with the expected actor counts.
The incremental source omission in `ImpactContactState` is repaired: the
documented collision-refresh and once-per-pair-per-tic resolution methods are
present again, and stale edges expire after five collision-free tics.

### 4.29.0ac evidence audit

The group-16 control without follower movement closed normally. The moving
run did not: its incremental logfile retains exactly 1,024 complete reports,
or 17:04 simulated, and has no closing timestamp. The tester places the freeze
at about 18 real minutes. `logfile` therefore preserves everything flushed
before a freeze when enabled in advance, but cannot reconstruct a previous
unlogged freeze or provide a missing wall-clock end time.

Both runs kept 16,506 actors, 1,875 shared targets, 126 leaders, 1,749
followers, bounded projectiles and zero retained custom references/contacts.
Leader Chase stayed near 85–86 calls/s and peaked at eight per tic. The moving
run alone added 15,669,314 follower decisions (about 15,302/s) outside the
leader budget and drove up to all 1,875 active actors inside 512 MU around only
128 formation destinations. The final report is ordinary rather than a rising
counter spike. The best-supported cause is a pathological native movement or
collision tic in the compacted crowd, not a leak. That algorithm is rejected;
4.29.0ad leaves `ca_diag_mass_follower_movement=false` and does not authorize
3,750/7,500/15,000 active stages.

Perception arithmetic is internally coherent: all 455 logged rows satisfy
`detected = LOS && roll < visual probability`. Aperture produced 26/354 and
semicone 10/101, compatible with their expected probability sums. It is not a
valid angular A/B: 436/455 samples are within 30 degrees, semicone reaches only
36.6 degrees, and rooms 3/6 always report LOS 0/1 respectively. Hearing ranges
match the planned arithmetic, but only one positive event exists and the
diagnostic compares direct event serial/distance rather than validating real
sector `SoundAlert` propagation. Controlled angle markers, symmetric
occlusion and event-position/SoundAlert instrumentation are the next isolated
perception gate.

## Mansion correction and isolated perception/group prototype 4.29.0ac

**Implemented and structurally validated; GZDoom runtime validation required**

MAP01 is rebuilt only from the exact 4.29.0ab hash. The two mistakenly opened
rear-room wall pieces return to target 511 while the intended three-piece
central opening remains target 510. A new target-510 slab closes the unroofed
stair-origin cell. The enclosure moves inward from y=±391 to y=±295, leaving
96 MU of open balcony beyond the new full-height walls. The lower extension is
therefore part of the rear ground-floor room, while the side balcony remains
outside it. Every enclosed first-floor cell retains both the 128–136 floor and
256–264 roof slabs.

Two symmetric external stair flights occupy x=1697..1816. Each contains eight
32-MU-deep treads whose tops rise from z=152 to z=264. Their inner ends meet a
128×128-MU solid landing. The center of the inherited front wall contains a
128-MU opening above z=264; two `CaelumSlidingDoorLeaf` actors form independent
group 913 and cannot activate any earlier door group. MAP01 has 676 vertices,
918 linedefs, 1,754 sidedefs, 221 sectors and 223 Things; SHA-256 is
`41085aa4eafffae7d4d24706b31f3aa8e6900c22103d9b2bde0ed40c8498fd67`.

MAP02 removes the 108 local actors and 42 lines that implemented the obsolete
Look/Chase/projectile rooms. Six U-shaped raised-sector rooms and two interior
occluders replace them. The remote three-way Quintessence comparison is
unchanged. The mass field still contains exactly 15,000 actors: 13,125 passive
visual bodies plus 1,875 active actors. MAP02 has 112 vertices, 110 linedefs,
212 sidedefs, 9 sectors and 16,508 Things; SHA-256 is
`88956e5074fe4e0ae097cfb539b67a4e0a3b6f33407bddcfcdfb7b73ce8180a9`.

`CaelumDiagnosticPerceptionObserver` samples once per second and logs the
complete calculation. Its visual base is
`1000 / (1 + 9 × (distance metres / 20)²)` percent, with values below 1% set
to zero. The result then applies current target height / 56 MU, Insight
`1 + level/100`, retained Stealth and the angular factor before clamping to
100%. Native `CheckSight` must also pass. The default angular test interprets
60°/120° as total apertures (full strength through ±30°, quadratic fade to
zero at ±60°); `ca_diag_perception_wide_half_angles true` compares ±60°/±120°.
This CVar records an unresolved design interpretation rather than selecting a
final rule silently.

Walking now starts from the approved 50-dB base `50²/4 = 625 MU`; total mass
is divided by 100 kg, running is ×2 and crouching ×0.5. Stealth is applied
once, so crouching no longer doubles the Stealth stat and then also reduces
noise. Each observer consumes the player's latest event serial once and adds
its own auditory allowance before applying mass/movement/Stealth:
`(50+L) × [1 + 2L(L+1)/10100]`, producing 50/approximately 150.5/450 MU at
Insight 0/50/100. Listener height does not enter hearing.

The mass scheduler now publishes one live MAP02 target. Other field actors
adopt it by direct reference and enter `See` without an additional native
Look. Leaders retain the accepted ten-call native Chase ceiling. With
`ca_diag_mass_follower_movement true`, followers update a deterministic
32-direction/four-radius destination around that target and set local velocity
without native Chase, TryMove or actor searches. The default remains false so
the previously accepted baseline can be replayed first. This prototype does
not yet implement faction-specific target stores, sleeping distance tiers,
navigation around complex buildings or follower attacks.

Required runtime gates are listed in the roadmap. No stability, probability or
architectural result in this section is accepted merely from static validation.

The personal-document audit delivered with 4.29.0ab remains authoritative for
the already implemented systems: native saves plus
`CaelumPersistentCharacterState`, 0/79 new profiles, the 14-recipe processing
manual, localized armor, contextual Zoom Block and internal equipment levels
with base/silver/gold client names. Only 4.29.0ab's rejected house description
is superseded. The private document is deliberately not revised again until
the new architecture and diagnostic perception/group behavior pass runtime QA.

## Processing recipes and precious-metal finish costs 4.29.0aa

**Implemented and structurally validated; focused GZDoom gameplay/save validation pending**

The persistent Workbench catalogue contains 79 entries. The original 65
equipment indices are unchanged and the 14 processing recipes occupy the final
contiguous block. Recipe-book schema 3 preserves every schema-2 equipment flag
and initializes only the new processing block as unknown. A fresh character
therefore remains at 0/79.

`Manual de Procesamiento (LORE-0001)` is a real MAP01 key item placed at
x=-364, y=800, immediately left of the main station row. Picking it up once
unlocks the complete processing block. The tutorial's chosen starter-weapon
recipe and material handoff remain separate authored NPC work.

Five ore recipes and six fiber/hide recipes use the initial 50% conversion
rate: two raw units produce one refined unit. Bronze is 9 copper ingots plus 1
tin ingot for 10 bronze ingots. Weapon-grade steel is 497 iron ingots plus 3
coal units for 500 steel ingots (0.6% carbon by mass). Every transformation
supports batches ×1, ×10, ×100 and ×1000. Metals and alloys require the Forge;
fabrics, rope and leather require the Sewing Machine; both branches also
require the connected Workbench.

All crafted equipment shares one finish rule. Silver configurations consume
extra silver ingots equal to 10% of final item weight. Gold configurations
consume extra silver equal to 20% and gold equal to 10%. Quantities use the
existing 0.001-weight material unit and round upward; decorative metals never
increase the finished item's recorded weight.

Seventeen supplied 128×128 sprites cover raw copper/tin/iron/silver/gold,
bronze/steel/silver/gold ingots, wool, cotton, raw silk, plant fiber, rope and
the three hides. Existing copper/tin/iron and coal assets remain authoritative
for their earlier catalogue entries. MAP01 keeps the accepted 544 vertices,
730 linedefs, 1,430 sidedefs and 159 sectors and now contains 221 Things.

No AI, detection, combat, MAP02 or mansion geometry changed in this increment.

## Character-first menu, equipment finishes and eastern stair walls 4.29.0z

**Implemented and exercised in GZDoom 4.14.2; focused manual visual/save validation pending**

Successful Caelum weapon pickups now select, equip and activate the collected
configuration automatically when its size matches the character and the item
remains in personal inventory. Overweight pickups routed to the Magic Box and
incompatible sizes retain their normal storage behavior instead of being
forced onto the player.

The focused runtime test collected a silver sword, then a silver Water staff:
both became the active native selector and the staff ended on
`CaelumWaterStaffT2Weapon`. A deliberately incompatible crossbow was collected
without replacing that active staff.

The numeric equipment grade remains stable in saves and formulas but is no
longer presented to the player as T1/T2/T3. Weapons, essence implements,
shields, armor, amulets and seals use their base name, then localized silver
and gold finishes. Crafting and inventory navigation call the same finish a
finish/acabado. Processed components are labelled as item materials, while
wood, iron/copper/tin ingots, coal and raw gems keep their raw-resource names.

The main list menu is now text-based and uses `CaelumText` for New Character,
Load Character, Save Character, Options and Quit. Doom's five skill presets
are cleared and replaced by one neutral Caelum mode, so GZDoom starts MAP01
without showing a difficulty page. New Character still creates the player in
MAP01 and immediately opens the full-screen Caelum creation wizard; Load
Character uses native save loading. A stock PK3 cannot replace the hardcoded
`NewSmallFont` used by native OptionMenu rows, so Controls/Options keep the
engine font until those menus are reimplemented or a project executable is
maintained.

MAP01 adds an 8-MU-thick U around the eastern stair pair at x=1306..1697 and
y=-391..391. The three wall volumes use the existing tag-511 3D wall control
from z=128 to 256, leaving the twelve treads, continuous roof and central access
unchanged. Structure is 544 vertices, 730 linedefs, 1,430 sidedefs, 159 sectors
and 220 Things; SHA-256 is
`700a1f2c5bd7e99b2d36f5e3a033809301e58022836ee34880dd6f94f90dfae4`.

The raw sprite audit found ready assets for wood, iron/copper/tin ingots, coal
and raw ruby, sapphire, emerald, topaz and opal. Original raw/ingot sprites for
silver and gold are still required. A bronze sprite is required only if bronze
becomes a persistent intermediate item rather than consuming copper and tin
directly. No raw-resource conversion recipes are introduced in this patch.

## Shield recipes, empty new-profile book and stair cover 4.29.0y

**Implemented and structurally validated; focused runtime/save validation pending**

The unified Workbench catalogue now contains 65 recipes. Four appended shield
entries preserve all prior indices and craft Buckler, Kite, Tower and Magic
Shield configurations for every tier and size. Each transaction consumes its
named tiered plate plus a tier-1 strap, using the existing physical 70/30
plate/strap weight split. Every shield tier requires a connected Workbench,
Forge and Anvil; tier 3 additionally retains the cumulative Master Bench rule.
The result is a real `CaelumShieldPickup`, is registered persistently and is
routed unequipped to the Magic Box like the other crafted equipment families.

Recipe-book schema version 2 changes only new-profile policy. A newly created
character starts with zero known recipes. Existing 4.29.0x saves preserve their
exact 61 knowledge flags, while the four appended shield recipes begin locked.
Older committed development profiles retain the 61 recipes that were open
before knowledge existed. `LearnPhysicalWeaponRecipe(catalogueWeaponId)` gives
the tutorial/NPC layer a stable way to unlock exactly the starter weapon chosen
by the player; no provisional NPC dialogue, task or reward sequence is claimed
by this patch.

All twelve bitmap font families are rerasterized at twice their physical
resolution and declare `Scale 2`, preserving their established logical height,
advance, spacing and UI layout. MAP01 assigns the same roof-only tag used by the
other flights to the twelve eastern stair sectors. Structural counts remain
536/718/1,406/156/220 and MAP01 SHA-256 is
`1223bafec960be9c14018af07867e6ec2e216975f1c44b0415ff4002973c51de`.

The focused runtime pass must confirm: a new profile reports 0/65; an existing
4.29.0x save keeps its former known recipes; each shield stays hidden until
learned, requires Forge plus Anvil even at tier 1, consumes the displayed plate
and strap amounts, and reaches the Magic Box with correct tier/size/durability;
and the eastern stair pair is covered without blocking either ascent.

## Persistent recipe book and unified filters 4.29.0x

**Implemented and structurally validated; manual runtime/save validation pending**

The Workbench remains the only authoritative catalogue and transaction. Its 61
recipes are now browsed through six views: All, Physical Weapons, Armor, Essence
Weapons, Amulets and Seals. `Tab`/controller Y changes the family; Left/Right
cycles only entries in the active family. Tier, size, materials, box routing and
cumulative station requirements retain their existing code paths.

`CaelumPersistentCharacterState` stores one knowledge flag per unified recipe
and a recipe-book schema version. Schema-0 development profiles initialize as
version 1 with all recipes known, preserving the access current saves and tests
had before recipe knowledge existed. An unknown entry appears without its name, weight or components and is
rejected before either material spawning or the crafting transaction can run.
`CaelumPlayer.LearnCraftingRecipe(index)` is the shared authoritative entry point
for later sheets, merchants, NPC dialogue and discoveries.

The Journal Crafts page is no longer provisional: it reports known/total counts
for all 61 recipes and for the 16/16/20/4/5 family split. It remains read-only;
crafting still requires Use on a valid connected station. Runtime commands for
this isolated test are:

- `ca_debug_crafting_forget_all_recipes`
- `ca_debug_crafting_learn_selected_recipe`
- `ca_debug_crafting_learn_all_recipes`

This increment changes no recipe formula, balance value, map, AI, perception or
combat behavior. Final starting recipes are deliberately unresolved rather than
inferred from class or profession.

## Accepted MAP01 corrective follow-up 4.29.0w

**Implemented and manually accepted**

The author confirmed that the eight actual stair-side gaps are covered. Rear
landings remain under the continuous roof and the upper western canopy is
supported by two solid 8×8-MU columns that do not narrow the gate opening. This
acceptance closes the focused MAP01 correction and does not reopen MAP02 tests.

## Final endurance acceptance and MAP01 correction 4.29.0v

**Implemented and structurally validated; one focused MAP01 manual retest remains**

The supplied `ca_physics_4_29_0u_final.log` closes both remaining diagnostic
tests. Its first MAP02 session produces 1,033 consecutive reports, equivalent
to 17 minutes 13 seconds of simulation inside an approximately 22-minute-
36-second file window. The log cannot timestamp the boundary between its two
sessions, so it cannot assign exact real seconds to the first one alone; the
combined timing, uninterrupted telemetry and the author's live observation
are sufficient to accept the requested approximately twenty-real-minute run.

All 16,608 combat actors remain present and all 1,983 active AI actors reach a
target. The group-16 split stays fixed at 126 leaders and 1,749 followers.
Admitted native Chase totals 93,211 calls, averages 90.2 per simulated second,
peaks at 146 per second and at nine in one tic, below the ten-call budget.
Custom contacts, maximum contacts, callbacks, duplicate callbacks and retained
references remain zero in every report. At most one projectile is live; all 26
spawned projectiles impact and are destroyed, with no expiry or failure.

The second MAP02 session is the short Quintaessence release test. Its affected
population peaks at 2,086, then descends to zero across eleven nonzero reports
and remains zero for seven further reports. The author observed a slight frame-
rate reduction only when releasing the black hole. FPS itself is not recorded,
but the bounded population and clean terminal counters show a transient density
cost rather than a persistent leak or freeze. Repeated simultaneous releases
may be optimized later; they do not block this acceptance.

MAP01 incorporates the corrections found during the manual V4.29.0u walk.
The 128-MU upper western opening now contains two 64-MU sliding leaves at
height 136 MU. They share new group 912 and remain independent of ground-floor
group 808. Eight narrow joints beside the four stair modules and all four
landings now use the complete tag-510 floor/roof volume. The twenty-four real
stair sectors keep tag 515, so their ascent remains open and only their overhead
cover is added. The resulting map has 516/690/1,350/146/220 structural counts
and SHA-256 `cd285dcebe7b92245ec42851ef988fe35849e0be7d0d1f618682b117dbb4c70d`.

The future auditory allowance is now fixed as:

`HearingAllowanceMU(L) = (50 + L) × [1 + 2L(L + 1) / 10100]`

where `L` is effective Perspicacity from 0 to 100 and the bracket is its Type-4
multiplier from x1 to x3. The allowance is 50 MU at level 0, about 84.7 at 25,
150.5 at 50, 266.1 at 75 and 450 MU at 100. Final hearing reach is planned as
`dB² / 4 + HearingAllowanceMU`; listener height is excluded. Target height
remains relevant only to visual exposure. This formula, native `SoundAlert`
propagation and the dynamic faction/species group controller remain planned;
V4.29.0v contains no new perception ZScript.

### V4.29.0v runtime procedure

Only MAP01 needs another test because V4.29.0v changes no runtime code or
MAP02 content. From both sides, use the upper western portón and confirm that
its two halves retract in opposite directions, close normally and do not move
the ground-floor gate. Walk all four staircases and their landings without
`noclip`; verify continuous floor at every one-MU joint, no hole in any landing
and continuous cover above all four landings. Confirm that no added slab blocks
the climb or closes a real stair shaft. Finally recheck the western threshold,
interior roof and uncovered eastern balcony. The accepted MAP02 endurance and
single-release Quintaessence tests do not need repetition for this map-only
patch.

## Accepted squad margin and first-floor enclosure 4.29.0u

**Implemented and structurally validated; manual MAP01 traversal and one final mixed endurance run remain**

The two requested V4.29.0t comparisons both remained responsive. Group 16
produced 1,087 complete telemetry intervals, or 18.1 simulated minutes; group
8 produced 995, or 16.6 simulated minutes. Both preserve 16,608 combat actors,
1,983 active AI actors and eventual target acquisition by every active actor.
Contacts, maximum contacts per actor, custom callbacks, unique/duplicate
callbacks and retained references remain exactly zero. Live projectiles stay
between zero and two and no projectile spawn failure is reported.

Group 16 uses 126 leaders and 1,749 followers. After acquisition its native
Chase execution averages 85.8 calls per simulated second and peaks at 121.
Group 8 uses 230 leaders and 1,645 followers, averages 164.7 and peaks at 243.
The latter nearly doubles the admitted movement work while preserving the same
active population and target coverage. Group 16 is therefore retained as the
baseline for the future formation controller. The result is not evidence that
16 is a universal gameplay formation size: authored formations may subdivide
visually while sharing a smaller set of movement owners.

MAP01 now closes the first-floor shell needed before authoring a second floor.
The complete western 96×192-MU gap behind the main threshold receives the
128–136-MU floor slab and the 256–264-MU roof slab. A 128-MU opening aligned
with the entry remains traversable. Finite walls connect the northern and
southern wings at the west and east. At the east, the wall stays inside a
96-MU continuous balcony; its connecting floor remains exterior and uncovered.
Every newly enclosed central strip, existing upper door threshold, stair tread
and landing receives the required roof without duplicating the pre-existing
tag-100 landing floor.

The perception design was also reconciled during this audit, but remains
deliberately separate from runtime code. Its accepted base curve is
`1000 / (1 + 9(d / 20 m)^2)%`, with values below 1% treated as zero. Sight uses
current height/1.8 m and a 60-degree core fading quadratically to zero at the
120-degree limit; hearing uses total mass/100 kg in 360 degrees. Perspicacity
scales from x1 to x2 and Stealth multiplies both channels by
`1 - Stealth/100`, including complete visual and auditory concealment at 100%.
Walking, running and crouching emit x1, x2 and x0.5 movement noise. Visual
checks will be phased at one per NPC per second and hearing will be event
driven. The exact angular convention —full aperture or half-angle— remains an
author decision and must be settled before implementation. V4.29.0u still
uses the legacy V4.26.4 movement `SoundAlert` and diagnostic/native target
acquisition.

The generated WAD contains 516 vertices, 690 linedefs, 1,350 sidedefs, 146
sectors and 218 Things. Its accepted SHA-256 is
`cd5db426b51570a2a4715223cd0a6bb8afb9373192b67d64fe7263371bcf7d9b`.
The constructor is deterministic and refuses any base other than the accepted
4.29.0t MAP01.

### V4.29.0u runtime procedure

In MAP01, cross the main threshold without `noclip`, walk the whole new western
vestibule and pass through its centered opening. Traverse every old/new floor
seam, all four stair landings and every upper door. Confirm that the eastern
balcony is 96 MU wide, walkable, exterior and open to the sky; the interior
side must be closed by the finite east wall. Finally use `fly` or `noclip` only
for inspection and verify that the complete enclosed portion has a continuous
roof suitable as the next floor base.

In MAP02, perform one final 20-real-minute group-16 run with Look, Chase and
attacks enabled, including ordinary player movement through the main field but
without Quintaessence. A separate short Quintaessence density test belongs to
collision calibration and must not be mixed with this AI endurance result.

## Accepted squad endurance and AirCapacity audit 4.29.0t

**Implemented and structurally validated; one repeated manual endurance run remains recommended**

The supplied `ca_physics_4_29_0s.log` completes 1,328 internally consistent
telemetry reports without a stop, approximately 22 simulated minutes. It keeps
16,608 combat actors alive and reaches targets on all 1,983 active AI actors.
Custom contacts, collision callbacks, maximum contacts per actor and retained
contact references stay at zero for the entire run. Live projectiles remain
between zero and one and continue reaching their bounded destruction path.

With groups of 16, admitted native Chase averages 96.6 calls per simulated
second and peaks at 161, versus the previous saturated ~350. This is 7.1 times
longer than the failed 148-report V4.29.0r run and is the strongest controlled
result so far. It does not prove which internal branch of `A_Chase`/`TryMove`
produced the abrupt stalls; it does establish that actor count, target count,
custom contacts and projectile retention are not sufficient causes. Production
AI should therefore retain shared squad goals, distance/sleep tiers and a small
number of movement owners instead of restoring independent pursuit to every
member.

The V4.29.0s telemetry accidentally included 13,125 passive field bodies in
the squad totals. V4.29.0t corrects only that report path. The expected active
line is `escuadras_activas tamano=16 lideres=126 seguidores=1749`; gameplay
behavior is unchanged.

MAP01 restores the four requested finite leaves at the end-of-corridor room
connections: groups 906–909. No geometry changed, and the output is
byte-identical to the previously validated 4.29.0r map. Groups 902/905 and the
double front entrances 910/911 also remain.

The inherited engine property `Player.AirCapacity` is not Caelum's HUD meter.
GZDoom defines it as a multiplier for the native underwater air supply and it
remains at its default value of 1. Caelum separately stores `CurrentAir`,
derives `MaximumAir` from the 1,000-unit base and Resilience, spends it on
running/jumping/combat/blocking and refills it over the authored eight-minute
cycle. A future underwater rule must either make `CurrentAir` authoritative or
explicitly keep breath separate; merely copying the maximum into
`Player.AirCapacity` would leave two unsynchronized resources.

### V4.29.0t runtime procedure

Run one clean MAP02 repetition with the same group size 16 for at least fifteen
real minutes. Confirm `126/1749`, nonzero follower pulses, zero custom contacts
and bounded projectile counts. A second high-value comparison changes only
`ca_diag_mass_squad_size` to 8; it should report 230 leaders and 1,645
followers. This measures the scalability margin without returning immediately
to the unsafe one-agent-per-actor path.

In MAP01, test the four end-of-corridor leaves 906–909, the two middle divider
doors 902/905 and the two double front entries 910/911. No room contour needs
to be reaccepted.

## Leader/follower pursuit isolation and canonical character art 4.29.0s

**Implemented and structurally validated; manual GZDoom endurance and visual acceptance pending**

The supplied `ca_physics_4_29_0r.log` contains 148 complete telemetry reports
before the same abrupt stop. Its stable invariants are decisive: 13,125 passive
fillers are already outside the blockmap, all 1,983 active AI actors have a
target, custom contacts/callbacks/references remain zero, and live projectiles
stay between zero and two. The final report is ordinary rather than a rising
curve. Passive blockmap enumeration, projectile accumulation and the custom
contact graph are therefore not sufficient causes. The remaining common path
is repeated native `A_Chase`/`TryMove`, whose internal work can vary sharply by
actor position even under the ten-call-per-tic gate.

V4.29.0s isolates independent movers rather than lowering the same global
number again. The 1,875 active main-field actors form deterministic diagnostic
groups of 16. Exactly 126 are leaders and 1,749 are followers in the current
field; leaders can use the existing
13-phase Chase plus ten-call ceiling. Followers retain perception and targets,
but only face their target on a phased 64-tic pulse; they do not request native
movement or range/attack checks. The new telemetry line reports group size,
leader/follower counts and pulses. This affects only the MAP02 main field.

MAP01's four side portals were already valid geometry; only their finite door
Things were embedded unnecessarily in the wall thickness. Groups 906–909 are
removed without touching a vertex, linedef, sidedef or sector. The divider and
front-entry groups 902, 905, 910 and 911 remain. The final structure is
468/587/1,144/101/214 for vertices/linedefs/sidedefs/sectors/Things.

World pickups no longer maintain a stale second art catalogue. `TEXTURES`
maps all ordinary equipment, ammunition, consumables, materials and jewelry
directly to the 128×128 icon masters and applies world-only scale. The PK3 omits
the superseded legacy directories. Domingo contributes 39 gameplay frames and
is now CaelumPlayer's third-person/world appearance; unused banners, blood,
faces, weapon cutouts and slash effects are not loaded.

### V4.29.0s runtime procedure

Set all mass CVars before loading MAP02, including
`ca_diag_mass_squad_size 16`. Warp to the main field and move through it for at
least fifteen real minutes. The squad line must show `lideres=126`,
`seguidores=1749` and nonzero follower pulses; admitted Chase must fall
well below the old constant 350 calls per simulated second. Do not invoke
Quintaessence in this run. If it remains stable, repeat from a fresh map with
group size 1 only as a short A/B confirmation.

In MAP01, cross all four side connections and confirm that no visible or
invisible leaf remains, then test the divider and front doors. Inspect pickups
from every major category for updated art and correct floor scale. Use a
third-person view to inspect Domingo standing, moving, attacking, crouching,
taking Pain and dying.

## Blockmap-isolated endurance candidate and final central entries 4.29.0r

**Implemented and structurally validated; manual GZDoom endurance and visual acceptance pending**

The supplied `ca_physics_4_29_0q_C.log` ends after 193 complete telemetry
reports. Every final report is internally consistent: 16,608 combat actors,
1,983 active AI actors with targets, 10 admitted native Chase calls per tic,
350 per simulated second, zero custom contacts/callbacks/references and zero
live projectiles. The stop is abrupt and the preceding V4.29.0p full-combat run
survived 548 reports with the same settings. Ten calls is therefore not a
universal safety boundary and no monitored gameplay object grows toward the
failure.

V4.29.0r changes one spatial property. The 13,125 passive fillers of the main
15,000-actor field are still visible and still exist as lightweight actors,
but are omitted from the native blockmap. The 1,875 active field actors remain
linked and continue using the same Look, Chase and attack settings. The three
500-rat Quintaessence rooms explicitly re-enable blockmap membership, so their
collision tests are unchanged. If the endurance run now remains stable, native
movement was spending pathological time enumerating passive blockmap residents;
if it still stops, independent `A_Chase`/TryMove work remains sufficient.

MAP01 receives the only missing entrances approved by the author. Each central
T room now has a 128-MU front portal and two normal 64-MU sliding leaves:
group 910 at Y=196 and group 911 at Y=-196. The doors align at X=336 and 400,
matching the established double-door layout. No room footprint, divider,
connection, stair, balcony passage or 119×119-MU landing moves. The resulting
map has 468 vertices, 587 linedefs, 1,144 sidedefs, 101 sectors and 218 Things.

The graphics recomposition is integrated selectively by runtime use. All 137
inventory, equipment, crafting and elemental icons now use the supplied
128×128 masters. Rulo, Ronnie, Argento and Caella each provide 48 directional
A–F frames and six common G–L death stages on 256×256 RGBA canvases. Explicit
baseline offsets and actor scales preserve the previous world height. This
patch does not import preview sheets, unused sewer/Domingo art or the package's
unchanged/Doom-compatible preservation copies. Pre-existing compatibility
lumps are unaffected. The permanent sizing rules are documented in
`docs/GRAPHICS_SIZE_GUIDE.md`.

### V4.29.0r runtime procedure

Load MAP01 and test both new double entrances from the central corridor and
from inside each room. Confirm that both leaves open, that the complete 128-MU
threshold is passable, that closing does not crush the player, and that the
central divider and side-room connections behave exactly as before. Inspect
Rulo, Ronnie, Argento and Caella from all eight directions, then trigger their
attack, Pain and complete Death states; no frame may jump vertically, float,
clip or revert to the previous artwork.

For MAP02, keep the same Look 7/20, Chase 13/10 and full-combat settings. The
first report must show `ligeros=16500 blockmap=3375 visuales=13125`. Move among
several positions in the main field for ten real minutes. This is one controlled
comparison; do not change the budget or run Quintaessence during it.

## Connected upper rooms and stable 10-call load 4.29.0q

**Implemented and structurally validated; manual MAP01 door acceptance pending**

The supplied V4.29.0p pair validates the reduced scheduler gate. Test A runs
for 368 complete reports with mass attacks disabled; test B immediately reloads
MAP02 in the same process and runs for 548 with full combat. Both acquire all
1,983 field targets, cap native Chase at 10 calls per tic and 350 per simulated
second, and retain exactly 16,500 lightweight actors. Contacts, callbacks and
contact references remain zero throughout.

Test B spawns 40 bounded projectiles and records all 40 impacts/destructions,
never retains more than one live missile and reports no spawn failure. It also
reaches 502 targets within 512 MU, whereas the failed V4.29.0p input run reached
only 175 before stopping at a 20-call gate. Local actor density and projectiles
therefore cannot be sufficient causes of the abrupt freeze. The variable that
still tracks stability is the number of native `A_Chase`/movement queries
admitted in one world tic.

MAP01 keeps the accepted two continuous T rooms. The old extreme-room openings
spanned Y=304..432 and Y=-432..-304; after the T reconstruction only 41 MU of
each opening actually overlapped a shared room wall. V4.29.0q closes those
obsolete portals, then creates four exact 64-MU connections at Y=400..464 and
Y=-464..-400. Each connection crosses both 8-MU wall rings and receives one
finite sliding leaf, groups 906–909, which retracts into the longer rear wall.

The original central dividers remain at X=364..372. Their 64-MU openings and
door groups 902/905 are validated rather than duplicated. All four 119×119-MU
landings, stairs, room footprints and the previous 210 Things remain fixed;
only four connection doors are added. MAP01 now has 460 vertices, 575 linedefs,
1,120 sidedefs, 99 sectors and 214 Things.

### V4.29.0q runtime procedure

In MAP01, open every new door from both sides and wait for it to close. Cross
each threshold while the door is open, stand in it through the close timer and
confirm the anti-crush hold. Walk the formerly open lower portions of all four
extreme-room walls and confirm they are now solid. Test both central divider
doors and all four stair landings without `noclip`.

For the final 10-call endurance gate, use full combat and move the player among
several points of the mass field for at least eight real minutes. This tests
reconvergence and different blockmap paths. Do not increase the Chase budget;
the next architectural step after acceptance is distance-tiered or shared
squad scheduling, not searching for the highest unsafe count.

## Continuous central rooms and lower pursuit gate 4.29.0p

**Implemented and structurally validated; manual GZDoom acceptance pending**

The V4.29.0o endurance file contains 119 complete telemetry intervals before
the abrupt stop. All 1,983 active AI actors had targets; custom contacts,
callbacks and retained references remained zero; the lightweight population
remained exactly 16,500 and live projectiles stayed between zero and one. The
last complete interval admitted 20 native Chase calls per tic and 699 during
the simulated second. No monitored counter grows toward the stop.

This invalidates 20 as a universally stable diagnostic ceiling. More
importantly, it reproduces the exact 119-report duration previously observed at
40 calls with main-field attacks disabled. Attack delivery, guided projectile
logic, custom collision and RPG helper objects are not necessary causes. The
shared active path is native `A_Chase` and spatial convergence. The next gate
therefore uses a hard default of 10 Chase calls per tic (350 per simulated
second at most), while Look remains at 7 phases and 20 calls per tic.

MAP01 is reconstructed from the accepted V4.29.0i/0n hash. The four separate
V4.29.0o blocks are not merged or patched. Instead, the old north and south
central contours are removed completely and rebuilt as two continuous T-shaped
rooms. Each room absorbs both rear wings, uses one tag-510 floor/roof component
and one tag-511 wall component, and has no residual seam at X=192 or X=544 in
the rear bar. The original middle dividers and their 64-MU door openings are
recreated after the continuous rooms.

The internal stairs still end at Y=±272. Their room fronts remain at Y=±391,
so the four reserved landings remain exact independent 119×119-MU squares.
Side rooms, six stair flights, passages and all 210 Things retain their accepted
positions. MAP01 contains 448 vertices, 559 linedefs, 1,088 sidedefs and 99
sectors.

### V4.29.0p runtime procedure

Set all server CVars before loading MAP02. First run Look and Chase with
main-field attacks disabled for five real minutes at Look 7/20, Chase 13/10.
Only if it remains responsive, start a fresh MAP02 load with attacks enabled
and repeat for five real minutes. The first report must literally show
`chase ... cupo/tic=10`; stop any invalid run. Do not increase the budget.

In MAP01, enter both T-shaped rooms with `noclip`, then disable `noclip` and
walk their entire inner floor, both halves and the two central door openings.
Walk all four green-reserved landing areas and verify that no invisible surface,
wall seam or fall-through remains. Existing side rooms and stairs must behave
as in V4.29.0n.

## Four closed upper blocks and stable pursuit boundary 4.29.0o

**Implemented and structurally validated; manual MAP01 acceptance pending**

The two V4.29.0n logs validate the reduced pursuit ceiling under both required
loads. The no-attack session supplies 319 complete telemetry reports and the
full-combat session supplies 506. Both reach all 1,983 target-bearing AI actors,
hold native Look and Chase peaks at 20 per tic and Chase throughput at 700 per
simulated second. Contacts, callbacks and references remain zero. The enabled
run retains at most two bounded projectiles. No counter trends toward a stop,
so 20 is now the accepted diagnostic ceiling; 40 remains rejected.

MAP01 retains the complete V4.29.0i/0n rooms and inserts four new closed blocks
only in the two gaps between rooms on each side of the central passage. Their
outer footprints are 313×153 MU; 8-MU native wall rings leave 297×137-MU
interiors. The north façades begin at Y=391 and the south façades at Y=-391.
Because the internal stairs end at Y=±272, each one retains an exact 119-MU
setback and a separate 119×119-MU landing aligned to its 119-MU flight.

The blocks end at Y=±544 and use the full available rear depth without moving
an accepted room. They are individual tag-510/tag-511 components, not another
continuous-row reconstruction. Existing side openings and door actors are not
repurposed, and every new block remains physically closed until the author
specifies its connections. MAP01 now has 454 vertices, 569 linedefs, 1,108
sidedefs, 107 sectors and 210 Things.

### V4.29.0o runtime procedure

Load MAP01 and inspect all four new blocks from roof level, ground level and
inside with `noclip`. Walk every 119×119 landing and the central passage without
crossing an invisible wall, falling through a surface or entering a new block.
Confirm the six stairs, existing rooms and all prior doors still behave exactly
as in V4.29.0n. Connections are deliberately absent.

For AI endurance, keep the accepted 7/20 Look, 13/20 Chase and 64-phase attack
settings. Run one three-load sequence with full combat: five minutes in MAP02,
reload MAP02, repeat, then reload once more and repeat while changing the
player's position. This tests map cleanup and repeated convergence; do not raise
the Chase budget above 20.

## MAP01 rollback and pursuit isolation 4.29.0n

**Implemented and structurally validated; manual GZDoom acceptance pending**

MAP01 is restored byte-for-byte to V4.29.0i, the accepted state immediately
before the continuous-room expansion. This rejects the complete V4.29.0l and
V4.29.0m geometry passes instead of trying to repair their overlapping walls,
missing landing space and open surfaces. The restored map has 398 vertices,
489 linedefs, 948 sidedefs, 99 sectors and 210 Things. Its valid divider and
rear-door additions remain; none of the later enlarged rows remains.

The four supplied V4.29.0m logs also correct the previous runtime assumption.
The server CVars entered after `map map02` were not live; their effective value
appeared on the next map load. Consequently the runs actually were: all
enabled for 34 reports, all disabled for 249, Look-only for 495, and Look plus
Chase with main-field attacks disabled for 119. Only the last run stopped.
Its final report retained zero contacts and callbacks, 16,500 lightweight
actors and a 40-update Chase peak. The isolated-room actors explain its single
projectile; the main field explicitly reported `ataques_masivos=0`.

This isolates sustained native pursuit/convergence as the next boundary. The
diagnostic Chase ceiling is reduced from 40 to 20 calls per tic. The scheduler
captures server settings once per map, and state actions no longer copy every
setting on every Look, Chase or attack attempt. This is both a stricter test
and a universal hot-path optimization for the diagnostic. Gameplay maps and
the nine isolated MAP02 rooms remain unchanged.

### V4.29.0n runtime procedure

Enter every server CVar before `map map02`. The first report after loading is
the authority; do not continue if its active flags differ from the requested
test. Run Chase without attacks for five real minutes. Only if it remains
responsive, repeat with attacks enabled. Both tests use Look 7/20, Chase 13/20
and attack stagger 64. If the first test freezes, stop there and repeat later
with a Chase budget of 10 instead of enabling attacks.

In MAP01 verify only the rollback: both central pairs, their middle divisions,
rear first-floor doors, balcony strips and stair landings must match V4.29.0i.
Do not extend or connect rooms in this patch.

## Live mass-AI controls and straight landing corridor 4.29.0m

**Implemented and structurally validated; manual GZDoom acceptance pending**

The three V4.29.0l logs stop after different durations but share the same
stable boundary: 16,608 combat actors, 1,983 active AI, zero custom contacts,
zero callbacks, zero to two projectiles and at most 40 admitted Chase updates
in any tic. No monitored value rises toward the abrupt stop. However, the two
intended disabled sessions did not actually disable their systems: the console
changed the CVars after the actors had cached their initial `true` values.
Consequently all three files are enabled-Chase samples, not a valid A/B result.

V4.29.0m moves those settings into `CaelumMassAIScheduler`. It reads CVars once
per world tic and every field actor reads only cached coordinator fields.
Look, Chase and attacks can now be changed while MAP02 is running, and the
telemetry shows the effective state on the next line. Look also receives a
hard default ceiling of 20 native calls per tic; Chase remains capped at 40.

The variable abrupt timing, stable counters and very large fixed ZScript object
graph make a collector/main-thread pause more plausible than contact or missile
growth. The diagnostic-only population is therefore lightweight: 16,500
mass/passive stress actors keep native thinker/state execution but do not own
permanent anatomy, armor or elemental-state objects and do not run the complete
Caelum RPG/contact Tick. The isolated test actors and all normal-map NPCs retain
the full model. Telemetry reports both lightweight and remaining helper counts.

MAP01 replaces the stair-shaped room fronts with straight façades at Y=±368.
Since all six upper landings end at Y=±272, the path between stairs and rooms is
exactly 96 MU and uninterrupted. Front doors move to Y=±372; middle doors move
to Y=±456. The rear balcony keeps its existing 96-MU offset, all stair modules
remain 119 MU wide and lateral room divisions stay closed for the next gate.

The colored HUD resource fills are manually accepted.

### V4.29.0m runtime procedure

Run four fresh MAP02 sessions: all three systems disabled; Look only; Look plus
Chase; then full combat. CVars are live, so a valid report must literally show
`look activo=0/1`, `chase activo=0/1` and `ataques_masivos=0/1` as requested.
The lightweight line should report approximately 16,500 actors and only the
isolated-room population should retain helper objects. Look peak must stay at
or below 20 and Chase peak at or below 40.

In MAP01 walk the full corridor behind every staircase, then inspect both
façades and roofs from above and below. No wall return may point toward a
landing; the front and rear balcony gaps must both measure visually alike.

## Bounded chase, colored HUD fills and continuous room rows 4.29.0l

**Implemented and structurally validated; manual GZDoom acceptance pending**

The supplied V4.29.0i log freezes after approximately 120 reported seconds
with 1,605 target-bearing actors and roughly 1,924 real `A_Chase` executions
per second. Contacts and custom callbacks remain zero, only four projectiles
are alive and no attack is accepted in the final interval. Every family reaches
a similar target saturation; rats dominate only because they are the largest
population. The earlier V4.29.0h run survived more cumulative Chase calls, so
the actionable boundary is concurrent native pursuit work rather than a simple
per-call memory leak.

V4.29.0l keeps dormant perception at seven phases and moves pursuit to an
independent thirteen-phase schedule. One registered `CaelumMassAIScheduler`
also caps the whole field at 40 admitted Chase calls per tic. Each actor caches
the handler and all CVar values once in `PostBeginPlay`. `ca_diag_mass_chase_enabled`
provides a target-retaining, no-movement control. Telemetry now reports the
actual peak per tic, phase/budget/pause deferrals, family updates and target
distance bands.

MAP01 no longer consists of six isolated room rectangles. The two first-floor
rows are clean, disconnected components of one tag-510 interior and one
tag-511 wall sector. Their fronts remain at Y=±192, preserving 96 MU of balcony;
the rooms expand behind the stair landings at Y=±272. Every flight remains
119 MU wide. Closed native dividers yield four rooms per row. Balcony doors
700/716/717/718 and middle doors 902/905 remain; obsolete side leaves
900/901/903/904 are removed until lateral openings are authored.

HUD-01 frames render before 164-MU inset fills, restoring every resource color
without painting over end caps. `CaelumText`, `NewSmallFont`, `SmallFont` and
their alternative small alias use `SpaceWidth 8`; letter kerning and HUD
`CaelumMono` are unchanged.

### V4.29.0l runtime procedure

Run three fresh MAP02 sessions for five simulated minutes each: Chase disabled
and attacks disabled; Chase enabled and attacks disabled; then both enabled.
Use Look 7, Chase 13, budget 40 and attack stagger 64 in all three. A stable
disabled run proves target ownership alone is safe; a stable no-attack Chase
run validates the native pursuit ceiling; the final run restores combat.

In MAP01 inspect all eight rooms, both balcony edges and all six stair modules
from above and below. Lateral dividers are expected to be closed. No room floor,
landing or exterior strip may be missing, collision-solid but invisible, or
crossed by a coincident wall.


## Cached perception scheduling, MAP01 doors and UI foundation 4.29.0i

**Implemented and structurally validated; manual GZDoom acceptance pending**

The stable V4.29.0h run shows that chase/attack phase separation can keep the
1,875 active actors responsive. V4.29.0i moves the remaining dormant cost—the
native `A_Look` scan—behind the same seven-phase schedule. Each main-field
actor captures the three diagnostic CVars and both deterministic phase keys
once at map load. The hot Look, Chase and attack paths therefore contain no
CVar lookup and no coordinate hash. Normal maps and the nine isolated MAP02
rooms execute their original native AI timing.

The monitor now separates Look attempts, updates and deferrals from Chase. At
the default value, a ten-tic Spawn loop admitted once per seven phases yields
one sight check per actor approximately every 70 tics. This is a diagnostic
foundation for the later stealth/group scheduler, not its final alert model:
formations, shared sightings, proximity wake-up and fair group attack tokens
remain future authored behavior.

MAP01 retains the author-accepted central first-floor shells byte-for-byte and
adds only four thin native divider targets around the two existing central
doors. The targets reuse sector 511 and its already working 3D-floor controls.
Four rear-room leaves form two additional double doors without changing room
footprints. Current structure is 398 vertices, 489 linedefs, 948 sidedefs, 99
sectors and 210 Things.

HUD/UI-01 supplies 94 independent runtime PNGs. `CaelumStatusBar` removes the
Doom face/status bar, while the permanent overlay keeps real resource values
and applies modular frames/icons. Tab opens a local six-section Journal and M
preserves the native automap. Inventory ownership and quantities are not
copied into UI storage. Only the existing active weapon/load and twelve
attributes are exposed now; the four not-yet-authored sections state that they
are pending.

### V4.29.0i runtime procedure

Set the diagnostic values before loading MAP02 because actors cache them in
`PostBeginPlay`:

```text
logfile ca_physics_4_29_0i.log
ca_diag_mass_attacks true
ca_diag_mass_ai_stagger 7
ca_diag_mass_attack_stagger 64
map map02
sv_cheats 1
warp 16368 -16 0
```

Run the field for at least three minutes. Do not lower the stagger values in
this candidate. Confirm that `[CA-AI] ... look` and `... chase` each report
attempted/executed/deferred counts, no custom contact graph grows, and input
remains responsive. Separately load MAP01 and validate both new divider walls
and both rear double doors from above, below and on both sides.


## Canonical MAP01 sector ownership and budgeted mass AI 4.29.0h

**Implemented and structurally validated; manual GZDoom acceptance pending**

The V4.29.0g rectangles were topologically closed but twelve of their edges
placed the intended front sector on the geometric left. The lower tag-510
control therefore existed while GZDoom resolved the tagged interior outside
the visible room, producing the photographed hole and ground-floor fall.
V4.29.0h gives both outer and inner contours one clockwise winding: sector 510
is on the right/front inside the room and sector 511 is on the right/front
inside the wall ring. No new surface or control sector was added.

The supplied stagger-3 run froze after its second complete report with 958
target-bearing actors, 16 live projectiles, zero contacts and zero custom
collision callbacks. The last combat interval contained only 57 attempts,
19 projectile spawns and three impacts. The remaining synchronous threshold is
the arrival of 634 rats at melee range and the native chase/collision work
around one player, not projectile retention or the Caelum contact graph.

Only MAP02's main field now uses `THRUACTORS`. Its `A_Chase` invocations are
distributed across seven deterministic phases and its attack deliveries across
64 phases. Rooms 1–9 and all normal maps use the original AI/collision timing.
The monitor reports chase attempts, updates and deferrals separately.

### V4.29.0h runtime procedure

```text
map map02
con_notifytime 10
logfile ca_physics_4_29_0h.log
sv_cheats 1
ca_diag_mass_attacks true
ca_diag_mass_ai_stagger 7
ca_diag_mass_attack_stagger 64
warp 16368 -16 0
```

Run one 60-second session. Do not repeat the rejected stagger values 3, 2 or 1.
For MAP01, load `map map01`, enable `noclip` and verify both central interiors
from below, above, inside and outside before any door or divider is restored.


## Clean MAP01 modules and staggered mass combat 4.29.0g

**Implemented and structurally validated; manual GZDoom acceptance pending**

MAP01's two central first-floor rooms no longer contain any part of the
V4.29.0c–f divider, threshold or door topology. Sixty lines and their 120
sidedefs were removed as one unit. Each replacement now consists of exactly
eight bilateral lines: four around one 336×336-MU interior and four around its
continuous 8-MU wall ring. The working end rooms and the common 3D-floor
controls for tags 510 and 511 were not rebuilt.

MAP02's main field now separates AI stress from island-physics stress. Its
15,000 bodies share a diagnostic species and `THRUSPECIES`; Rooms 7–9 still
retain full collisions for Quintaesencia. When attacks are enabled, the default
`ca_diag_mass_attack_stagger 3` distributes attempts between three deterministic
phases derived from each spawn cell. Straight projectiles and melee actions do
not damage another main-field actor, so one intercepted shot cannot trigger an
infighting cascade. A value of `1` restores the unthrottled V4.29.0f behavior.

The supplied no-attack log reached 1,983 targeted actors and 42,415 collision
callbacks/s without ending at that point. The attack run stopped after the
first second containing 97 projectile spawns and 28 impacts, while only 69
missiles remained live. This makes synchronous attack/impact work and crowd
cross-collision the actionable causes; retained projectiles and contact-list
growth are not required to reproduce the abrupt stop.

The mapping workflow is documented in
`docs/ULTIMATE_DOOM_BUILDER_TUTORIAL.md`. Doors and dividers remain intentionally
absent from the new central shells until visual and traversal acceptance.

### V4.29.0g runtime procedure

```text
map map02
con_notifytime 10
logfile ca_physics_4_29_0g.log
sv_cheats 1
ca_diag_mass_attacks true
ca_diag_mass_attack_stagger 3
warp 16368 -16 0
```

Run for 60 seconds or until a freeze. On a fresh `map map02`, repeat with
stagger values `2` and `1`, in that order, stopping after the first unstable
setting. Do not continue to a more aggressive setting after a freeze.

For MAP01, use `map map01` and inspect both central shells from ground floor,
first floor, exterior and below the slab. Closed walls are expected in this
candidate; doors and the divider are not.


## Continuous MAP01 slabs and isolated mass-AI combat 4.29.0f

**Implemented and load-validated in GZDoom 4.14.2; manual visual/performance acceptance pending**

The V4.29.0e threshold repair still treated the visible room surface and each
door/exterior band as different 3D-floor targets. Their lower and upper
controls could occupy the same height while remaining different render links,
which reproduced the reported solid-but-invisible surface from both the room
and its exterior. V4.29.0f removes that distinction instead of adding another
plane: every former tag-512 target is now tag 510 and therefore uses the same
128–136-MU floor slab and 256–264-MU roof slab as the adjacent room.

The independent 512 control rectangle, its upper duplicate link and an empty
sector inherited from the earlier rebuild are removed. The mansion surface
PNGs are also registered explicitly in flat/texture namespaces rather than
being available only through their sprite aliases. Current MAP01 structure is
510 vertices, 517 linedefs, 1,004 sidedefs, 98 sectors and 206 Things. Every
linedef has a valid front sidedef, bilateral flags agree exactly with back
sides, and there is no target or 3D-floor link 512.

MAP02 keeps all 16,608 combat actors and the exact 1,875-active main-field
stage. One native wall at X=8192 blocks actors, monsters and sight between the
spawn/test-room side and the mass field. GZDoom 4.14.2 runtime loading reports
zero main-field targets at baseline. The new server CVar
`ca_diag_mass_attacks` changes only attack execution inside that field:

- `false`: perception and chase remain active, but melee, Bull charge and
  projectile actions are counted and suppressed;
- `true`: the same actors execute their normal attacks using the existing
  bounded straight projectiles;
- all nine small diagnostic rooms ignore the gate and retain their authored
  behavior.

The monitor now prints family target/active counts and a combat line:

```text
[CA-AI] campo objetivos/activos ratas=0/1250 rulo=0/125 argento=0/125 caella=0/125 ronnie=0/125 toros=0/125
[CA-COMBAT] ataques_masivos=1 intentos/s=0 anulados/s=0 proj +0 impacto=0 vencido=0 destruido=0 fallo=0
```

Counters are integer increments on the existing actors/projectiles; no new
per-tic actor search was added. The MAP02-only monitor still performs its one
aggregate Thinker traversal per second.

### V4.29.0f runtime procedure

Start each logged session from the console:

```text
map map02
con_notifytime 10
logfile ca_physics_4_29_0f.log
```

Wait ten seconds at spawn. Every family numerator in `[CA-AI]` must remain
zero, `ia_objetivos=0` and `proyectiles=0`. Then run two fresh-map sessions:

```text
ca_diag_mass_attacks false
map map02
warp 16368 -16 0
```

and:

```text
ca_diag_mass_attacks true
map map02
warp 16368 -16 0
```

Observe each for 30 seconds or until a freeze. The first run should report
attack attempts under `anulados/s` with `proj +0`; the second exposes the
actual projectile creation/completion rate. The final complete line written
before a freeze is diagnostic evidence even if the failing tic never reaches
the next one-second report.

MAP01 acceptance is independent: walk over both central first-floor rooms,
the exterior bands at their lateral doors and the internal divider doorway;
inspect all six doors from both faces and verify every surface from above and
below. A visually absent but collision-solid band still fails acceptance.

## Central threshold closure and valid MAP02 coordinates 4.29.0e

**Implemented — pending GZDoom 4.14.2 runtime validation**

The supplied screenshots expose two independent construction regressions.
MAP01's four exterior leaves used `arg2=0`: their vertical WALLSPRITE faced the
authored opening, but their blocker row and displacement ran along X,
perpendicular to the wall. MAP01's target tag 512 also received only the lower
128–136-MU slab, leaving its six doorway sectors absent from the 256–264-MU
walkable roof. MAP02 failed before gameplay because Room 7 Things reached
approximately X=-50,288 and Room 8 vertices reached X=-32,800, outside the
engine-supported `-32768..32768` coordinate range.

Current corrections:

- door groups `900`, `901`, `903` and `904` now use `arg2=1`, matching the two
  divider groups `902` and `905`; all six slide parallel to their Y-axis wall;
- linedef 325 applies the existing upper 256–264-MU control slab to target tag
  512, while the original 128–136-MU threshold slab remains unchanged;
- Rooms 7–9 move to centers `(-24000,-18000)`, `(-24000,0)` and
  `(-24000,18000)` respectively;
- each room retains exactly 500 actors and remains 18,000 MU from its neighbor;
- MAP02 now ranges only from X=-24,800..24,576 and Y=-18,700..18,900 for
  vertices, and X=-24,288..24,288 and Y=-18,228..18,228 for Things.

The PK3 builder now checks the coordinate range of every UDMF vertex and Thing.
It rejects the V4.29.0d MAP02 at vertex 56 before packaging and accepts both
current maps. MAP01 remains 514 vertices, 521 linedefs, 1,008 sidedefs, 100
sectors and 206 Things. MAP02 remains 80 vertices, 71 linedefs, 134 sidedefs,
one sector and 16,610 Things.

### V4.29.0e runtime procedure

Start logging before each MAP02 session:

```text
map map02
con_notifytime 10
logfile ca_physics_4_29_0e.log
```

Use a fresh `map map02` before each position:

| Test | Command | Expected Seal count |
| --- | --- | ---: |
| Room 7 — native collision | `warp -24000 -18000 0` | 500 |
| Room 8 — complete Caelum contacts | `warp -24000 0 0` | 500 |
| Room 9 — same-species pass-through | `warp -24000 18000 0` | 500 |
| 1,875-AI main field | `warp 16368 -16 0` | Not a Seal-isolation test |

The fresh-map telemetry baseline should still be approximately
`actores=16608 ia=1983 ia_objetivos=0 objetivos=0 proyectiles=0`.

## Canonical MAP01 side table and bilateral-line repair 4.29.0d

**Implemented — pending GZDoom 4.14.2 runtime validation**

The V4.29.0c MAP01 retained 316 unreferenced sidedefs from removed room
iterations. Although every linedef contained a numeric `sidefront`, the live
references after linedef 420 jumped across those dead index ranges. In
addition, linedefs 461–520 carried `sideback` but did not declare
`twosided = true`. An editor or node builder that normalizes the side table can
therefore reject or reinterpret the later references.

V4.29.0d performs one canonical repair over the complete WAD:

- retain only sidedefs referenced by a live linedef;
- remap every `sidefront` and `sideback` to the compact table;
- require exactly one owner for each sidedef;
- add `twosided = true` to every linedef with `sideback`;
- reject `twosided = true` when no `sideback` exists.

Current MAP01 structure: 514 vertices, 521 linedefs, 1,008 sidedefs, 100
sectors and 206 Things. All 1,008 side references are unique and cover the
continuous range `0..1007`; every linedef has an in-range front sidedef; every
sidedef has an in-range sector; every line with a back side is explicitly
two-sided; and no one-sided line carries that flag. The room geometry, sector
heights, six door Things and their TIDs `900–905` remain unchanged from the
V4.29.0c reconstruction.

`tools/build_pk3.py` now applies these UDMF invariants to every embedded
`TEXTMAP`. It rejects the V4.29.0c MAP01 at linedef 461 and accepts current
MAP01/MAP02 before writing the PK3, so the earlier shallow range-only check can
no longer certify this failure mode.

Manual validation remains authoritative: load MAP01 in GZDoom 4.14.2, confirm
that node construction reports no missing front sides, and inspect both
central pairs plus all six doors from both faces.

## Native central-room rebuild and historical mass-AI replay 4.29.0c

**Superseded structurally by V4.29.0d; MAP02 staging remains current**

The V4.29.0b log contains five fresh-map sessions in the declared order:
Rooms 5, 6, 7, 8 and the main-field center. Its results separate three costs
that had previously appeared together.

| Session | Relevant peak/result | Interpretation |
| --- | --- | --- |
| Room 5 — straight projectile | 4 targets, 18 missiles, 1 callback | The mass-safe projectile route is bounded and adds no sustained contact work. |
| Room 6 — explosive projectile | Targets grow 4 → 199; 18 missiles; 0 callbacks | `A_Explode` propagates damage/targets and infighting even without moving bodies. |
| Room 7 — native Rat collision | 1,103 Seal targets; 240 callbacks once | The test was contaminated beyond its authored 500 Rats. |
| Room 8 — complete contacts | 1,755 Seal targets; 33,232 callbacks; 815 edges; max 12/actor | The room and neighboring populations were pulled together; pair duplication is measurable but bounded. |
| Main center | 2,065 Seal targets; 37,144 callback peak | Density, rather than retained historical edges, is the dominant trigger. |

At the end of the main-center session, after Channel release, the log still
shows 4,718 raw callbacks but only 18 retained edges, `max/actor=4`, 503 unique
pair-tic attempts, 28 duplicates and 4,599 resting rejections. This validates
the V4.29.0b cleanup: the former large retained graph and per-callback object
allocation are no longer the principal post-release cost. GZDoom continues to
report thousands of native collisions while solid bodies remain physically
stacked, so low simulated-time FPS can persist without a logical contact leak.

### MAP01 reconstruction

The finite-panel approach is retired for the two central first-floor pairs.
Each north/south pair is rebuilt in this order:

1. one continuous exterior rectangle from `x=192` to `544`, spanning
   `y=192..544` north or `y=-544..-192` south;
2. one 8-MU native outer wall ring;
3. two interiors divided only by the native `x=364..372` wall;
4. one centered 64-MU door sector in that divider;
5. one centered 64-MU exterior door on each lateral wall.

The four former front doors move to `(196, ±368)` and `(540, ±368)` at angle
0. Internal doors remain at `(368, ±368)`. Their TIDs `900–905`, first-floor
height 136 and sliding-door arguments are unchanged.

The V4.29.0c artifact contained 514 vertices, 521 linedefs, 1,324 sidedefs, 100
sectors and 206 Things. Its geometry and removal of `CaelumFiniteWallPanel`
remain current, but the 316 orphaned sidedefs and missing bilateral flags are
corrected by V4.29.0d.

### MAP02 staged AI and isolated Quintessence rooms

The total main-field population remains 15,000, but it now contains the exact
historical 1,875 active-AI stage:

- 125 Rulo;
- 125 Argento;
- 125 Caella;
- 125 Ronnie;
- 125 Bulls;
- 1,250 active Giant Rats;
- 13,125 remaining passive stress actors.

The active actors closest to `(16368, -16)` are selected deterministically;
the farthest is approximately 3,417 MU from that center. Including Rooms 1–6,
the fresh-map telemetry baseline should be approximately:

`actores=16608 ia=1983 ia_objetivos=0 objetivos=0 proyectiles=0`

`ia` counts living classes that execute perception, chase or attacks.
`ia_objetivos` counts only those active classes with a target. `objetivos`
still counts every actor with a target, including passive bodies affected by
damage; the difference exposes the exact contamination observed in Room 6.

The three 500-Rat matrices keep their collision variants and remain separated
by 18,000 MU. V4.29.0e replaces the invalid V4.29.0c positions with these
in-range console positions after every fresh `map map02`:

| Test | Command | Expected Seal count |
| --- | --- | ---: |
| Room 7 — native collision | `warp -24000 -18000 0` | 500 |
| Room 8 — complete Caelum contacts | `warp -24000 0 0` | 500 |
| Room 9 — same-species pass-through | `warp -24000 18000 0` | 500 |
| 1,875-AI main field | `warp 16368 -16 0` | Not a Seal-isolation test |

Manual validation order:

1. Load MAP01 and inspect both central pairs from every room, corridor, ground
   floor and roof. Confirm continuous walls, correct floors/roofs and all six
   doors opening from both sides.
2. Load a fresh MAP02 and record ten seconds of the baseline above.
3. Run Rooms 7, 8 and 9 separately from a fresh map. Channel Quintessence for
   five seconds and observe twenty seconds after release. Each run must report
   exactly 500 affected actors; otherwise the isolation still failed.
4. Load MAP02 again, use `warp 16368 -16 0`, do not Channel, and let the
   1,875-AI population pursue and attack for sixty real seconds. Record FPS,
   input responsiveness and all three telemetry lines until either stabilization
   or the first abrupt freeze.
5. If this exact historical stage remains responsive, increase later patches
   in the prior sequence: 3,750 → 7,500 → 15,000 active AI. Do not combine the
   stages, because the first failing population is diagnostic evidence.

Validated Seal behavior/formulas, crafting and V4.27 input deferral remain
unchanged.

## Simple mass projectiles and collision hot-path reduction 4.29.0b

**Implemented — pending controlled GZDoom 4.14.2 runtime validation**

The V4.29.0a telemetry rejects the retained-contact graph as the sole cause of
the post-Quintessence slowdown. In the 2,000-actor sample, callbacks reached
approximately 30,000 per reported simulated second and remained high while
the bodies stayed physically stacked, but the retained graph stayed much
smaller. Explosive Argento fire also produced a clear callback increase,
especially after radial damage caused infighting. These are real repeated
native collision events, not merely historical contact references.

V4.29.0b therefore reduces the amount of Caelum work performed for every such
event. A shared pair resolves once per tic; later callbacks only refresh its
liveness. Coincident, separating or effectively resting callbacks return
before body construction, normalization and square root. Every player and
combat actor lazily owns three reusable work objects (`ImpactBody` source,
`ImpactBody` target and `ImpactResult`) instead of allocating them in the
collision hot path. Native collision detection still has an unavoidable cost,
but duplicate callbacks no longer multiply the custom impulse calculation or
temporary-object churn.

Rulo, Caella, Ronnie and Argento now use the mass-safe projectile route. It is
straight, finite-range, single-impact and non-explosive. It preserves the
prepared attack result, critical flag, elemental payload, magical push and
Eloquence-derived maximum range. It performs no seeker target lookup, steering
or radial victim search. The old explosive behavior remains as an explicit
class for authored explosive weapons and the controlled Room 6 comparison.

The MAP02 monitor now writes three `[CA-PHYS]` lines per simulated second. In
addition to actors, targets, missiles, contacts and reference churn, it reports:

- `unicos`: contact pairs on which Caelum actually began one resolution tic;
- `duplicados`: later callbacks for a pair already resolved that tic;
- `reposo`: callbacks rejected as coincident, separating or below threshold;
- `sello_afectados`: actors in the current player's Channel target set.

Rooms 7–9 form an equal three-way Quintessence comparison with 500 passive
Rats in each room:

| Room | Collision configuration | Purpose |
| --- | --- | --- |
| 7 | Native solid collision; Caelum contacts disabled | Native-engine baseline |
| 8 | Native solid collision plus complete Caelum contacts | Exact custom-physics increment |
| 9 | Caelum contacts disabled plus same-species pass-through | Channel scan/force cost without pair collisions |

The original 15,000 passive stress actors remain outside these isolated rooms.
All nine rooms share one valid UDMF sector with 71 linedefs, 134 sidedefs and
no missing front sides.

MAP01 retains its finite-wall architecture. The four central first-floor
panels at `x=368` now all cover 72 MU, and each interior reverse face receives
only a 0.25-MU offset along the panel normal. The previous global X/Y shift
moved an angle-90 reverse face partly along its width and exposed its endpoint
from inside; that diagonal displacement is removed.

Manual validation for this candidate:

1. In MAP01, inspect both central first-floor room pairs from inside and from
   the corridor. The four wall endpoints must remain closed with no flicker or
   duplicate collision surface.
2. Reload MAP02 before each test. Compare Rooms 5 and 6 for thirty seconds;
   Room 5 must use straight single-impact shots, while Room 6 retains the
   intentionally expensive explosion/infighting case.
3. Test Rooms 7, 8 and 9 separately with a five-second Quintessence channel,
   then observe twenty seconds after release. Record FPS and all three
   telemetry lines. Room 8 minus Room 7 estimates Caelum contact cost; Room 7
   minus Room 9 estimates native Rat-to-Rat collision cost.
4. Repeat the 2,000-actor pile once. High raw `callbacks/s` may remain because
   the engine is still resolving stacked solid bodies, but `unicos` must be
   bounded to at most one resolution per pair/tic and custom allocations must
   no longer scale with callbacks.

Validated Seal effects/formulas and crafting behavior are unchanged.

## Bounded contact pressure and controlled MAP02 rooms 4.29.0a

**Implemented — pending controlled GZDoom 4.14.2 runtime matrix**

The reported Quintessence cluster exposed two independent conditions. First,
Giant Rats inherited `THRUSPECIES`, so Rat-to-Rat overlap could not generate
the contact graph required for pressure or crushing. Second, every historical
pair remained in both actors' arrays while its centers stayed inside a broad
release distance, even when the engine had stopped reporting actual
collisions. A converging `A_Chase` crowd could therefore retain increasingly
large arrays and linearly search them on later callbacks.

V4.29.0a removes Rat species pass-through and makes collision callbacks the
authoritative liveness signal. A shared edge expires after five complete tics
without another callback; the existing distance test remains as an additional
release condition. Sustained contact records at most one impulse sample per
tic, sums the real transmitted impulse for 35 tics, and converts that sum back
to its two-body equivalent closing speed for the existing mass/anatomy/impact
pipeline. No fixed walking speed is substituted.

This correction deliberately remains a bounded pair graph. Repeated
action/reaction impulses can propagate through adjacent edges, but the code
does not yet solve every connected member and constraint simultaneously as a
single aggregate-mass island. That larger solver remains conditional on the
results below because a full component traversal could itself increase crowd
cost.

MAP02 preserves the original 15,000 passive actors and adds eight rooms. The
north row is numbered 1–4 west to east; the south row is numbered 5–8 west to
east. Every room uses ordinary two-sided blocking walls, an internal
sight-breaking baffle and an invisible player-passable/monster-blocking
threshold. All 64 linedefs have valid front sides.

| Room | Population | Isolated variable |
| --- | ---: | --- |
| 1 | 25 Rats | `A_Look`/target acquisition only; no chase or attack |
| 2 | 25 Rats | `A_Chase`, native solid collision, no Caelum contacts/attack |
| 3 | 25 Rats | Same chase as Room 2 plus bounded Caelum contacts |
| 4 | 25 Rats | Complete current Rat AI, melee and Caelum contacts |
| 5 | 4 Argento | Stationary shooting; projectile Death omits `A_Explode` |
| 6 | 4 Argento | Identical stationary shooting with normal `A_Explode` |
| 7 | 100 passive Rats | Controlled Quintessence pressure |
| 8 | 500 passive Rats | Larger Quintessence pressure and cancellation load |

The MAP02 monitor writes two `[CA-PHYS]` console lines each second: actor and
target totals, live projectile count, approximate shared contact edges,
maximum contacts held by one actor, collision callbacks per second, and
created/removed contact references. The original passive field is expected to
keep `objetivos=0` and contribute no contacts until physically disturbed.

Manual validation must run each room from a fresh `map map02` load:

1. Record the untouched baseline for ten seconds; contacts and projectiles
   should remain zero and controls must be responsive.
2. Enter Room 1 and wait thirty seconds. If this alone freezes, investigate
   target acquisition/base actor Tick rather than movement or collisions.
3. Repeat separately in Rooms 2 and 3. Room 2 must report zero Caelum contacts;
   any large regression appearing only in Room 3 identifies the custom graph.
4. In Room 4, let all Rats converge, then run directly into the cluster from
   several angles. Verify mass-dependent displacement, pressure damage along
   contacted neighbors, and bounded `max/actor` rather than historical growth.
5. Compare Rooms 5 and 6 for thirty seconds each. A regression unique to Room
   6 isolates explosion/status/area-contact churn from perception and firing.
6. In Rooms 7 and 8, channel Quintessence for five seconds while centered,
   cancel it manually, and record affected count, cancellation response,
   contact peak, `max/actor`, deaths and recovery. Rat-to-Rat contacts and
   some pressure damage are now expected; complete overlap without contact is
   not.
7. Repeat the worst room three times from a fresh map and compare the same
   baseline. If performance degrades while live contacts/projectiles return to
   baseline, inspect allocation/GC or engine caches; if the counters remain
   elevated, inspect the corresponding logical subsystem first.

MAP01, all author-validated Seal effects and crafting behavior are unchanged.
The V4.29 crafting roadmap remains authorized but receives no recipe-content
change in this diagnostic patch.

## MAP01 safe rollback and V4.29 authorization 4.28.0bp

**Seal track validated; MAP01 parallel; V4.29 authorized**

- The author validated Fire, Earth, Air, Water and Quintessence Seal behavior,
  including the corrected element binding, mass response and gravity handling.
- V4.28 Seal mechanics are accepted. Weather extensions remain deferred to
  the Version 5 calendar/weather module as planned.
- The V4.28.0bo MAP01 geometry is rejected because GZDoom's node builder
  reported linedefs 569–590 without usable front sides.
- MAP01 is restored byte-for-byte to the loadable V4.28.0bn version and no
  longer blocks major-version progression. Its large-room reconstruction is a
  parallel architecture task.
- Material and special-item HUD isolation is retained and awaits a short
  pickup regression test.
- The complete V4.27 input matrix is deferred by author decision until the
  crafting system is complete.
- V4.29 Crafting Completion and Persistent Recipe Book may now begin.

## Geometry-native first-floor rooms and material HUD isolation 4.28.0bo

**Rejected — invalid GZDoom node-builder result; superseded by 4.28.0bp**

- Both mirrored central first-floor modules in MAP01 are now large rectangular
  rooms built from UDMF geometry, without finite wall actors.
- Each room has one centered door in its left wall, one in its right wall and
  one in the central dividing wall.
- The two former front entrances are closed with the standard wall sector.
- Coincident internal linedefs were removed during consolidation to prevent
  duplicated faces and z-fighting.
- `CaelumSpecialInventoryItem` is excluded from the native inventory bar, so
  materials and key/special items cannot replace the player face.
- Consumables and ammunition remain available through their independent
  native-bar definitions.
- Bull sprites, Seal effects and MAP02 are unchanged.

Pending runtime validation: inspect all wall faces and three doors from both
sides, confirm correct door collision/opening, and collect several material
types while watching the player face.

## MAP01 wall orientation, equipment HUD isolation and Bull sprites 4.28.0bn

**Implemented — pending manual GZDoom 4.14.2 validation**

- MAP01 contains the four valid finite wall panels at `x=368`, angle 90, and
  no angle-0 perpendicular finite wall panels.
- `CaelumEquipmentItem` is excluded from the native inventory bar, covering
  weapons, armor, shields, amulets and Seals through their common base class.
- Consumables remain available through their independent native inventory
  class and `INVBAR` flag.
- Bull rear Charge frames `BULLF5` and `BULLG5` now show the authored rear
  views.
- Bull Death frames `BULLI0` through `BULLN0` use transparent 96x64 PNGs; the
  final frame has a complete head and no duplicated or clipped face.
- MAP02 remains unchanged with 15,000 passive stress actors.

Pending runtime validation: confirm the intended walls from both sides in
MAP01, verify that no custom equipment pickup replaces the player face, and
check Bull rear Charge rotation and Death offsets in motion.

## Mass-resisted Seals and elevated Quintessence epicenter 4.28.0bm

**Implemented — pending manual GZDoom 4.14.2 validation**

Quintessence now centers its sphere 160 map units above the player: exactly
five meters at the established 32-units-per-meter development scale. Targets
therefore converge overhead instead of through the owner's collision volume.
Continuous attraction and Air's clockwise tangential/vertical acceleration
divide the applied force by each target's authoritative mass. The existing
Quintessence release formula remains `10 × trapped mass / expelled mass`.

Earth channeling no longer calls either Freeze or Dazzle. Poison remains its
only elemental status and visual, while a new presentation-independent Earth
penalty preserves the radial reduction of movement and accuracy: 100% at the
center, 50% at half radius and 0% at the boundary. Actual Ice attacks continue
to own Freeze and its visual exclusively.

Seal pickups no longer participate in GZDoom's native inventory bar. Caelum's
own inventory and equipment system remains authoritative, and collecting a
Seal cannot replace the native HUD face with that Seal's icon.

Validation focus:

1. Channel Quintessence among a crowd and confirm targets gather overhead
   without crossing and collision-killing the player.
2. Compare a Giant Rat and Bull under Air and Quintessence; the Bull must
   accelerate substantially less because of its greater mass.
3. Channel Earth and confirm Poison plus radial statistic reduction with no
   Freeze state, frozen visual or Ice presentation.
4. Collect all five Seals and confirm the player face remains unchanged.

## MAP01 panel rollback and authoritative Seal binding 4.28.0bl

**Implemented — pending manual GZDoom 4.14.2 validation**

The bilateral visual reconstruction from `4.28.0bk` is reverted. MAP01 no
longer places any of its eight `CaelumFiniteWallPanel` actors, including the
interior wall indicated in the supplied screenshot and the panels adjoining
the entrances. They are deliberately open rather than covered by another
actor-wall experiment. Sliding doors again have one visual leaf, eliminating
the second coincident-looking texture introduced in the previous patch.

Seal channel actors now retain the exact Seal inventory object that created
them. Every tic validates that this object is still the equipped Seal and
reads the effect type from it; unequipping or replacing it destroys the old
channel. The HUD selection and the applied element can therefore no longer
diverge through a surviving Fire channel actor.

MAP02 is unchanged from `4.28.0bk`: 15,000 passive, solid and damageable stress
actors with no target acquisition, chase, facing or attack calls.

Validation focus:

1. View and operate MAP01 doors from both sides; each leaf must show one
   texture, with no doubled rear leaf.
2. Inspect the eight removed panel positions; they must be empty and must not
   retain an invisible collision wall.
3. Channel Fire, stop, equip each other Seal and channel again. The applied
   mechanic must always match the equipped element shown by the HUD.
4. Confirm MAP02 retains 15,000 passive actors and its validated responsiveness.

## Rebuilt bilateral walls/doors and passive stress population 4.28.0bk

**Implemented — pending manual GZDoom 4.14.2 validation**

The first-floor actor walls no longer place their reverse visuals at a fixed
diagonal offset. Each back panel is reconstructed from its master's actual
orientation, positioned 0.5 MU along the local normal and rotated 180 degrees.
Sliding doors now use the same two-visual representation: one master front
leaf owns the existing collision/blockers and a synchronized non-solid rear
leaf follows every opening and closing movement.

MAP02 now uses six passive stress subclasses. All 15,000 actors retain their
normal profiles, mass, radius, height, solidity, anatomy, elemental response,
Pain and Death states, but Spawn/See/Melee/Missile contain no `A_Look`,
`A_Chase`, target facing, charge or projectile/melee call. This isolates actor
count, rendering, collision and Seal processing from AI and combat decisions.

Validation focus:

1. Inspect every rebuilt upper wall and door from both sides, particularly the
   room shown in the supplied screenshot and the entrance-facing doors.
2. Open and close each rebuilt door from either side and confirm both faces
   move together without doubled collision.
3. Start MAP02 and approach the entire population: no actor may acquire,
   pursue, turn toward or attack the player or another actor.
4. Damage representatives of all six passive types and confirm Pain, Death,
   solidity, physics and Seal effects still operate.
5. Compare responsiveness while viewing and entering the passive 15,000-actor
   crowd against the previous active-AI result.

## Southern tornado Seal and first-floor seam closure 4.28.0bj

**Implemented — pending manual GZDoom 4.14.2 validation**

The Air Seal now adds clockwise horizontal tangent velocity and positive
vertical velocity instead of radial expulsion. Its direction is viewed from
above and follows the project's southern-hemisphere convention. Air and
Quintessence record each target's original `NOGRAVITY` flag, suspend gravity
only while that target remains affected, and restore the original value when
the target leaves, the owner is interrupted or channeling ends normally.

The Earth Seal computes Freeze and Dazzle power from distance to the channel
center. A continuous piecewise squared curve produces exactly 100% at the
center, 50% at half radius and 0% at the boundary. The existing 1.1-second
refresh, poison damage, channel radius, tier costs and cooldown are unchanged.

The remaining MAP01 slit shown from inside the central first-floor room was a
terminal render seam behind the nominal 64-MU closure. The mirrored terminal
panels at `x=368`, `y=±540`, height 136 now span 72 MU. Their 4-MU overlap at
each endpoint closes the visible joint while retaining finite upper-floor-only
collision and the existing first-floor topology.

Validation focus:

1. View the indicated central-room wall from the supplied firing position and
   confirm no black vertical seam remains.
2. Inspect both mirrored closures from either side and from the ground floor.
3. Channel Air beside several masses and confirm clockwise orbit plus lift.
4. Walk or throw a target outside Air and verify gravity resumes immediately.
5. Repeat with Quintessence, including normal release and Pain interruption.
6. Compare Earth targets at center, half radius and boundary for approximately
   100%, 50% and 0% movement/accuracy penalties.
7. Confirm MAP02 still contains and can awaken all 15,000 combatants.

## Full post-island stress population 4.28.0bi

**Implemented — pending manual GZDoom 4.14.2 validation**

MAP02 now contains exactly 15,000 combatants: 1,000 each of Rulo, Caella,
Ronnie, Argento and Bull, plus 10,000 Giant Rats. Every actor occupies a unique
position on the existing 96 MU grid, and the enclosure, entrance and geometry
remain unchanged. Contact islands, once-per-second crushing, straight explosive
projectiles, Eloquence-derived range and the 350-tic absolute projectile
safeguard remain unchanged.

Validation focus:

1. Confirm the initial chamber remains responsive before acquisition.
2. Wake all 15,000 combatants and record the first sustained frame drop.
3. Distinguish stable low frame rate from progressive loss of responsiveness.
4. Continue after projectiles expire and verify whether performance recovers.
5. Enter the central contact pile and monitor active contact count.

## Range-bounded projectiles and UI-safe contact telemetry 4.28.0bf

**Implemented — pending manual GZDoom 4.14.2 validation**

MAP02 returns to the previously validated population of 937 combatants: 63
Rulo, 63 Caella, 62 Ronnie, 62 Argento, 62 Bulls and 625 Giant Rats. Its
16,384×16,384 MU enclosure, dogleg entrance and actor positions are unchanged.

Player and combat actors now store an array of shared `ImpactContactState`
objects rather than one replaceable actor reference. Each state is the edge
between two bodies; connected edges therefore form an implicit contact island.
The state remains active until its bodies exceed the established release
distance for five consecutive tics.

An initial collision still uses `ImpactPhysics.ResolveBodies` and may apply
ordinary collision trauma. Later collision callbacks for the same pair perform
an allocation-free inelastic momentum transfer and cannot apply a second
impact while contact persists. Every 35 sustained-contact tics, crushing
resolves a synthetic collision at the pusher's current walking speed. It uses
the existing source and receiver effective masses, contact-height interval,
anatomy, Toughness and armor pipeline; the receiver's biological landing
absorption is subtracted before the damage curve. There is no independent
crushing base damage or arbitrary multiplier.

Rulo, Caella, Argento and Ronnie now fire straight explosive elemental
projectiles instead of calling `A_SeekerMissile` every tic. Their explosion
uses the same base radius and direct-damage ratio as the player's Statuette.
Their magical attack decision and projectile distance now share the player's
authoritative range rule: 3,200 MU multiplied by Eloquence Type 4
`AbilityRangePercent`. Unimpacted projectiles self-destruct as soon as they
exhaust that distance, while 350 tics remains an absolute safeguard.

The debug UI no longer calls the play-scope `GetImpactContactCount` function.
Player `Tick` caches `ImpactContactCountForUI`, and the overlay only reads that
numeric field, preserving GZDoom's play/UI context boundary.

Validation focus:

1. Confirm MAP02 loads with exactly 937 combatants and remains quiet at spawn.
2. Wake all populations and let them collide and exchange projectiles.
3. Run through the central pile and confirm the game remains responsive.
4. Observe `Contacts` on the physics debug page while touching several bodies.
5. Confirm one collision causes at most one trauma event until true separation.
6. Confirm sustained pushing can propagate through several touching actors.
7. Hold a heavy actor against a lighter body for several seconds and compare
   the once-per-second Crush result with a walking-speed collision.
8. Confirm NPC projectiles fly straight, explode on impact and disappear after
   ten seconds when they miss.

## Wall reverse rendering and texture-package validation 4.28.0az

**Implemented — pending manual GZDoom 4.14.2 validation**

The repeated first-floor slit persisted because `CaelumFiniteWallBackPanel` used `NOINTERACTION`. The reverse actor therefore failed to remain available to the sector renderer. It now remains render-linked while `NOBLOCKMAP`, absence of `SOLID`, `CANNOTPUSH` and `DONTTHRUST` keep it outside collision and Impact Physics. Front and rear visuals remain separated by 0.25 MU to avoid coplanar depth rejection.

Font directories use kerning `-4` and one additional pixel of `SpaceWidth`. One transparent right column was also removed from every glyph, so template fonts created by `FONTDEFS` receive the same one-pixel tightening even when they do not consume `font.inf`. `FONTDEFS` now carries the matching larger word spaces. The five classic main-menu actions are patch graphics rather than live text, so `M_NGAME`, `M_OPTION`, `M_LOADG`, `M_SAVEG` and `M_QUITG` are replaced by CaelumText-rendered Spanish labels.

The supplied startup log identifies `sprites/caelum/weapons/` as invalid texture data. The existing development archives contain explicit zero-byte ZIP directory records in texture namespaces, while all 3,166 PNG files decode successfully and have positive dimensions. `tools/build_pk3.py` packages files only, validates PNG headers and dimensions, rejects every empty source file, verifies the ZIP and atomically replaces the output. This directly removes the only invalid texture resource exposed by the log and addresses the later `Trying to create zero size texture` fatal at its concrete package-level source.

Manual validation:

1. Build exclusively with `python tools/build_pk3.py src build/caelum_argenteum_dev.pk3`.
2. Confirm startup no longer prints `Invalid data encountered for texture`.
3. Inspect the central first-floor wall from both directions.
4. Verify spacing in HUD, options and the main-menu labels.
5. Repeat the 937-actor projectile test. If the fatal recurs, preserve the new log and crash stack because no zero-sized package entry should remain.

## Closed connector ends and 937-actor stress step 4.28.0ay

**Implemented — pending manual GZDoom 4.14.2 validation**

The black vertical strip visible through the central first-floor rooms belongs to the old 64-MU connector band between the two equal rooms. Its front and rear ends remained visually open. Four new 64-MU finite panels now close those ends at coordinates `x=368`, `y=±196/±540`, height 136. Each is a single smooth wall section using the existing finite-wall renderer and collision, so the closure does not extend infinitely through the ground floor.

Letter kerning remains `-3`. Only `SpaceWidth` increases by two pixels in every family, making word boundaries clearer without reopening the spacing between individual letters. The Debug profile remains unchanged at twelve attributes of 90.

MAP02 retains its 17 vertices, 17 linedefs, 17 sidedefs, one sector and original enclosure. Its new total is exactly 937 stress actors: 63 Rulo, 63 Caella, 62 Ronnie, 62 Argento, 62 Bulls and 625 Giant Rats, plus the player start. The two equal fractional remainders were assigned deterministically to Rulo and Caella.

Manual validation:

1. Stand at the position shown in the supplied screenshot and verify that neither end of the obsolete connector reveals the map background.
2. Inspect the same four closures from the opposite side and from the ground floor.
3. Confirm menu and HUD word spacing while individual letter spacing remains unchanged.
4. Wake all 937 MAP02 actors and note whether projectile activity still causes a freeze.

## Exact wall spans and 1,875-actor stress step 4.28.0ax

**Implemented — pending manual GZDoom 4.14.2 validation**

The four central first-floor finite wall panels previously covered 136 MU each, leaving 4-MU slits at the exterior endpoints. They now use exact 140-MU spans. Their centers move from ±268/±468 to ±266/±470, producing continuous ranges 196–336 and 400–540 on both wings while preserving the 64-MU central doorway from 336 to 400. No extra overlapping panel or collision layer is introduced.

Every bitmap family now uses kerning `-3`; `SpaceWidth` remains unchanged. The Debug creation profile's central attribute constant is 90, so all twelve attributes are reset to exactly 90 after equipment bonuses whenever the Debug profile is applied or recalculated.

MAP02 retains the 17 vertices, 17 linedefs, 17 sidedefs, one sector and original 16,384×16,384 MU stress enclosure. Its population is now 125 Rulo, 125 Caella, 125 Ronnie, 125 Argento, 125 Bulls and 1,250 Giant Rats: 1,875 test actors plus the player start.

Manual validation:

1. Inspect the four endpoints of both central wall dividers from inside and outside.
2. Verify both 64-MU internal door openings remain unobstructed.
3. Check menu, options, console and HUD letter spacing without losing word separation.
4. Create a Debug character and confirm all twelve attributes read 90.
5. Wake all 1,875 MAP02 actors and record whether the engine freezes or remains responsive.

## Direct transition and 3,750-actor stress step 4.28.0aw

**Implemented — pending manual GZDoom 4.14.2 validation**

MAP01 now uses `nointermission`, bypassing Doom's inherited completion statistics and moving directly to MAP02. This is provisional: a future Caelum intermission may report project-specific information such as elapsed time, exploration, objectives, casualties and resource use.

Typography keeps the validated size and contrast from 4.28.0av, but all letter pairs use kerning `-2` instead of `-1`; `SpaceWidth` remains unchanged so word separation stays visibly greater than letter separation. The native main menu remains intact and its title uses the higher-resolution `CAMLOGO` through `hires/M_DOOM.png`, retaining the original 132×65 logical footprint so it cannot overlap the options.

The central-room reverse wall face no longer occupies exactly the same rendering plane as its forward face. It is offset by 0.25 MU in X and Y, which is visually negligible but prevents coplanar depth rejection. Collision remains exclusively on the master panel and its blockers.

MAP02 preserves its entire enclosure and reduces each population exactly by half: 250 Rulo, 250 Caella, 250 Ronnie, 250 Argento, 250 Bulls and 2,500 Giant Rats. The result contains 3,750 stress actors plus the player start.

Manual validation:

1. Confirm MAP01 Exit reaches MAP02 without showing Doom statistics.
2. Check that letters are tighter while spaces between words remain clear.
3. Inspect every central finite wall from both sides and confirm one collision surface.
4. Verify the larger menu logo does not overlap selectable items.
5. Wake all 3,750 MAP02 actors and record whether the engine freezes or remains responsive.

## Native-menu recovery and legibility pass 4.28.0av

**Implemented — pending manual GZDoom 4.14.2 validation**

The 4.28.0au `ListMenu "MainMenu"` declaration contained a logo but no selectable items. In MENUDEF, that declaration replaces the inherited menu definition rather than decorating it, so the game displayed only the logo and directional input produced sounds without a usable selection. The override has been removed. `M_DOOM` continues to provide the Caelum logo, while GZDoom supplies the complete native menu structure and actions.

The bitmap families retain their fixed cell height and shared baseline. Ordinary serif and monospaced roles increase by one point and gain a dark one-pixel outline behind a bright translated foreground. Large/intermission roles decrease from 15 to 12 points to correct the oversized MAP01 completion presentation.

Manual validation:

1. Start the game and confirm that every main-menu entry is visible, selectable and functional.
2. Check main, options, controls, video, audio and console screens for the Caelum family and adequate contrast.
3. Verify HUD and dialogue text at the normal gameplay resolution.
4. Finish MAP01 and confirm the intermission typography is smaller than in 4.28.0au.

## Explicit menus, complete central pairs and 7,500-actor field 4.28.0au

**Implemented — pending manual GZDoom 4.14.2 validation**

The main menu now has a project-owned `MENUDEF`: it draws the transparent `CAMLOGO` emblem and requests `CaelumText` directly. `FONTDEFS` explicitly rebinds `NewSmallFont`, `NewConsoleFont`, `SmallFont`, `ConsoleFont` and `BigFont`, covering the modern option menus as well as classic list menus. `GameInfo.CreditPage` points to `TITLEPIC`, so Doom II's inherited credit image no longer alternates with the project title screen.

MAP01 activates the previously reserved sectors 93-95 for the south-central pair using control tags 510-512. It mirrors the validated north topology: one continuous exterior volume, two equal rooms, two independent exterior sliding doors and one door through the midpoint divider. Geometry near coordinate ±30,000 remains deliberately remote because it supplies the stacked-sector control planes used by GZDoom's 3D floors.

MAP02 keeps exactly the same room, start chamber, dogleg and unique-position distribution from 4.28.0at. Only population counts change: 500 Rulo, 500 Caella, 500 Ronnie, 500 Argento, 500 Bulls and 5,000 Giant Rats. The 7,500 actors remain deaf/ambush until acquiring sight.

Manual validation:

1. Confirm the main menu shows `CAMLOGO`, never `M_DOOM`, and the title loop never shows Doom II credits.
2. Open the main, settings, controls, video and audio menus and verify the Caelum typeface in every one.
3. Inspect both central MAP01 pairs: equal floor areas, continuous exterior walls, two exterior entrances and one midpoint door per pair.
4. Confirm the distant control geometry remains inaccessible during normal play and all first-floor surfaces remain present.
5. Wake the 7,500 MAP02 combatants and record whether the engine remains responsive. No push/contact-island code changed in this revision.

## Titanic isolated stress field and finite-wall reverse faces 4.28.0at

**Implemented — pending manual GZDoom 4.14.2 stress validation**

The narrow first-floor section that was visible externally but transparent internally was the reverse side of a one-sided `WALLSPRITE`. Every finite wall panel now creates one synchronized visual reverse face. The reverse actor has no interaction and creates no collision blockers, so physical behavior remains owned solely by the original panel.

Typography retains the shared-baseline cells introduced in 4.28.0as but increases each role moderately. Compact interface and monospaced families use bold faces, and all gameplay HUD labels request the engine's standard text shadow to remain readable against bright or detailed surfaces.

MAP02 now contains one remote 16,384×16,384 MU enclosure with 15,000 mixed combatants: 1,000 each of Rulo, Caella, Ronnie, Argento and Bull, plus 10,000 Giant Rats. A two-turn corridor blocks every initial line of sight, and `ambush` prevents remote sounds from waking them. Initial positions are unique, reproducibly shuffled and spaced 96 MU apart.

The earlier freeze has not been reproduced since remote awakening was isolated and NPC homing projectiles gained a ten-second lifetime. Infinite lost projectiles remain the leading causal candidate, but the two corrections were introduced together and therefore do not constitute a single-variable proof. An unbounded projectile population adds permanent thinkers whose seeking, movement and collision work executes every tic; a saturation freeze may leave no script error because the main loop is overloaded rather than throwing an exception.

Manual validation:

1. Inspect the corrected MAP01 wall from inside and outside; both faces must be opaque while collision remains single and finite.
2. Review HUD, menus, character creation and console for baseline, size and contrast.
3. Start MAP02 and remain in the initial chamber; no combatant may see, hear or attack the player.
4. Traverse the dogleg and enter the single enclosure; verify all six populations are interspersed rather than stacked.
5. Record frame rate, responsiveness, actor activation time and whether finite-lifetime projectiles disappear. With 15,000 active AI actors, severe slowdown may represent an engine capacity limit rather than the former unbounded-growth defect.

## Corrected north-pair entrances and font metrics 4.28.0as

**Implemented — pending manual GZDoom 4.14.2 validation**

The first 4.28.0ar room placement incorrectly aligned the midpoint divider with the only newly closed exterior gap. V4.28.0as closes that central opening as wall and restores both original 64-MU entrance positions. Each of the two equal rooms now has one exterior single-leaf sliding door, while the midpoint wall retains a third single-leaf door for internal communication.

The original supplied glyph PNGs were tightly cropped to different heights. GZDoom draws Unicode glyph patches from a common top origin, so lowercase, capitals, accents and descenders did not share a baseline. Every family is now regenerated on fixed-height transparent cells with one baseline. The classic HUD/console family is reduced to 10 pixels, `CaelumMono` is requested explicitly by both project overlays, and the modern engine aliases are supplied for menus and the console.

Manual validation:

1. Confirm each north-central room has its own exterior sliding entrance.
2. Confirm the central exterior face is solid and the midpoint divider does not intersect either entrance.
3. Open and close both exterior doors and the internal door from both sides.
4. Check that capitals, lowercase letters, accents and descenders share one baseline in HUD and character creation.
5. Confirm the HUD fits around every bar and that menus and console visibly use the new family.

## North-central room prototype and typography 4.28.0ar

**Implemented — pending manual GZDoom 4.14.2 architectural/font validation**

The 4.28.0aq interpretation of the central rooms is superseded. The north-central pair is now one continuous 336×336 MU exterior body. A finite wall at its exact midpoint divides it into two equal 168×336 MU rooms and contains one 64-MU single-leaf lateral door. There is no connector room or narrow passage between them. Only this pair is active; the mirrored south pair and lateral rooms remain neutral until the prototype passes manual validation.

The supplied font package is merged into the main PK3. Standard GZDoom font names are replaced globally, while the named Caelum variants remain available for later role-specific ZScript and MENUDEF use. Coverage includes printable ASCII, Latin-1 and Spanish punctuation. The supplied guide is stored as `docs/TYPOGRAPHY.md`, and the DejaVu redistribution notice is included under `licenses/DejaVu-copyright.txt`.

The complete MAP02 stress sequence passed: sound did not wake unopened rooms; Bulls crowded and collided; Caella, Argento, Rulo and Ronnie were introduced sequentially; Giant Rats were killed through impacts; and the surviving actors fought centrally without freezing. The 4.28.0aq containment is therefore validated. Contact-island physics remains a planned robustness improvement rather than the current reproduced cause of the freeze.

Manual validation:

1. Inspect the north-central pair from every exterior side: it must read as one large rectangular room volume.
2. Confirm the interior consists of exactly two equal rooms separated by one wall and one sliding door, with no intermediate passage.
3. Check floor, ceiling and outer walls from both floors and verify the stair landing remains clear.
4. Review main menu, character creation, HUD, inventory, console and debug overlay at 640×360 and 320×200 for missing accented glyphs or unreadable sizes.
5. After approval, reflect this exact room topology into the south-central pair.

## Central rooms, authored music and bounded MAP02 projectiles 4.28.0aq

**Implemented — pending manual GZDoom 4.14.2 validation**

The four central first-floor rooms in MAP01 again target the existing native 3D-floor controls: the two 64×64 links use floor/roof tag 510, their walls use tag 511 and their door/threshold regions use tag 512. This repairs the reported holes, irregular floor and absent walls without placing actor panels over the stair landing.

The title screen and MAP01 use `CA_MUS01`; MAP02 uses `CA_MUS02`. The embedded files identify the work as `The Argentine Omen` and the artist as `marjaja197` (metadata also notes creation with Suno).

The latest freeze sequence exposed two test-contamination risks. Because all MAP02 populations share a connected sound region, one pistol shot could alert actors outside the room being tested. Every test actor is now marked ambush/deaf and therefore ignores remote sound until it sees the player. NPC homing elemental projectiles also had an unbounded one-tic `Spawn` loop; each now self-destructs after 350 tics (ten seconds) if it has not impacted first. This patch does not yet replace the one-reference contact latch with contact islands.

Manual validation:

1. Inspect all four central MAP01 rooms from above and below: continuous floor, regular roof, complete walls and a clear stair landing.
2. Confirm `01` plays on the title screen and MAP01, while `02` plays on MAP02.
3. Fire inside one MAP02 room and confirm actors in unopened rooms remain asleep.
4. Wake Caella, Argento, Rulo and Ronnie populations individually and verify lost projectiles disappear within ten seconds.
5. Repeat the previous multi-group sequence; if it still freezes, record which populations are simultaneously visible/contacting so the contact-island implementation can be scoped.

## Rat room restoration, title screen and freeze diagnosis 4.28.0ap

**Implemented — pending manual GZDoom 4.14.2 validation**

MAP02 now has a seventh isolated room containing twenty Giant Rats. Its dedicated zigzag corridor blocks every initial sight line, as do the six previous rooms. Total population is 140 test actors: twenty each of Training Dummy, Rulo, Argento, Caella, Ronnie, Bull and Giant Rat, plus one player start.

The author-supplied 1920×1080 presentation image is registered explicitly as `TITLEPIC` through MAPINFO and stored in the graphics namespace.

The inventory is no longer a supported freeze hypothesis because the failure reproduced without opening it. Actor count alone is also insufficient: ranged NPC crowds and the initial Bull pile remained responsive. The strongest code-level hypothesis is the single-reference contact latch. Every body stores only one `ImpactContactActor`; in a dense moving pile, new contacts overwrite older references. Once both members of an older pair point elsewhere, that still-touching pair is treated as new and allocates two `ImpactBody` objects plus one `ImpactResult`, resolves another impulse and may overwrite more links. Bull pursuit, charge mass and a narrow corridor continuously rearrange neighbors, creating a feedback loop capable of producing allocation and impulse churn.

No physics change is included in 4.28.0ap. The next physics correction should replace the one-contact pointer with bounded multi-contact or island state, retain separation-based rearming and avoid per-contact heap allocation during collision callbacks.

Manual validation:

1. Confirm the new title screen appears before starting a game.
2. Enter only the Giant Rat room and repeat the prior twenty-rat tests.
3. Reproduce the Bull sequence: enter, allow crowding, leave, then approach the corridor again.
4. Do not mix groups during the reproduction; record whether the freeze occurs while Bulls contact one another, a wall or the player.
5. Confirm the other six rooms remain initially unaware of the player.

## Compartmentalized large-scale MAP02 4.28.0ao

**Implemented — pending manual GZDoom 4.14.2 validation**

The unapplied 4.28.0an package is superseded. Sewer source assets now follow the Windows-safe project order `src/graphics/caelum/textures/sewer`; the patch does not create a directory beside the root `TEXTURES` file.

MAP02 is now a large connected field with a central empty start and six distant rooms connected through two-turn corridors. It contains no Giant Rats. Each room contains twenty instances of exactly one test type: Training Dummy, Rulo, Argento, Caella, Ronnie or Bull. All 120 test actors begin behind native sight-blocking walls and have no direct line of sight to the player start.

MAP01.wad remains byte-identical to 4.28.0al/4.28.0am. MAPINFO assigns MAP02 as its next map so the existing normal Exit advances to the separate actor field.

The loose `CAF*` and `STF*` graphics are native status-face lumps selected by name. Files in the graphics namespace do not become inventory actors, and no face file is referenced by the equipment catalogue. The reported appearance of faces as equipable items therefore remains open for reproduction and must not be treated as a folder-placement fix.

Manual validation:

1. Start MAP02 and remain in the central chamber; confirm no actor attacks or acquires the player immediately.
2. Enter one room at a time and verify its population remains isolated from the other five groups.
3. Stress-test twenty actors of one type before opening a second room or using area effects.
4. Confirm there are no Giant Rats anywhere in MAP02.
5. Test MAP01's existing Exit and confirm it changes to MAP02.
6. If a face appears as equipment, record its inventory category, displayed name and icon before changing face assets.

## Separate architecture and actor maps 4.28.0am

**Implemented — pending manual GZDoom 4.14.2 validation**

MAP01 is now the architecture-only mansion test and remains byte-identical to its stable 4.28.0al state. MAP02 is a new independent actor arena built from one flat sector, four ordinary outer boundaries and no mansion or actor-based architecture.

MAP02 contains one player start, four Training Dummies, the four elemental NPCs, one Bull and twenty active Giant Rats. The groups begin separated so AI acquisition, collisions, inventory behavior, Seal effects and mass attacks can be observed without 3D-floor or sliding-door interactions.

Manual validation:

1. Load MAP01 and confirm its architecture-only stability remains unchanged.
2. Enter `map map02` in the console and remain stationary while the active actors acquire targets.
3. Test `noclip`, inventory, rat contacts, the Bull and area attacks independently.
4. Do not recombine actors with MAP01 until both maps remain stable separately.

## Actor-free architecture diagnostic 4.28.0al

**Implemented — pending manual GZDoom 4.14.2 validation**

The freeze also occurred while native `noclip` was active, so physical contact is no longer the primary hypothesis. MAP01 temporarily contains no monster, NPC or Training Dummy. The twenty Giant Rats, Bull, Rulo, Argento, Caella, Ronnie and four dummies are absent. The barred enclosures introduced only for 4.28.0ak are also removed.

The current first-floor room pair, ground-floor ceiling slabs, stairs, landing, doors, pickups and crafting infrastructure remain unchanged. This isolates the map architecture and non-combat world actors without modifying Impact Physics or gameplay code.

Manual validation:

1. Remain at the player start for several minutes.
2. Traverse the ground floor, stairs, landing and both implemented upper rooms with and without `noclip`.
3. Open the inventory in several areas.
4. If the freeze remains, remove the current upper-room pair for a direct architectural comparison.

## Isolated collision test enclosures 4.28.0ak

**Implemented — pending manual GZDoom 4.14.2 validation**

The Bull previously stood inside the approximately twenty-rat group and could push many bodies simultaneously, preventing a clean distinction between player/rat crowd contacts and Bull-driven displacement. MAP01 now has two closed, non-adjacent barred enclosures. All twenty normal active Giant Rats remain together in the western enclosure; the Bull is centered in a separate eastern enclosure. The bars block players and monsters while preserving visibility.

No collision formula or latch behavior changes in this diagnostic patch. The observed `noclip` result points to physical contact, but remains provisional until the two groups are tested independently.

Manual validation:

1. Remain outside both enclosures and confirm the Bull cannot touch or push any rat.
2. Enter only the rat enclosure with `noclip`, disable it inside and test the complete crowd without Bull interference.
3. Enter the Bull enclosure separately and test one Bull/player collision.
4. Confirm both barred contours remain closed and neither actor group escapes.

## Bilateral multi-contact latch for actor crowds 4.28.0aj

**Implemented — pending manual GZDoom 4.14.2 stress validation**

The stationary-rat test still froze after physical contact, disproving both AI load and ordinary actor count as the root cause. Impact Physics stored only one `ImpactContactActor` on each body. When a player contacted several rats, the player's pointer moved to the newest rat while earlier rats still pointed to the player. The player-side test then treated those older pairs as new every tic and repeatedly allocated `ImpactBody`, `ImpactBody` and `ImpactResult` objects.

Player and combat actors now treat a pair as latched when either side still references the other. This preserves the existing separation/rearm rule while preventing repeated allocation and impulse delivery for simultaneous crowd contacts. The twenty MAP01 actors are restored to the normal pursuing `CaelumGiantRat`; the diagnostic stationary subclass and DoomEdNum 18030 are removed.

Manual validation:

1. Remain near the complete active rat group for at least two minutes.
2. Let the group surround and physically push against the player.
3. Walk through the group repeatedly and open inventory while surrounded.
4. Confirm each rat still pursues and bites for base damage 60.
5. Confirm a separated rat can collide again after the established contact-rearm interval.

## Stable twenty-target Giant Rat area test 4.28.0ai

**Implemented — pending manual GZDoom 4.14.2 validation**

The freeze is confirmed to occur without opening inventory when the complete rat group enters its simultaneous `A_Look`/`A_Chase` range. MAP01 now uses `CaelumGiantRatAreaTest` for its twenty-target cluster. This subclass retains the Giant Rat body, mass 10, combat profile, quadruped anatomy, elemental statuses, Pain and Death, but deliberately has no target acquisition, chase or melee state.

The normal `CaelumGiantRat` remains available as the actual enemy with chase and base bite damage 60. The stationary test subclass exists only to make Fire, Earth, Air, Water, Quintessence and other mass attacks reproducible without mixing the measurement with twenty concurrent AI routes.

Manual validation:

1. Approach and circle the complete group without a freeze.
2. Open inventory beside the group.
3. Apply each Seal effect and confirm all authorized targets respond.
4. Confirm Pain and Death function and Quintaesencia still uses each rat's mass 10.
5. Spawn a normal `CaelumGiantRat` separately and confirm it still chases and bites for base 60.

## Ground-floor ceiling restoration and Giant Rat crowd fix 4.28.0ah

**Implemented — pending manual GZDoom 4.14.2 validation**

Native 3D-floor slabs again cover the eight actual room footprints, restoring the ground-floor ceilings and reserving the future first-floor walking surfaces. The two obsolete 64×64 central connectors remain untagged, so no slab or collision crosses the central corridor. Upper walls and doors remain limited to the manually accepted western pair from 4.28.0ag.

Opening the custom inventory does not enumerate nearby actors, but it immobilizes the player while the simulation continues. The approximately twenty test rats could therefore converge into one same-species collision pile. Giant Rats now use `THRUSPECIES`: they continue colliding with and attacking the player while passing through other Giant Rats. Mass, bite damage, targeting and elemental-area eligibility are unchanged.

Manual validation:

1. Inspect every ground-floor room ceiling and confirm its footprint matches the room above it.
2. Cross beneath the central corridor; confirm both former 64×64 connector slabs are absent.
3. Approach the full rat group and open/close inventory repeatedly while they converge.
4. Confirm rats still attack and collide with the player but no longer block one another.

## Incremental first-floor rebuild: pair 1 4.28.0ag

**Implemented — pending manual GZDoom 4.14.2 validation**

The complete actor-surface first floor from 4.28.0ae is rejected after a runtime freeze while the player crossed beneath its central elevated span. All upper finite floor, roof and wall panels are removed. Native 3D-floor controls now target only the two western rooms, one per wing; every other former upper polygon is assigned to an untagged neutral sector and therefore creates no upper volume.

Only four upper sliding leaves remain: the two exterior doors of the western north/south pair. The central corridor contains no upper actor bridge or blocker grid. Ground-floor geometry, doors, lintel, Seal systems and the approximately twenty Giant Rats are unchanged.

Manual validation:

1. Cross the entire central corridor and the stair landing repeatedly without a freeze or pause.
2. Inspect both western upper rooms from below, inside and above.
3. Confirm each room has a continuous floor and correctly oriented roof.
4. Open both double doors from each side and confirm both leaves slide laterally.
5. Confirm no wall, collision or invisible floor belonging to the other six rooms remains.

## GZDoom 4.14.2 elemental-visual compatibility 4.28.0af

**Implemented — pending parser and manual gameplay validation**

The elemental-status visual helper now receives a typed `class<Actor>` and calls the native static factory as `Actor.Spawn`. This replaces the object-scope call that GZDoom 4.14.2 rejected at `CaelumElementalStatus.zs:192`. No elemental damage, duration, target filtering or balance value changes in this compatibility patch.

Manual validation:

1. Confirm the PK3 parses and MAP01 starts in GZDoom 4.14.2.
2. Apply burn, poison, freeze and lightning and confirm the attached effects follow their owner and disappear with the status.
3. Confirm horizontal lightning projectiles and vertical Water-channel strikes retain their correct orientation.

## Seal Channel, Giant Rat tests and first-floor rebuild 4.28.0ae

**Implemented — parser correction supplied in 4.28.0af; manual GZDoom 4.14.2 validation pending**

User2 now starts the area effect defined by the equipped Seal and a second press interrupts it. Channeling spends exactly 3/6/9 Adrenaline each 35-Hz tic for T1/T2/T3, cannot begin without the first tic's cost, and starts a 60-second cooldown whenever it ends. Pain, death, losing/changing the Seal or reaching insufficient Adrenaline also ends it.

The player is stationary and cannot attack, Block, Aim, Reload, charge, cast, use consumables, Tarot, racial or class abilities while channeling. Fire, Earth, Air, Water and Quintessence have their authored non-weather effects. The area selector accepts living combatants of every allegiance, neutral NPCs, corpses and missiles; it does not accept inventory, pickups, stations, doors or map architecture.

Manual validation:

1. Equip each Seal tier and confirm exact consumption of 105/210/315 Adrenaline over one second.
2. Confirm User2 starts/stops the effect and every termination path starts a 60-second cooldown.
3. Confirm movement, attacks, Reload/charge, Zoom/Block, AltFire, User1, User3, User4, Use and consumables are suppressed.
4. Confirm Pain, death, zero Adrenaline, unequipping or changing the Seal interrupts immediately.
5. Test each elemental effect against enemies, allies, neutral NPCs, corpses and projectiles; verify pickups, doors and stations remain untouched.
6. For Water, place 1/2/4 actors inside the impact area and confirm the modified 10,000 pool is divided once across them.
7. For Quintaesencia, compare actors of different mass and verify release follows `10 × total trapped mass / individual mass`.

Climate modifiers by Seal tier are intentionally pending the Version 5 calendar/weather module.

The Seal HUD identifies the equipped element/tier, active channel and remaining cooldown. The development Adrenaline control adds 100 Adrenaline and removes 10 seconds from the Seal cooldown. MAP01 contains approximately twenty Giant Rats for mass-area testing; each rat uses quadruped anatomy, mass 10, approximately 40 cm height, all twelve attributes at 1 and base bite damage 60.

The first floor is an experimental full-wing rebuild with four similarly sized rooms per wing, one internal connection per adjacent pair and a clear stair-landing corridor. Original 3D-floor room-floor/roof controls were restored, finite bridge surfaces remain only where a real span is required, and door leaves choose their lateral axis from doorway orientation. Manual validation of floor continuity, roof orientation, lateral door travel and landing clearance remains mandatory.

## Stair-back closures, contextual Block dash and Giant Gauntlets AltFire 4.27.0g

**Implemented — pending manual GZDoom 4.14.2 validation**

The two north and two south gaps behind the intermediate staircase pairs are each closed by an independent conventional sector. Every strip is eight map units deep, has a 136-MU walkable floor and is aligned with the established room-back plane at `y=±640`; no free-standing middle texture or self-referencing sector is used. The four arena perimeter walls now display the large weathered cobblestone atlas crop `CMWV01`.

Mansion PNGs now live under `graphics/caelum/textures/mansion`. This avoids the case-insensitive Windows collision between the root `TEXTURES` lump file and a sibling `textures` directory while retaining engine-visible eight-character resource names.

The jewelry failure was a presentation-state reset: crafting instantiated `CaelumSealPickup` or `CaelumAmuletPickup`, but opening the equipment menu immediately replaced the selection with Armor/head. The menu now synchronizes armor fields only when Armor is the selected family, so a newly crafted Seal or Amulet remains visible and selectable.

Giant Gauntlets AltFire uses the same catalogue damage, reach and Air cost as Fire. A successful damaging uppercut applies the normal horizontal physical push and adds that calculated push force to vertical velocity; it therefore continues to respect the attacker's push multiplier and the target's effective mass instead of introducing an unrelated launch constant.

When Zoom begins a valid shield Block while the next attack is charged, horizontal velocity is set forward to 150% of the character's live maximum run speed. Attribute and elemental movement multipliers are read at activation; Pain/immobilization prevents the dash. The charged state is not consumed, because it remains attached to the next attack.

Manual validation:

1. Inspect and cross all four intermediate stair-back strips from ground, stair and roof level; confirm no side or upper plane escapes.
2. Confirm all four outer perimeter walls use the large cobblestone and room interiors retain their current material.
3. Craft a Seal and an Amulet separately, reopen equipment and verify the proper family/icon instead of Armor/head.
4. Compare Giant Gauntlets Fire/AltFire range, Air and damage, then confirm only AltFire launches a living target upward.
5. Charge a compatible melee or magic weapon, press Zoom with a shield equipped and confirm Block plus one forward 150%-maximum-speed impulse; confirm the next attack still consumes the charge.

MAP01 structure: 198 vertices, 264 linedefs, 520 sidedefs, 76 sectors and 186 things.

## Charge HUD, jewelry selection, rear-wall faces and mansion textures 4.27.0f

**Implemented — pending manual GZDoom 4.14.2 validation**

The combat HUD now displays `Charging: N.Ns` during the speed-scaled preparation and `Charged/Potenciador: N.Ns` during the three-second empowered window. The value reads the authoritative state timer rather than estimating it from animation frames.

Amulet and Seal crafting already spawned the correct native subclasses. The apparent helmet result came from the equipment menu always reopening on its default armor/head selection. Successful jewelry crafting now selects the created kind, type and tier before refreshing the inventory preview.

The two rear structural strips retain their closed 8-MU geometry and lower `STARTAN3` faces. Their new closure sidedefs no longer carry middle textures, removing the duplicate patches rendered above the intended wall height.

The author-supplied 1536×1024 mansion atlas was separated into 81 engine-ready PNG resources, subsequently relocated in 4.27.0g to `graphics/caelum/textures/mansion` for Windows compatibility. Every filename is an eight-character map-texture identifier.

Manual validation:

1. Inspect both restored rear walls from ground and roof level; confirm no wall patch floats above them.
2. Charge a melee and magical weapon while stationary and moving; confirm the countdown follows actual progress.
3. Let the charge complete and confirm the potentiator countdown begins at three seconds and disappears on attack, Pain, switch or expiry.
4. Craft one amulet and one seal; open inventory and confirm each created item is selected instead of a helmet.
5. Inspect the `CMEX`, `CMIN`, `CMST`, `CMWD`, `CMRF`, `CMGR`, `CMPW`, `CMPF` and `CMWA` families in SLADE or the map editor before assigning them to production geometry.

## Static charged-projectile classes 4.27.0e

**Implemented — pending parser confirmation in GZDoom 4.14.2**

GZDoom 4.14.2 does not expose Actor `SetSize` to ZScript. Charged standard, homing and explosive magical projectiles therefore use dedicated subclasses with `Radius`, `Height` and `Scale` fixed in each `Default` block. Attack routing selects the corresponding charged class before spawning it, retaining all parent homing, elemental, damage, durability and explosion behavior without runtime geometry mutation.

## GZDoom 4.14.2 charged-projectile compatibility 4.27.0d

**Implemented — pending parser confirmation in GZDoom 4.14.2**

The charged magical projectile now changes collision dimensions through Actor `SetSize` and replaces the complete visual `Scale` vector. ZScript does not permit direct compound assignment to the exposed `Radius`, `Height`, `Scale.X` or `Scale.Y` values. This revision fixes the parser error at `CaelumPlayer.zs:9057` without changing the intended `sqrt(2)` linear multiplier or any 4.27.0c gameplay value.

## Rear-wall restoration and contextual charged Reload 4.27.0c

**Implemented — pending manual GZDoom 4.14.2 validation**

MAP01 remains on the V4.26.5r pre-gate baseline. This patch adds only two closed, 8-MU-deep structural strips beside the rear-room door so the missing wall faces return on the stair and room sides. The four training dummies are moved laterally to `y=-900`. No main gate, connector corridor or terrace partition has been restored.

Reload is now contextual. Ranged weapons retain their existing magazine reload. Melee and essence weapons begin a 2-second base charge multiplied by the current physical attack-duration or casting-duration multiplier. Moving during either reload or charge applies a 50% movement multiplier and a 50% progress multiplier. On completion, the charged state lasts 3 seconds.

The next valid charged attack consumes 200% Air or Anima and inflicts 200% damage. Magical projectile collision/visual dimensions and explosion radius use a `sqrt(2)` linear multiplier, which doubles planar area. Pain, charge expiry and weapon switching remove the state. Fire/AltFire cancel an active shield Block before attacking. Empty ranged Fire automatically requests Reload if compatible inventory ammunition remains.

Manual validation:

1. Inspect both sides of the restored rear-room wall strips and cross the room roof without obstruction.
2. Confirm all four training dummies stand on the lateral line and no main entrance gate exists.
3. Time melee and magical charge at baseline attributes, then compare high physical attack speed and high casting speed.
4. Move during ranged Reload and both charge types; confirm movement and progress are each halved only while directional input is present.
5. Confirm Pain, weapon switching and the 3-second timeout remove the charge.
6. Compare normal/charged Air or Anima cost, damage, projectile size and statuette explosion radius.
7. Activate Block, press Fire and confirm Block drops while the attack continues.
8. Empty a ranged magazine while retaining reserve ammunition and confirm Fire begins Reload automatically.

MAP01 structure: 190 vertices, 248 linedefs, 488 sidedefs, 72 sectors and 186 things.

## MAP01 rollback to the pre-gate baseline 4.27.0b

**Implemented — pending confirmation that the crash is gone in GZDoom 4.14.2**

The supplied crash report shows that GZDoom completed actor parsing, initialized MAP01 and entered gameplay before raising access violation `C0000005`. The recorded position (`x=-14.09`, `y=536.57`) lies inside the new western/northern terrace connector introduced after the stable staircase layout. This is treated as an engine-level failure triggered by the experimental map geometry rather than a ZScript compile error.

MAP01 is therefore restored byte-for-byte from V4.26.5r. It contains no main corridor gate, no rear terrace connector fill and no internal terrace-partition doors. The rollback also removes every map experiment from V4.26.5s through V4.27.0a instead of attempting another local repair. Construction will resume incrementally from the aligned-room/stair baseline.

Restored structure: 186 vertices, 242 linedefs, 476 sidedefs, 70 sectors and 186 things. Static validation confirms valid references and closed degree-2 boundaries for all 69 non-exterior sectors.

V4.27 input work is not rolled back. The user has manually confirmed that held Zoom behaves correctly with a magic weapon and shield. Ranged-only Reload and User1–User4 reservation routing remain pending broader manual validation.

Manual validation:

1. Start MAP01 and revisit the former crash coordinates around the first north connector/stair pair.
2. Confirm there is no main entrance gate or associated frame near the Player Start.
3. Confirm the later terrace fills, internal divider doors and lateral black strips are absent.
4. Verify the original eight room doors, silver-key NPC room and three aligned staircase pairs still work.
5. Retest ranged Reload and the four User bindings separately from map construction.

## Native input contract and conventional terrace partitions 4.27.0a

**Superseded for MAP01 by 4.27.0b; input changes remain active**

V4.27 has begun without assigning unauthored ability effects. Every physical, ranged and magic selector now exposes the complete native input contract: User1 reaches the racial-ability service hook, User2 reaches Seal Channel, User3 reaches the equipped-Tarot hook and User4 reaches the class-ability hook. Reload exclusively requests a magazine reload for ranged weapons. The four abilities remain reservation interfaces until their authored content patches; the control menu now names all four bindings in English and Spanish.

Magic weapons now share the same release latch used by physical/ranged contextual Zoom. Holding Zoom therefore produces only one Block toggle until the key is released. Ranged Zoom/ADS and its physical accuracy multiplier are unchanged.

The failed 4.26.5w internal-wall technique has been removed completely. Each of the four terrace connectors is now a set of seven ordinary sectors: west/east floor spaces at height 0, wall spans at 136, jambs and moving panel at 128. No self-referencing middle texture participates in the room division. This preserves three connected rooms per north/south row while preventing a wall face or 3D-floor plane from escaping laterally. The main western entrance similarly uses two continuous closed jamb polygons rather than a jamb/extension seam.

Updated MAP01 structure: 252 vertices, 350 linedefs, 692 sidedefs, 103 sectors and 186 things. Static validation confirms 102 closed non-exterior sector contours, valid references, no duplicated/overlapping segment and no non-vertex crossing.

Manual validation:

1. Inspect both terrace rows from below and above; confirm the left roof is complete and no black or textured strip escapes laterally.
2. Inspect the four internal doors from both rooms, including their floor edges and all jamb faces.
3. Cycle every internal panel at least four times from both sides and cross above every partition on the terrace.
4. Inspect and cycle the western entrance from both directions; confirm both jambs are complete and opaque.
5. Bind User1–User4 through Customize Controls and confirm each weapon family accepts the proper native state without attacking or reloading unexpectedly.
6. Hold Zoom with a shield-compatible magic weapon and confirm Block toggles only once until release.
7. Confirm Reload affects ranged magazines only and User2 does not consume Anima yet.

## Three-room terrace divisions and sealed entrance frame 4.26.5w

**Implemented — pending visual confirmation in GZDoom 4.14.2**

The two roofed areas behind the intermediate staircases are no longer continuous hall-like spaces. Each north/south row is divided at the centers of its two connector modules, producing three similarly sized rooms connected in sequence. Every new partition contains a centered 128-MU retracting panel with bilateral repeatable USE. The remaining partition spans are self-referencing finite 3D middle walls from floor 0 to the underside of the 128-MU roof, so they close sight and movement at room level without creating another ceiling/control strip or obstructing terrace traversal above.

The western corridor gate retains its established position and dimensions. Its two outer frame extensions now use floor 128 and roof-control ID 100 like the adjacent jambs. This makes the complete jamb/extension assembly opaque and finite while preserving the open roof route above the panel.

Updated structure: 256 vertices, 340 linedefs, 672 sidedefs, 93 sectors and 186 things. Static validation confirms valid references, 26 platform-door activators, 53 roof targets, closed boundaries for every conventional sector, no duplicate or overlapping segments, no non-vertex crossing and deterministic regeneration.

Manual validation:

1. Enter each north/south terrace interior and confirm it is now a sequence of three rooms rather than one large hall.
2. Cycle all four new internal doors repeatedly from both sides and confirm they block sight while closed.
3. Inspect every partition from floor level and then cross the uninterrupted terrace above it.
4. View the western entrance frame obliquely from both sides and confirm there are no transparent triangles, black extensions or infinite faces.
5. Confirm the central corridor remains uncovered and all six staircase routes still reach the terrace.

## Closed terrace topology and opaque entrance frame 4.26.5v

**Implemented — pending visual confirmation in GZDoom 4.14.2**

The screenshot from 4.26.5u exposed a topology leak rather than an intentionally authored corridor: the two 136-MU rear structural-wall strips each inherited one extra jamb edge, leaving an open contour. Their floor surface could consequently extend as a long black strip toward the spawn and make the left/right terrace fill appear asymmetric. Those connections now return to the correct low stair sectors; wall strips, stairs, connectors, rooms and gate components all form independent closed polygons.

The western entrance retains the same location and 128-MU panel. Its frame is now structurally identical to the room pattern: 16-MU north/south jamb sectors at floor 128, followed by separate 16-MU wall-extension sectors at floor 136 to reach y=±96. Every exposed edge carries a finite lower face, removing the transparent section without enlarging the door or covering the corridor.

Updated structure: 208 vertices, 284 linedefs, 560 sidedefs, 81 sectors and 186 things. Static validation confirms all 80 non-exterior sectors have closed degree-2 boundaries, plus no collinear overlap or non-vertex crossing.

Manual validation:

1. Return to the screenshot viewpoint and confirm no black roof strip extends toward the Player Start.
2. Compare the northern/southern and western/eastern terrace connectors for symmetric fill and roof continuity.
3. Inspect all four faces of both entrance jambs and wall extensions for transparency.
4. Cycle the entrance panel repeatedly from both sides and confirm the corrected frame remains finite.

## Integrated corridor entrance and continuous rear terrace 4.26.5u

**Implemented — pending manual GZDoom 4.14.2 validation**

The standalone gate at x≈-1556 is removed completely. Its mechanism now occupies the actual western entrance between the nearest north/south rooms: west threshold x=-593, east threshold x=-569, panel width 128 MU and solid frame spanning the remaining corridor width to y=±96. No separate gate sector remains near the Player Start.

Four new connector sectors fill only the areas behind the first two north/south staircase pairs. Northern connectors cover y=272…640; southern connectors cover y=-640…-272. Their 128–136 MU solid roof target joins the neighboring room roofs into one terrace. Existing room-side linedefs are split and shared with the connector sectors, while the 136-MU final steps provide their front boundary. The central y=-272…272 corridor/stair zone remains open to the sky.

Updated structure: 204 vertices, 278 linedefs, 548 sidedefs, 79 sectors and 186 things. Static validation confirms deterministic regeneration, 18 platform-door activators, 39 roof-target sectors, no collinear overlap and no non-vertex crossing.

Manual validation:

1. Confirm there is no gate, jamb, roof strip or collision remnant near the Player Start.
2. Approach the western room pair and verify a single framed trap door closes the real corridor entrance.
3. Complete at least four opening cycles from both sides and inspect the frame obliquely.
4. Climb the first two northern and southern stair pairs and cross their final steps onto the new connector roofs.
5. Walk the joined terrace across all six paired rooms and confirm no 1-MU holes remain behind the stairs.
6. Look upward throughout the central corridor and confirm it remains completely unroofed.

## Structural rear walls, compact entry gate and debug creation 4.26.5t

**Implemented — pending manual GZDoom 4.14.2 validation**

The rear staircases no longer own wall middle textures. Two 8-MU structural strips now belong to the rear room itself. Their conventional floor is 136 MU, producing visible lower wall faces from the room floor and from every adjacent tread while aligning their walkable top with the roof. This restores the interior wall and prevents stair textures from projecting above the building.

The entry trap gate moves from x=-1496…-1472 to x=-1568…-1544. Its west face is 32 MU ahead of the Player Start and its total depth remains 24 MU; panel, jambs, roof target and bilateral activation are unchanged. The four training dummies retain x=-1216/-704/320/1344 but move together to y=-900, clearing the central corridor.

Character creation now exposes `Depuración` / `Debug` as a fifth option on the race page. Confirming it jumps directly to the summary. The resulting profile overrides all twelve post-equipment primary attributes to exactly 30 and forces mass tier 6 / size tier 4: 100 kg base body mass and 1.8 m body height. A second confirmation completes creation and initializes resources normally. Carried equipment weight remains additional to the documented 100-kg body mass.

Updated MAP01 structure: 198 vertices, 258 linedefs, 508 sidedefs, 75 sectors and 186 things. Static validation confirms deterministic regeneration, no scaled stair middle textures, no collinear overlap and no non-vertex crossing.

Manual validation:

1. Inspect both faces of the rear-room walls from inside, from every tread and from the roof.
2. Confirm the stairs themselves have no wall texture and their final steps transition onto the wall/roof top.
3. Spawn facing east and verify the compact gate is immediately ahead without overlapping the player; complete four bilateral cycles.
4. Confirm all four dummies form a usable row south of the buildings and no longer obstruct the corridor.
5. Select `Depuración`, confirm twice, and verify twelve attributes at 30, 1.8 m height and 100 kg base mass.

## Visible stepped rear walls and corridor trap door 4.26.5s

**Implemented — pending manual visual/activation validation in GZDoom 4.14.2**

The ten rear-room wall sections beside treads below roof level now use individually scaled `STARTAN3` 3D middle textures. Each section begins at its adjacent stair floor and ends at the 128-MU roof underside; it therefore closes the room above the tread without becoming invisible below it or projecting through the roof. The two boundaries adjacent to the 136-MU final steps remain open for traversal.

A standalone trap-door gate now crosses the beginning of the test corridor at x=-1496…-1472, 104 MU ahead of the Player Start at x=-1600. It combines a 128-MU-wide retracting panel, two 16-MU solid jambs, bilateral repeatable special 62 activation and the same finite 128–136 MU roof target as the room template. It is unlocked and independent of the silver-key NPC door.

Updated structure: 194 vertices, 252 linedefs, 496 sidedefs, 73 sectors and 186 things. Static validation confirms 18 platform-door activators, 35 roof-target sectors, deterministic regeneration, no collinear overlap and no non-vertex crossing.

Manual validation:

1. Climb both rear staircases and confirm every wall is visible above its tread and terminates at the roof underside.
2. Cross from both 136-MU final steps onto the roof without invisible collision.
3. Open the new corridor door from the Player Start side, cross it, wait for closure and reopen it from the opposite side for at least four cycles.
4. Inspect its jambs obliquely and confirm the panel and frame do not extend above the roof slab.

## Aligned staircase modules and restored rear walls 4.26.5r

**Implemented — pending manual visual/collision validation in GZDoom 4.14.2**

The three complete north/south staircase pairs now share one exact module: 119 MU width, 665 MU start-to-start horizontal spacing, low corridor boundary at y=±80 and high roof boundary at y=±272. No flight protrudes farther into the central passage than another.

The western rooms move 71 MU east and the eastern rooms move one additional MU east, with all contained pickups translated identically. Conventional modules retain a 1-MU anti-overlap clearance. The rear room moves one additional MU east and is centered on y=0; its y=±272 corners coincide with the two high steps.

All six boundaries between the rear room and its stairs again carry `STARTAN3` lower faces. These close the room only across the local floor-height difference and stop at each corresponding step height, replacing both the missing walls from 4.26.5q and the projecting 128-MU middle textures from 4.26.5o.

MAP01 remains at 186 vertices, 242 linedefs, 476 sidedefs, 70 sectors and 186 things. Static validation confirms valid references, deterministic regeneration, no collinear overlap and no non-vertex crossing.

Manual validation:

1. Walk the central corridor and confirm all six first steps begin on the same north/south line.
2. Compare all three staircase widths and verify none projects into the passage.
3. Climb both rear flights and confirm the final steps meet the room corners and roof without a gap or obstruction.
4. Look into the rear room from every step and confirm its side walls are restored without rising above the current tread.
5. Verify pickups in the western and eastern rooms retained their internal arrangements.

## Complete NPC attributes and uniform corridor stairs 4.26.5q

**Implemented — pending manual gameplay validation in GZDoom 4.14.2**

`CaelumCombatActor` now stores Constitution, Charisma, Empathy and Eloquence alongside its previous eight attributes, completing the same twelve-field primary model used by `CaelumAttributes`. It also stores current and maximum Anima. Maximum Anima uses the player rule `HEALTH_ANIMA_DAMAGE_SCALE × Type1(Patience)` and every predefined NPC initializes at maximum.

The resulting equipped test values are: Rulo 1060 Anima (Patience 3), Ronnie 1280 (Patience 7), Argento 2710 (Patience 18), and Caella 3760 (effective Patience 23). Caella's tier-1 magic helmet raises effective Intelligence by five but does not directly alter Anima; her separate magic-glove +5 Patience bonus is what increases the reserve. NPC statistics now recalculate after armor initialization, matching the player's equipment order.

MAP01 now contains three complete mirrored staircase pairs in the intermediate vertical corridors. Their centers are separated by approximately 664 MU on the integer map grid. The eastern north/south rooms and rear room move 24 MU east; pickups inside the eastern rooms move with them. All six shared rear-stair boundaries are textureless two-sided partitions, eliminating the protruding wall along the full climb.

Updated structure: 186 vertices, 242 linedefs, 476 sidedefs, 70 sectors and 186 things. Static validation confirms valid references, no collinear overlap, no non-vertex crossing and deterministic regeneration.

Manual validation:

1. Climb every north and south staircase and confirm all six steps are free of projecting wall strips.
2. Cross onto the roofs from each staircase pair and check the 1-MU safety clearances beside conventional room walls.
3. Confirm eastern-room pickups retained their relative positions after the 24-MU move.
4. Inspect Rulo, Ronnie, Argento and Caella diagnostics for all twelve attributes and full Anima.

## Clear roof landings and NPC-archetype audit 4.26.5p

**Map fix implemented — pending manual collision validation in GZDoom 4.14.2**

The two boundaries shared by the rear room and the 136-MU top stair sectors remain valid two-sided partitions but no longer render or collide as finite wall faces. Both lateral routes can now reach the roof; the five lower boundaries on each staircase retain their closed wall faces.

The definitive **`habitación con puerta trampa`** configuration is the complete 4.26.5p form: finite 128-MU room walls, solid walkable 128–136 MU roof, independent retracting floor panel, bilateral repeatable USE, solid jamb pillars that block lateral sight, and an unobstructed upper traversal plane. The keyed NPC room is the locked variant of the same template.

The 4.26.5p audit identified `CaelumCombatActor` as a combat-capable subset rather than a complete general NPC archetype. Constitution, Charisma, Empathy, Eloquence and Anima were its five missing fields; 4.26.5q implements them. Survival-only Hunger, Thirst, Sleep, Carry Load and Air remain intentionally player-only.

No missing attribute values are assigned in this patch: Rulo, Ronnie, Argento and Caella retain their existing balance exactly.

Manual validation:

1. Climb both rear stairs and walk onto the roof without catching on a narrow wall fragment.
2. Confirm the lower outer sides of both staircases remain closed.
3. Recheck the rear door, jamb sight blocking and roof traversal after the boundary change.

## Solid door frames, flush stairs and mounted exit 4.26.5o

**Implemented — pending manual visibility and collision validation in GZDoom 4.14.2**

The invisible 16×24-MU jamb partitions from 4.26.5n left a lateral sight slit beside each closed floor panel. Their sectors now begin at floor height 128 MU and carry finite `STARTAN3` lower textures on every exposed boundary. Each doorway therefore has a real two-pillar frame whose closed volume blocks sight and projectile targeting below the roof while retaining the 512-MU base ceiling and shared 128–136 MU roof slab above it.

The rear staircases now reach x=1400 and use the rear-room wall as their shared eastern boundary; no duplicate line is authored. Their western edge moves from x=1288 to x=1281, leaving only 1 MU before the pre-existing eastern-room wall at x=1280. Zero clearance would require splitting and sharing that older wall across the individual step sectors; 1 MU is the closest conventional integer-grid placement that avoids overlaps while making the gap visually negligible.

The freestanding NPC exit line at x=-2448 is removed. `SW1EXIT` and special 243 now occupy the central 128-MU segment of the actual western room wall at x=-2464, y=-64…64. It inherits the same finite wall collision and cannot float inside the room.

Updated MAP01 structure: 130 vertices, 166 linedefs, 324 sidedefs, 46 sectors and 186 things. Static validation confirms valid references, balanced sector boundaries, no collinear overlap and no intersection outside shared vertices.

Manual validation:

1. Stand at oblique angles beside several closed doors and confirm the interior cannot be seen through either jamb.
2. Confirm NPCs do not acquire or attack the player through a closed doorway, then acquire normally after opening it.
3. Open every door and confirm both frame pillars remain finite and do not obstruct the central passage.
4. Climb both rear staircases and inspect the 1-MU western clearance and flush shared eastern wall.
5. Use the exit switch on the NPC room's western wall and confirm it no longer floats.

## Reusable one-trap-door room replication 4.26.5n

**Implemented — pending complete manual validation in GZDoom 4.14.2**

The architecture validated through 4.26.5m is now named **`habitación con 1 puerta trampa`** in the project vocabulary. One instance consists of an interior sector, a 128–136 MU solid 3D-floor roof, a finite floor panel that retracts through `Plat_DownWaitUpStay`, and two invisible jamb partitions. Its base ceiling remains at 512 MU, so wall and door geometry never extends into the upper playable space and the roof remains traversable in every door state.

MAP01 now contains eight instances: four central rooms, two eastern rooms, the NPC room and the rear room. Every door faces the corridor serving that room. The rear-room entrance has rotated from south to west. The NPC room retains silver lock 200 using the native UDMF `locknumber` field on both special-62 thresholds; the underlying trap-door motion is identical to the unlocked instances.

The provisional staircase and 136-MU raised block east of the rear room are removed. Two staircases flank its new west-facing entrance. Each contains six 32-MU-deep steps and reuses the established floor heights 24, 48, 72, 96, 120 and 136 MU. They occupy the passage between the eastern rooms and the exterior face of the rear door, and their upper steps provide the roof-access jump across the existing 24-MU door depth.

All 186 things remain present. Item coordinates are unchanged. The four `CaelumTrainingDummy` instances move 128 MU west, toward the player start, leaving the rear room empty without changing their common firing axis.

Updated MAP01 structure: 132 vertices, 167 linedefs, 326 sidedefs, 46 sectors and 186 things. Static validation confirms valid references, balanced boundaries, no overlapping collinear linedefs and no intersections outside authored vertices.

Manual validation:

1. Open every unlocked room from outside and inside, then complete at least two full cycles per door.
2. Confirm all seven unlocked doors face their corridors and none produces suspended or infinitely tall textures.
3. Approach the NPC door without and with `CaelumSilverKey`; verify the localized lock response and successful opening only with the key.
4. Enter every room and walk across representative roof areas, including all eight doorway roofs.
5. Climb both new side staircases and cross from each 136-MU upper step onto the rear-room roof.
6. Confirm the old eastern staircase and raised block are absent.
7. Verify all pickups remain in their prior positions and all four training dummies are outside rooms on the shifted firing axis.

## Door partition texture cleanup 4.26.5m

**Implemented — pending visual validation in GZDoom 4.14.2**

The 4.26.5l geometry and motion behaved correctly, but the auxiliary sectors introduced around the jambs still carried `STARTAN3` middle textures. After their base ceilings were raised to 512 MU for continuous roof traversal, those partition textures rendered as narrow suspended strips above the door.

All sixteen middle-texture assignments belonging to the auxiliary partition boundaries and the moving-door side partitions are removed. The two side lines no longer use `midtex3d` or bottom-pegged middle-texture flags. Their finite `BIGDOOR2` lower textures remain, appearing only across the actual 128-MU floor-height difference while the panel is closed.

MAP01 remains at 94 vertices, 93 linedefs, 178 sidedefs, 16 sectors and 186 things. Reference and closed-boundary validation pass; door motion and roof targets are unchanged.

Manual validation:

1. Inspect the doorway from outside and inside and confirm no narrow strips float above it.
2. Open and close the door and confirm its finite front and side faces remain visible while closed.
3. Walk over the complete roof and confirm the entrance remains traversable above.

## Independent finite door and continuous roof 4.26.5l

**Implemented — pending manual validation in GZDoom 4.14.2**

The 4.26.5k limiter shortened the vertical ceiling motion but did not solve the underlying coupling: door sector 5 was still both the moving closure and a target for the solid roof 3D floor. Lowering its base ceiling to the 128-MU roof underside removed the playable upper volume over the doorway, while the ceiling-based panel could still render against the complete vertical sector.

The closure is now independent of the ceiling. Door sector 5 has a fixed 512-MU sky ceiling and a closed floor at 128 MU. Both USE thresholds call native `Plat_DownWaitUpStay` (special 62): the floor panel lowers to the surrounding 0-MU floor, waits 150 tics and returns to its authored 128-MU closed position. The existing speed remains 16. `BIGDOOR2` is assigned as a lower texture, so only the finite floor-height difference renders as the door face.

Room sector 4, door sector 5 and jamb sectors 14–15 all retain the 512-MU base ceiling and target ID 100. The solid 3D-floor slab from 128 to 136 MU therefore remains valid and walkable above the complete entrance regardless of door position. The map structure remains 94 vertices, 93 linedefs, 178 sidedefs, 16 sectors and 186 things; static topology and reference validation pass.

Manual validation:

1. Confirm the closed panel ends at the 128-MU lintel and has no continuation toward the sky.
2. Open from outside, cross, wait for closure and reopen from inside.
3. Complete at least four alternating cycles and confirm the panel returns to the same closed height.
4. Walk continuously across the roof above the door while it is closed and while it is open.
5. Stand clear during closure and confirm the passage does not remain visually or physically blocked after reopening.

## Finite framed template door 4.26.5k

**Implemented — pending manual validation in GZDoom 4.14.2**

**Superseded by 4.26.5l.** The limiter corrected the target height but kept the moving ceiling coupled to the roof target, so the upper doorway remained non-traversable.

The template door previously opened against sectors whose base ceilings were at the 512-MU outdoor sky. Because the standard vertical `Door_Raise` action stops four map units below the lowest adjacent ceiling, the moving door sector rose far above the visible 128-MU doorway and appeared infinitely tall.

Two 16×24-MU structural jamb sectors now flank the existing 128-MU-wide door recess. Their ceilings are 132 MU, providing a deterministic 128-MU open position after the native four-unit clearance. The door remains a conventional vertical stone door rather than a polyobject: this preserves finite collision beneath the walkable 3D-floor roof and avoids an infinitely tall rotating polyobject blocking traversal above the doorway.

The room, roof, door width, activation lines, speed and 150-tic delay are unchanged. Both thresholds retain front/back player USE and `repeatspecial = true`. Updated MAP01 structure: 94 vertices, 93 linedefs, 178 sidedefs, 16 sectors and 186 things. Static validation confirms valid references and balanced sector boundaries.

Manual validation:

1. Open the door from outside and confirm its visible panel disappears at the 128-MU lintel instead of rising toward the sky.
2. Cross the threshold, wait for closure and reopen it from inside.
3. Complete at least four full cycles while alternating sides.
4. Walk over the roof above the doorway and confirm there is no new invisible obstruction.
5. Confirm the two narrow jamb extensions render as part of the doorway rather than as gaps.

## Unified shield framing and true walkable room roof 4.26.5j

**Implemented — pending manual validation in GZDoom 4.14.2**

All four equipped-shield Block layers now use the same medium framing previously validated for the Kite Shield: virtual position `(90, 125)` and rendered size `210×230`. This keeps every shield left of center without the Buckler becoming too central or the Tower becoming excessively large. The Magic Shield retains only its larger translucent halo pass as a type-specific visual distinction.

The room is no longer a sector capped at 136 MU. Room sector 4 now has a 512-MU sky ceiling and shares target ID 100 with door sector 5. A closed control sector outside the playable field defines a solid opaque 3D-floor slab with underside at 128 MU and walkable top at 136 MU. Its initialization line uses `Sector_3DFloor` (special 160) for target 100. The existing finite 3D middle-texture walls end below the slab, so the player can cross their upper edge onto the roof rather than colliding with an infinitely tall boundary.

The adjacent raised platform and final stair remain at 136 MU. They provide the current access/calibration point for crossing onto the new roof at the same elevation. The door recess receives the same slab, avoiding an uncovered strip above the doorway. `Door_Raise` remains front/back usable and uses the valid `repeatspecial` field.

Updated MAP01 structure: 90 vertices, 87 linedefs, 166 sidedefs and 14 sectors. The added control geometry is a conventional closed four-line sector and is outside the playable field.

Manual validation:

1. Enter the room and confirm the ceiling underside remains at 128 MU.
2. Use the six steps to reach 136 MU and cross/jump from the adjacent platform onto the room roof.
3. Walk across the complete roof, including above the doorway, without falling through or meeting an invisible wall.
4. Drop from the roof into the field and confirm collision/landing physics still operate.
5. Complete at least four door cycles from alternating sides.
6. Test all four shields and confirm they share the same medium left-offset framing.

## Equipped shield first-person Block layer 4.26.5i

**Implemented — pending visual calibration in GZDoom 4.14.2**

Persistent Block now exposes the equipped shield as a modular first-person HUD layer. The layer is driven by a play-scope snapshot of `CombatBlockModeActive` and the live equipped shield type, and disappears immediately when Block ends, the shield breaks or the shield is unequipped.

The four provisional compositions preserve the authored visual distinction:

- Buckler: near the center and lower in the frame.
- Kite Shield: shifted left and covering a broader part of the screen.
- Tower Shield: far left and substantially larger.
- Magic Shield: more centered, with a second translucent sprite pass acting as a temporary magical halo.

The existing original 64×64 project shield sprites are reused and enlarged at render time. Exact HUD coordinates and sizes are provisional visual calibration values, not combat coverage or balance values. Mechanical coverage remains 120° / 140° / 160° / 120° according to shield type.

User-validated in the preceding test pass: native Fly lateral movement, ranged visual Zoom/ADS, ADS physical-accuracy behavior and Dexterity-scaled ranged Reload.

Manual validation:

1. Enter/leave Block once with each shield and confirm the layer follows the equipped type.
2. Confirm ranged ADS never displays a shield layer.
3. Confirm large/two-handed physical weapons still cannot enter Block.
4. Check that Buckler, Kite, Tower and Magic Shield remain readable at 1920×1080 without hiding critical HUD resources.
5. Break or unequip the shield and confirm the layer disappears.

## Zoom input latch, Fly lateral movement and roof diagnosis 4.26.5h

**Input/movement fixes implemented — roof rebuild pending**

Contextual Zoom now accepts exactly one transition per physical key press. GZDoom may revisit a weapon's native Zoom state while the button remains held; `CombatZoomInputLatched` ignores those repeated pulses and is cleared only when `BT_ZOOM` is released. This applies equally to ranged ADS and shield Block.

Native Fly sets the player to a no-gravity movement state. The Caelum acceleration layer previously required ground contact before increasing its movement factor, leaving Fly at factor zero if it began while stationary. `NOGRAVITY` movement is now treated as continuously supported for lateral acceleration, while ordinary jumping retains its existing no-air-acceleration rule.

The block beside the stairs is sector 6: its floor is physically raised to 136 MU and its ceiling remains at 512 MU. The player stands on that raised floor, so its top is a native walkable plane. The room is sector 4: its floor is 0 and its ceiling is 136 MU. A Doom-sector ceiling renders the underside, but its opposite side is not a second walkable plane. Consequently the room can have an interior ceiling without providing a roof surface above it.

A room with both usable interior space and a walkable roof requires a solid 3D-floor slab (planned from 128 to 136 MU) controlled by separate geometry. Simply raising the room floor would reproduce the stair block but destroy the interior; simply retaining the low ceiling cannot create a walkable upper surface. The next architectural pass must replace the current ceiling with that control-sector 3D floor and revalidate the door's target height.

Manual validation:

1. Hold Zoom for several seconds: ADS/Block changes only once.
2. Release and press Zoom again: the state toggles once in the opposite direction.
3. Enable native Fly while stationary and verify forward, backward and lateral movement.
4. Verify ordinary airborne movement still preserves momentum without ground-style acceleration.

## Upper-wall removal, true repeatable door and live Dexterity reload 4.26.5g

**Implemented — pending manual validation in GZDoom 4.14.2**

The finite middle textures introduced in 4.26.5f ended at roof height, but both sidedefs still carried upper `STARTAN3` textures. Those upper textures filled the room/outdoor ceiling difference and visually recreated the wall above the roof. They are now removed from both sides of all five room walls and both jambs.

The door-cycle limit was caused by using `repeatable`, which is not the valid UDMF repeat-special field. Both door thresholds now use `repeatspecial = true`, retain front/back player USE activation and operate the same door sector with the existing speed and 150-tic delay.

Ranged Aim is verified in the attack path: `RangedAimModeActive` multiplies `EffectivePhysicalAccuracyPercent` by ×2. Crouching supplies its own ×2 multiplier, so Aim + crouch still produces ×4 before the weapon spread calculation.

Reload now derives its effective duration from the player's current effective Dexterity at the moment Reload starts. The formula remains the authored Type-4 rule:

`effective seconds = base seconds × 100 / Type4(Dexterity)%`

The base durations remain Standard Bow 3 s, Longbow 3 s, Crossbow 5 s and Carbine 5 s.

Manual validation:

1. Verify that no wall texture reappears above the roof cut.
2. Complete at least four full door open/close cycles, alternating approaches.
3. Compare Reload at ordinary Dexterity and debug Dexterity 75 while observing the HUD countdown.
4. Verify that Zoom ADS remains visual and that ranged shots become more accurate.

## Finite room walls, repeatable door and contextual ranged Zoom 4.26.5f

**Implemented — pending manual validation in GZDoom 4.14.2**

The template room no longer uses infinitely wrapped blocking middle textures. Its five wall lines and two jambs now use bottom-pegged finite 3D middle textures, allowing their visible and physical height to follow the authored texture instead of extending to the outdoor 512-MU ceiling.

Both door thresholds retain repeatable tag-0 `Door_Raise` and now accept USE from their back side as well as their front side. This pass specifically targets the reported failure to begin a second open/close cycle.

Zoom is now contextual. Standard Bow, Longbow, Crossbow and Carbine toggle Aim with a real native ×2 FOV zoom. For non-ranged weapons, Zoom enters persistent Block only when the equipped weapon uses one-handed shield rules. Large and ranged two-handed physical weapons therefore cannot block through a shield that remains equipped. Ranged AltFire remains an alternate Aim input.

The normal HUD now displays `Magazine: loaded / capacity | Reserve: amount` while a ranged weapon is active, plus the remaining Reload time while reloading. Reserve excludes the rounds already represented by the loaded magazine.

Manual validation:

1. Room walls stop at their finite authored height instead of reaching the outdoor sky.
2. Complete at least three door open/close cycles, testing USE from both sides.
3. Equip a shield with a large or ranged weapon and verify that Zoom does not enter Block.
4. Equip a one-handed shield-compatible weapon and verify that Zoom still toggles Block.
5. Equip each ranged weapon and verify that Zoom changes FOV and the HUD reports magazine, capacity and reserve.
6. Fire and Reload while watching the HUD counts and Reload countdown.

## Bilateral wall rendering, dual-use door and ranged ammunition 4.26.5e

**Implemented — pending manual validation in GZDoom 4.14.2**

The room/exterior sector split from V4.26.5d was structurally valid, but an upper texture only fills the height difference above the lower ceiling; it does not draw the required wall from floor level. The five room walls and two jambs now retain bilateral sector ownership while also using explicit wrapped `STARTAN3` middle textures on both sides, matching MAP01's already visible test-wall vocabulary.

The inner room/door threshold now carries the same tag-0 manual `Door_Raise` special, speed and delay as the exterior-facing line. The exterior line remains non-blocking and the door sector remains the physical closure, so USE is available from both approaches.

Ranged ammo actors now declare `Inventory.Amount 20`. Firing checks the loaded magazine rather than requiring both a loaded magazine and a simultaneously accessible reserve stack. Reserve ammo remains the Reload source and is decremented when a shot consumes a physical round, but moving/exhausting the reserve cannot cancel a round already loaded in the magazine.

Manual validation:

1. All room walls and jambs render from exterior and interior.
2. USE opens the door from both approaches and the raised opening is passable.
3. Pickups provide 20 bullets/arrows/bolts.
4. Press Reload and wait for the weapon's 3/3/5/5-second base time.
5. Standard Bow, Longbow, Crossbow and Carbine each spawn the correct projectile and reduce the loaded magazine by one.
6. Empty magazines still require Reload; reserve ammunition alone is not a loaded shot.

## Bilateral room shell, usable door and environmental Adrenaline 4.26.5d

**Implemented — pending manual validation in GZDoom 4.14.2**

The isolated room's one-sided walls faced inward, leaving no exterior sidedefs to render from the field. The five room perimeter lines and two door jambs now separate their authored interior sectors from exterior sector 0 and use finite upper textures. They remain blocking walls, but both sides have valid sector ownership and visibility.

The outer manual door line is reversed so sector 0 is its front and door sector 5 is its back. `Door_Raise` therefore receives USE from the exterior-facing side and operates on the door sector behind the line. The permanent linedef blocking flag has been removed from this opening; the closed door sector supplies collision until its ceiling rises.

Environmental impact damage already skipped the direct received-damage Adrenaline event, but its shared Pain calculation could still grant Pain Adrenaline. Pain resolution now receives an explicit permission flag. Wall/floor impacts pass `false`; actor impacts and ordinary combat damage pass `true`. Environmental impacts may still cause Pain/stun, but neither their damage nor their Pain grants Adrenaline.

Manual validation:

1. The isolated room is visible from the exterior on every wall and jamb.
2. USE from outside raises the door, which becomes passable, waits and closes.
3. Walls remain solid and the room interior renders normally.
4. A damaging wall collision may reduce HP/cause Pain but never increases Adrenaline.
5. Actor-to-actor damage and Pain still grant their intended Adrenaline.

## Final stair front-side correction and input-roadmap audit 4.26.5c

**Implemented — pending manual validation in GZDoom 4.14.2**

After V4.26.5b, the engine accepted the door repair and reported only linedef 82 as lacking a front. That line closes the sixth 136-MU stair sector.

MAP01 now removes the two unreferenced door sidedefs left at indices 94 and 96 and remaps all subsequent live references. Linedef 82 is reversed together with its front/back assignment, preserving the same physical sector adjacency while making exterior sector 0 its explicit front and stair sector 12 its back. The map now contains 86 vertices, 83 linedefs, 154 sidedefs and 13 sectors; every sidedef is referenced exactly once and every sector boundary remains balanced.

Manual validation:

1. MAP01 loads without a line-82/front-sidedef error.
2. The sixth stair remains visible, solid and climbable.
3. The 136-MU platform remains walkable.
4. The template door retains its V4.26.5b behavior.

The roadmap input audit preserves the already implemented architecture: Zoom = Block, ranged AltFire = Aim and ranged Reload = magazine reload. User1 is the remaining slot for the future racial ability; User2 remains Seal Channel; User3 Tarot; User4 class ability.

## Canonical MAP01 topology correction and roadmap reconciliation 4.26.5b

**Implemented — pending manual validation in GZDoom 4.14.2**

The V4.26.5a diagnostic pass left four provisional appended sidedefs and explicit `sideback = -1` placeholders in the UDMF map. Although local index/boundary validation could parse them, the engine node builder still rejected lines 53, 54 and 82 and reported line 52's right edge as disconnected.

MAP01 now uses the canonical 156-sidedef set. Door jambs and the outer manual door line are true one-sided boundaries with no synthetic back-side field. The outer door uses its original sector-5 sidedef; the inner threshold uses the original room-front/door-back pair. All three one-sided door edges are consistently oriented around the sector.

Static validation confirms 86 vertices, 83 linedefs, 156 sidedefs and 13 sectors, with valid references and balanced sector boundaries. Manual engine validation remains authoritative:

1. MAP01 loads without the reported front-sector/front-sidedef errors.
2. No disconnected edge is reported for the template doorway.
3. USE raises the door; it waits and closes normally.
4. The last stair sector and 136-MU platform remain valid and walkable.

The former V4.22–V4.26 roadmap has been reconciled with current implementation status in `docs/ROADMAP.md`. The next major implementation block is V4.27 Combat Input Architecture and Mode Separation.

## Architectural template topology correction 4.26.5a

**Implemented — pending manual validation in GZDoom 4.14.2**

The isolated template door had been converted to branching two-sided geometry: both jamb lines incorrectly continued into the room sector and the outer manual door line exposed an unnecessary exterior back side. Although all referenced sidedefs existed, those branches broke the closed boundaries expected by the node builder; it consequently reported human-facing line 54 as lacking a valid front side.

The jambs and outer door line are now consistently oriented one-sided front boundaries of door sector 5. The inner threshold is a two-sided transition facing room sector 4, with door sector 5 on its back. Static validation confirms that every linedef has an existing front sidedef, every referenced sector exists, and every sector boundary has balanced incoming/outgoing endpoints.

Manual validation remains:

1. MAP01 loads without node/front-sidedef errors.
2. Facing the unlocked template door and pressing USE raises it.
3. The door waits and closes normally.
4. The room, jambs, six stair sectors and 136-MU platform remain physically valid.

## Architectural template room 4.26.5

**Implemented — pending manual validation**

A single MAP01 template room is used to validate architecture before replication.

Validation sequence:

1. MAP01 loads without node/front-sidedef errors.
2. The room walls render and block normally.
3. The doorway has visible jambs/opening.
4. Facing the door and pressing USE triggers the manual `Door_Raise`.
5. The door opens, waits, then closes.
6. The six stair sectors can be climbed from 24 to 136 MU.
7. The 136-MU platform is walkable.

No attempt is made in this patch to retrofit all existing rooms with the template. Replication is deferred until this exact module works correctly in GZDoom 4.14.2.

## Crouch physics, movement noise and MAP01 building rebuild 4.26.4

**Implemented — pending manual validation**

For wall impacts while crouching:

`AgilityBonusRatio = max(0, JumpZ/BaseJumpZ - 1)`

`CrouchWallFraction = clamp(AgilityBonusRatio, 0, 0.50)`

The physical collision and displacement remain unchanged. Only traumatic Delta-v is reduced. If buckler block is also active, its doubled fraction is compared against the crouch fraction and the maximum is used; the two effects do not stack.

Sigilo is now explicitly calculated from Agility Type 2:

`Stealth% = clamp(Agility(Agility+1)/101, 0, 100)`

Crouch x2 remains authoritative and is capped at 100%. Movement hearing:

`NoiseRange = BaseRange × MovementMode × (1 - EffectiveStealth/100)`

with BaseRange = 20 m reference (622.22 MU), walking = 1.0, running = 1.5, crouching = 0.5. At EffectiveStealth = 100%, no movement alert is emitted.

MAP01 uses finite wall sectors with floor 136 MU and sky ceiling 512 MU. Interior sectors remain floor 0 and receive the shared 3D roof slab 128–136 MU. Two staircases reach roof level. All generated sectors pass closed-loop endpoint validation and every linedef has valid front/back sidedef and sector references.

## Buckler/map corrective pass 4.26.3b

**Implemented — pending manual validation**

The rodela no longer mixes direct JumpZ units with horizontal collision Delta-v. For horizontal impacts:

`AgilityBonusRatio = max(0, JumpZ / BaseJumpZ - 1)`

`BucklerHorizontalFraction = clamp(2 × AgilityBonusRatio, 0, 0.50)`

`TraumaticDeltaV = RawDeltaV × (1 - BucklerHorizontalFraction)`

This means the buckler can at most halve horizontal traumatic Delta-v; it can no longer manufacture `Delta-v = 0` / infinite equivalent tics. Its `2 × Toughness` rule remains unchanged, so a sufficiently tough buckler user may still end with zero final HP damage after the kinematic calculation. Stun continues to disable Agility damping.

MAP01 validation focus: finite room-wall height, real walkable 3D roofs, east-room door orientation, roof staircase, NPC-room roof bounds, item placement and absence of invisible room barriers.

## Buckler acrobatics and fall-test map 4.26.3

**Implemented — pending manual validation**

Active buckler block uses `2 × Toughness` for CaelumImpact tolerance and `2 × JumpZ` as Agility absorption. The latter applies to floor, actor and wall trauma. Stun sets active Agility absorption to zero. The buckler still uses 0.5× effective combat mass, so it remains easier to launch while making that displacement defensively survivable.

At V4.26.3, MAP01 had seven roofed structures: six equal test rooms plus the west NPC room. V4.26.5n supersedes that count with eight one-trap-door room instances. Outdoor vertical space remains 512 MU.

## Universal impact scale and anatomy response 4.26.2

**Implemented — pending manual validation**

The kinetic reference distance is now fixed at 28 MU for every body:

`T_impact = 28 / |Delta-v|`

This removes the previous double size effect in which large actors benefited both from greater mass during impulse resolution and from a larger height numerator during severity conversion.

Impact Physics Core remains anatomy-agnostic. It exposes only normalized contact-height intervals. Caelum interprets those intervals using `CaelumAnatomyProfile`, normalizes all overlapping region spans, and applies vulnerability and armor proportionally.

For each contacted region `i`:

`w_i = overlap_i / sum(overlap)`

After the V4.26.1 subtractive Toughness threshold:

`S_i = S_postToughness × w_i × Vulnerability_i × (1 - ArmorDefense_i)`

`S_final = sum(S_i)`

Critical/head Lucidity contribution uses the same `w_i`; non-critical regions contribute zero critical-point Lucidity loss. Local armor defense reduces the corresponding contribution.

Floor contact is represented as normalized height 0.0 and therefore maps to the lowest authored anatomy region. Actor-to-actor contact uses actual vertical cylinder overlap. Static vertical geometry currently uses 0.0-1.0 because native GZDoom line collision does not provide an anatomical Z contact point.

NPC controlled-landing absorption now follows Agility Type-1 jump scaling, matching the player design concept instead of scaling by actor height.

## Impact response refinement 4.26.1

**Implemented — pending manual validation**

Impact Toughness is now a threshold/tolerance measured in percentage points of maximum health. If the energy curve produces `S%` after the source-surface modifier:

`S_post = max(0, S - Toughness)`

`D_preArmor = HP_max × S_post / 100`

`D_final = D_preArmor × (1 - GlobalImpactArmor/100)`

This deliberately makes high Toughness completely ignore ordinary kinetic trauma while preserving vulnerability to sufficiently extreme impacts.

Static geometry requires at least 25% of pre-impact horizontal speed to be lost before the contact is considered an impact. Once static contact occurs, it remains latched until five consecutive unblocked tics have passed.

Environmental wall/floor impacts do not generate received-damage Adrenaline. Actor-to-actor impacts continue to do so.

## Impact Physics Core API 4.26.0

**Implemented — pending manual validation**

Generic physics is now separated from Caelum damage interpretation. `ImpactPhysics` resolves finite-body, static and external-source impacts and returns a neutral `ImpactResult`. Caelum adapters remain responsible for effective shield mass, biological landing damping, Toughness, armor and HP.

Static geometry is now modeled as the infinite-mass limit of the same physical model. The player-wall exception introduced during early calibration has been removed. The velocity component actually lost by native GZDoom movement defines the effective static collision normal.

**Convergence validation:** a character hitting increasingly massive movable bodies should approach the result of hitting static geometry. The existing mass-10000 training dummy is the primary MAP01 comparison against walls/doors.

**Export status:** the core source is isolated under `/impactphysics/` and contains no Caelum-specific class references. Packaging/licensing/versioning it as a standalone PK3 is planned after the API survives this validation pass.

**Melee integration:** intentionally deferred. Weapon mass can eventually feed an impact model, but melee also needs swing velocity, effective striking mass, contact area/edge geometry, material penetration, sharpness and attack technique. Existing melee damage remains authoritative until those variables are designed.

## Energy impact curve and contact rearm 4.25.4

**Implemented — pending manual validation**

Impact severity no longer uses discrete 3% damage steps. For `T_eq < 35`:

`R_v = 35 / T_eq`

`R_E = R_v²`

`Damage% = 100 × (R_E - 1) / (35² - 1)`

At or above 35 tics the result is zero. This normalization produces exactly 100% raw max-HP damage at one equivalent tic. Below one tic the same continuous quadratic curve remains active and may exceed 100%.

This is intentionally based on **specific kinetic energy** rather than total `1/2 m v²`. Mass already determines the action/reaction impulse and each body's resulting `Delta-v`; multiplying injury by mass again would double-count mass.

Contact rearm now requires true disengagement. A collision pair stays latched until center separation exceeds `RadiusA + RadiusB + 0.25 × min(HeightA, HeightB) + 2` for five consecutive tics. This is designed to reject tiny recoil gaps produced while holding movement against another body.

Existing V4.25.3 acceleration, biological landing damping, Toughness, armor mitigation and actor-to-actor momentum equations are unchanged.

## Acceleration and biological impact response 4.25.3

**Implemented — pending manual validation**

Player horizontal locomotion now uses an exponential acceleration state. With uninterrupted grounded directional input:

`A(n) = 1 - (1 - 0.028127624)^n`

At 105 tics (3 seconds) the factor is exactly 0.95. `A` multiplies the existing movement result, so the final maximum remains determined by Agility, LoadRatio, health/Air/survival state and shield mobility.

Self-powered wall impact severity also multiplies by this acceleration state. This makes run-up distance physically meaningful without changing the already validated actor-to-actor impulse equation.

Actor collisions now latch by contact pair. A collision is not eligible to resolve again while the same bodies remain touching; separation beyond their combined radii plus a small technical margin rearms the next impact.

Floor impacts now have a biological-damping layer before Toughness and armor. Player controlled landing absorption equals current `JumpZ`. Stun/physical immobilization sets that absorption to zero. CaelumCombatActor NPCs use height-scaled biological absorption and likewise lose it while lucidity-stunned.

**Validation focus:** acceleration feel and 95%-at-3s timing; short-run vs long-run wall impacts; sustained push against the 10000-mass dummy; ordinary jump landing; stunned landing; high falls that exceed biological absorption.

## Impact mitigation and calibration 4.25.2

**Implemented — pending manual validation**

Raw impact severity now passes through Toughness and global armor defense before health loss. The armor term is the simple arithmetic mean of all four armor-slot defenses; this avoids inventing location weights before a separate impact-location design exists.

Player wall-impact severity is normalized against effective movement percentage rather than raw GZDoom velocity. A 100% full frontal stop maps to 35 equivalent tics; load and movement-state penalties therefore reduce self-powered wall severity. A contact latch prevents repeated damage while continuously pressing against the same blocking geometry.

Landing detection now stores falling vertical velocity from prior tics and resolves damage on the next grounded state. Player impact reference height is the stable derived actor height.

Training dummy: movable, mass 10000, valid collision body.

Rulo/Caella/Ronnie/Argento already carry `CaelumCombatActor` profiles and T1 armor; V4.25.2 now allows these statistics to mitigate impact damage too. Generic Doom actors do not yet have a Caelum profile adapter.

## Momentum collision and impact physics 4.25.1

**Implemented — pending manual validation**

The collision foundation now resolves Caelum character/NPC contacts through a two-body impulse model. Effective combat mass participates in the impulse, so Buckler (`x0.5`) and Tower Shield (`x2`) naturally change both outgoing and self collision response. The normal coefficient of restitution is currently `e = 0`, producing an inelastic character collision rather than a bounce.

Each body independently converts its forced `Delta-v` into an equivalent time to cover half of its own height. More than 35 equivalent tics is non-damaging. From 35 down to 1 tic, each discrete threshold adds 3% maximum-health base damage, reaching 105% at one tic or less.

The same impact evaluator is connected experimentally to blocked horizontal world movement and floor landings. Impact damage currently bypasses evasion, shield Block and localized armor so the test build exposes the raw physical scale without hidden mitigation.

The debug overlay displays last impact kind, Delta-v, equivalent tics, damage percent and base damage. Internal fields also preserve effective masses, closing speed and impulse for calibration.

Carbine Reload base time is corrected to 5 seconds. Ranged Reload bases are now 3/3/5/5 seconds.

Detailed design: `docs/PHYSICS_COLLISION_SYSTEM.md`.

## Ranged weapon architecture 4.25.0

**Implemented — pending manual validation**

The four definitive ranged weapons now have independent magazine state and Reload behavior. Standard Bow and Longbow each hold 50 shots, Crossbow 20, and Carbine 10. Magazine capacity does not scale with tier. Reload base durations are 3 seconds for both bows, 5 seconds for Crossbow, and 10 seconds for Carbine; effective duration is divided by the Dexterity Type-4 attack-speed multiplier.

AltFire now toggles Aim for ranged weapons rather than trying to reuse the shield input. Aim multiplies physical accuracy by 2.0 and stacks with the existing crouch accuracy multiplier of 2.0. Native Zoom remains the independent persistent Block toggle.

Ranged damage is intentionally attribute-independent at the base-damage layer and therefore has been raised substantially. T1 bases are Standard Bow 1200, Longbow 1800, Crossbow 1400, and Carbine 3600. Ranged tiers use 100% / 160% / 250%, producing T2/T3 damage of 1920/3000, 2880/4500, 2240/3500, and 5760/9000 respectively.

Base critical chance scales with the same 100% / 160% / 250% tier multipliers before the Dexterity critical bonus is added. T1 bases are Standard Bow 10%, Longbow 12%, Crossbow 8%, and Carbine 6%.

The authoritative spread ladder is Minimum 10°, Very Low 30°, Low 50°, Medium 70°, High 90°, Very High 110°, Maximum 130°. Minimum spread is always 10% of maximum. Current ranged assignments are Standard Bow Very High (11°–110°), Longbow Medium (7°–70°), Crossbow High (9°–90°), and Carbine Maximum (13°–130°).

### Equipment-data audit

The executable remains the source checked for equipment values. Shield T1 weights are Magic 4, Buckler 8, Kite 12, Tower 16; documentation entries using older 14/18 values for Kite/Tower are obsolete. Physical-weapon T1 weights and catalogue combat values have been rechecked against `CaelumWeaponModel` and `CaelumWeaponCatalogue`.

## Connected crafting infrastructure 4.23.3a

**Implemented — pending validation**

The world-sprite alignment table has been restored from the validated 4.22.4c
configuration while retaining the twelve crafting-station sprites. The
training dummy and floor gallery therefore again use their corrected paths and
offsets.

Crafting close input now has a dedicated UI processor. This is necessary
because GZDoom routes input through `UiProcess` instead of `InputProcess` while
its GUI owns keyboard focus; `Q` is forwarded to the existing networked
crafting toggle in either input mode.

All twelve infrastructure actors now use dedicated project-local station
sprites rather than temporary weapon/equipment placeholders. Their source
cards were normalized for the sprite namespace and registered in
`ASSET_REGISTER.md`.

The crafting overlay now accepts its close command while GZDoom retains
`menuactive`, removing the previous requirement to press Escape before `Q`.

### Input regression note

The experimental global crafting UI processor has been removed because it
interfered with character creation at map start. Crafting input is temporarily
back on the stable 4.23.2 path; the requirement to close residual native menu
focus before `Q` may still occur and remains pending a safer implementation.


Crafting infrastructure forms a graph at interaction time. Two
`CaelumCraftingStation` actors are directly linked when their three-dimensional
distance is at most 64 map units, equal to exactly two development metres.
Connectivity is transitive, so a station can belong to the same workshop even
when it is farther than two metres from the Workbench if connected stations
bridge the distance.

The Workbench is the logical root of the interface. Using any station scans
its complete connected component and opens the same Workbench menu. A
component without a Workbench is rejected with a localized message. The scan
runs only on interaction and uses a per-player token to avoid recursion cycles
and cross-player scan collisions.

The twelve planned infrastructure actors currently exist: Workbench, Forge,
Anvil, Ranged Weapons Workshop, Sawmill, Armor Workshop, Sewing Machine,
Essence Altar, Globe, Jeweler Bench, Fine-tools Bench, and Master Bench. All
inherit `CaelumMovableProp`; their push requirement remains unset, so they
cannot yet be moved. Final station mass and physical-power requirements remain
deliberately pending for the later environment pass.

Tier requirements are cumulative. Forge recipes require Workbench + Forge at
tier 1, additionally Anvil at tier 2, and additionally Master Bench at tier 3.
Ranged-weapon recipes require Workbench + Ranged Weapons Workshop at tier 1,
additionally Sawmill at tier 2, and additionally Master Bench at tier 3. The
same architecture is reserved for Armor Workshop/Sewing Machine, Essence
Altar/Globe, and Jeweler Bench/Fine-tools Bench once those recipe families are
authored.

The Workbench menu currently exposes sixteen physical recipes: twelve Forge
recipes plus standard bow, carbine, longbow, and crossbow from the Ranged
Weapons Workshop. The interface reports whether the selected recipe's
infrastructure is ready and names the first missing station. Material
requirements, ownership checks, Magic Box routing, and the existing crafting
transaction remain unchanged.

MAP01 contains four infrastructure tests: a full twelve-station network, a
Workbench+Forge tier-1 network, a Workbench+Forge+Anvil tier-2 network, and an
isolated Forge that must reject interaction because no Workbench is connected.


### Armor and essence recipes

The unified Workbench currently exposes 52 recipes. Recipes 1–16 are the
physical weapon catalogue. The next 16 cover all four armor types across all
four body slots. The final 20 cover the four essence weapons with each of the
five elemental essences.

Armor material logic is weight-based and uses the existing material-unit
rounding system. Strap is always the base component. Fabric, Leather,
Chainmail, and Plate are the tier components for Magic, Light, Medium, and
Heavy armor respectively. Head/Body use 20% Strap and 80% tier material;
Hands/Feet use 60% Strap and 40% tier material.

Magic and Light armor require Workbench + Armor Workshop at tier 1, add Sewing
Machine at tier 2, and add Master Bench at tier 3. Medium and Heavy armor use
Workbench + Forge, add Anvil at tier 2, and add Master Bench at tier 3.

Essence weapons use 90% of their corresponding base material and 10% elemental
essence by final weapon weight. Tier 1 requires Workbench + Essence Altar,
tier 2 additionally requires Globe, and tier 3 additionally requires Master
Bench. The resulting weapon stores the selected essence on the native
equipment item.



This file describes the current executable prototype. The main design document
remains the authority for rules not yet connected to gameplay.

## Definitive physical weapon and recipe catalogue 4.12.0

**Implemented as authoritative data — pending playable crafting**

The code now defines all sixteen physical weapons in families 2 through 5:
dagger, hatchet, machete, javelin, sword, axe, flail, spear, greatsword, war
axe, halberd, giant gauntlets, standard bow, carbine, longbow, and crossbow.
Each entry centralizes primary/secondary damage, damage type or special action,
attack cadence, range, spread, critical chance, air cost, family, and shield
interaction. The carbine retains 360 damage/48 tics/60 m/30°–200°/0%/-20;
the longbow retains 180 damage/24 tics/30 m/10°–120°/12%/-10.

Every physical recipe now names one main component, one secondary component,
and the exact component that supplies its tier. Spear and javelin use shaft +
point and take the point's tier. Flail replaces the discarded one-handed mace
and uses round head + generic chain. Giant gauntlets remain the fourth large
weapon; the two-handed mace, saber, and their unused unique parts are absent.

Small weapon head and chain complete the active material catalogue. All 41
active material types are referenced by at least one physical, armor, shield,
or essence recipe. The old iron-ingot prototype is hidden from new selections
but its class and identifier remain available for save compatibility. Exact
component quantities and actual inventory consumption remain pending until the
global material-requirement formula is defined.

The console command `ca_debug_audit_crafting_catalogue` performs a read-only
runtime audit. Its expected result is 16 weapon recipes, 41 active materials,
and 0 unused materials.

## Native material catalogue and lock test 4.11.0

**Implemented — pending validation**

The Materials filter now exposes a data-driven catalogue of weapon parts,
shield plates, armor resources, elemental essences, secondary components, and
magical-item bases. Metal, wood, essence, leather, and fabric use three
localized grades; generic secondary components remain tier-independent.

Every material is a native `Inventory` instance. Type and tier together define
stack identity, so identical units merge while different grades remain
separate. Each unit weighs 0.1 by default, participates in automatic overweight
routing, and a complete stack occupies one Magic Box slot and weighs zero while
stored there.

`ca_debug_test_silver_lock` invokes `CheckKeys(200, true, false)`. This follows
the same native `LOCKDEFS` path used by locked map specials: without the silver
key it prints the configured remote failure message; with the key it confirms
access. A real door still declares lock number 200 in its map-line special.

## Categorized special inventory and native locks 4.10.0

**Implemented and manually validated**

The authoritative `Actor.Inv` chain now includes three additional categories:
Materials, Keys, and Key Items. The compact inventory cycles through eight
separate filters: armor, shields, weapons, ammunition, consumables, materials,
keys, and key items. Equipment retains its equipped/unequipped state and every
eligible object can still expose its Magic Box location.

The first test catalogue contains a stackable iron ingot, a native silver key,
and a unique sealed letter. Their default unit weight is 0.1. Materials use
their `Amount` as the load multiplier and a complete stack occupies one Magic
Box slot. Key items are non-stackable and can also enter the box.

The silver key derives from GZDoom's native `Key`, so the engine itself prevents
duplicates and recognizes it through `LOCKDEFS`. Lock number 200 can be passed
to locked door specials or ACS locked actions. Keys deliberately remain in
personal inventory: GZDoom's lock check only tests ownership and cannot see
Caelum's `InMagicBox` field, so boxing the same native key would otherwise leave
the lock usable. Its 0.1 weight always contributes to carried load.

GZDoom also provides `PuzzleItem`, Strife quest/dialogue infrastructure, HUD
messages, and programmable ZScript UI. These are reusable foundations for the
future mission pass, while Caelum will still own the general objective tracker
and presentation layer.

## Native consumables and timed regeneration 4.9.0

**Implemented and manually validated**

Life potion, Anima potion, energy drink, food ration, and water ration are now
stackable native GZDoom inventory objects. Their respective unit weights are
0.25, 0.25, 0.25, 0.10, and 0.10. Personal-inventory stacks contribute
`Amount × unit weight`; a complete stack occupies one Magic Box slot and weighs
zero while boxed. An overweight pickup follows the already validated native
overflow rule, and a full Magic Box leaves it in the world.

Using an item consumes one unit through GZDoom's native inventory path and
creates a ten-second Powerup. It applies one pulse per second: life restores 1%
of maximum health, Anima restores 1% of maximum Anima, the energy drink restores
1% of maximum air plus one sleep point, and each ration restores one hunger or
thirst point. Reusing the same item refreshes its remaining duration to ten
seconds instead of adding a second simultaneous intensity.

The compact inventory interface includes a Consumables filter. Left/Right
selects the item, `P` creates a five-unit test stack on the floor, Enter/E uses
one unit, `C` moves the complete stack between personal inventory and the Magic
Box, and `D` drops it. Native previous/next/use inventory commands are also
available under Customize Controls.

## Native inventory shadowing correction 4.8.1

**Implemented and previously validated**

The 4.8.0 native objects were collected correctly, as confirmed by `printinv`,
but ZScript's case-insensitive identifiers caused two parameter/field name
collisions. The equipment matcher compared its tier/type/slot/size parameters
against themselves, and the carried-load setter wrote calculated weights back
into its temporary parameters. Both interfaces now use unambiguous parameter
names, so ownership selection and weight propagation retain the values stored
in each native inventory instance.

## Native inventory and Magic Box object state 4.8.0

**Implemented and previously validated**

Armor pieces, shields, weapons, and carbine bullets are now real GZDoom
inventory objects. The player's native `Actor.Inv` chain is the single source
of ownership, quantity, and carried weight; collecting equipment no longer
deletes the pickup and replaces it with a parallel boolean record. Every
non-stackable instance stores its own slot/type, tier, size, durability,
equipped flag, Magic Box flag, and unit weight.

Equipping and removing only changes the equipped flag. Moving an object to the
Magic Box changes its carried contribution to zero while retaining the same
native object. A non-stackable instance uses one box slot. Carbine ammunition
uses its native `Amount`: any quantity remains one stack and therefore uses one
box slot. Outside the box its weight is `Amount × 0.003`; inside it weighs zero.

Immediately after the first character-creation confirmation, the four armor
pieces, profession shield, sword, staff, carbine, and 100-bullet stack appear
as nine pickups on the floor in front of the character. The character owns
nothing until those pickups are collected. If a pickup would exceed capacity,
it enters the Magic Box when a slot exists; otherwise it stays in the world.

The compact equipment menu can inspect the native objects, equip or remove
them, move them to or from the Magic Box, break them, and drop them. Its load
breakdown and the permanent HUD are rebuilt directly from native inventory on
every refresh. Legacy persistent equipment can be migrated once into native
instances for save compatibility.

## Authoritative persistent carried load 4.7.8

**Implemented — pending validation**

Every owned armor piece, shield, weapon, and bullet outside the Magic Box is
now summed exactly once from the persistent object registry. Equipped state is
used only to divide that authoritative value into equipped and personal
inventory subtotals; it can no longer decide whether an object contributes to
total carried weight. The complete breakdown is written atomically before mass,
movement, jump, evasion, air consumption, and HUD values are recalculated.

The permanent load display now prints its localized state next to the
percentage: normal below 75%, overload from 75%, and capacity exceeded from
100%. Its thresholds match the bar colors and gameplay state helpers.

## Atomic carried load and multi-weapon equipment 4.7.6

**Implemented — pending validation**

Inventory weight, equipped weight, ammunition weight, and development weight
now refresh `EquippedWeight`, `CarriedWeight`, `TotalMass`, and `LoadRatio`
atomically. This removes the stale-value route where opening the equipment menu
updated the inventory subtotal before the next gameplay tick and prevented that
tick from recognizing that a complete recalculation was still required.

Equipped and active weapons are now separate states. Any owned weapon can be
equipped without removing weapons from other families. Every equipped weapon
contributes its weight, but only one is active in the player's hands. Native
weapon-family buttons select the active test weapon: `3` sword, `5` carbine,
and `6` staff. Unequipping the active weapon automatically selects another
equipped family when one exists.

The equipped flags persist independently for every weapon/type/tier/size
combination. Saves from the single-weapon implementation migrate their previous
active weapon as equipped. Moving a weapon between personal inventory and an
equipment slot does not change total carried weight; moving it from the Magic
Box does.

## Post-creation starting equipment and ammunition weight 4.7.5

**Implemented — pending validation**

A new player owns no armor, shield, weapon, or carbine ammunition while the
character creator is open. Confirming the final page grants the development
loadout exactly once, using tier 1 and the default compatible size calculated
from the completed character.

Sword, staff, and carbine are always granted for testing. Sword begins equipped;
staff and carbine begin in personal inventory. The carbine begins with 100
bullets. Each bullet weighs 0.003, and current ammunition now contributes to
personal-inventory and carried weight, so firing reduces load by 0.003.

Starting armor and shield depend on the resulting profession:

- Warrior: heavy armor and tower shield.
- Mercenary, cleric, and battle mage: medium armor and kite shield.
- Explorer, pilgrim, and investigator: light armor and buckler.
- Pure priest, mage, and arcanist: magic armor and magic shield.

Armor uses its authoritative per-piece tier table in both equipped and
personal-inventory calculations, followed only by the established size
multiplier. This keeps previewed item weight and actual carried load identical.

## Personal inventory and overflow Magic Box 4.7.4

**Implemented — pending validation**

The personal inventory now exists independently from equipment and the Magic
Box. It has no item-slot limit: every unequipped object stored there contributes
its complete tier/size weight to carried load. Equipped weight, personal-
inventory weight, and development test weight form the load used by the HUD,
movement, evasion, air consumption, total mass, and push resistance.

When collecting or creating an object, the system first checks whether its
weight fits without exceeding carry capacity. If it fits, it enters personal
inventory. Otherwise it is redirected to the Magic Box; only this overflow
storage consumes its Intelligence-derived slots. If overflow is required while
the box is full, the pickup remains in the world.

Equipping an inventory object only changes its location and therefore does not
change carried weight. Equipping directly from the Magic Box adds its weight
and is rejected when capacity is insufficient. Unequipping returns the object
to personal inventory. The compact menu reports location, inventory count,
equipped slots, box usage, and the complete weight breakdown. Saves from 4.7.3
migrate their previously unequipped objects to the Magic Box.

## Persistent playable weapons 4.7

**Implemented — pending validation**

Sword, staff, and carbine are now real main-hand equipment records rather than
an isolated weight placeholder. Every weapon/type/tier/size combination owns
independent durability, uses XS–XL compatibility, records its current storage
location, and survives save/load and map travel. Existing 4.6 profiles
migrate their provisional weapon weight to a size-aware sword, staff, or
carbine without invalidating the earlier equipment data.

The compact equipment menu has a third Weapons filter. It previews damage,
attack time, base air/Anima cost, weight, compatibility, durability, and
carbine bullets. `P`, `Enter`, `Backspace`, `B`, and `D` use the same spawn,
equip, remove, break, and drop flow already used by armor and shields.

Every owned weapon may be equipped independently. Numeric family slots choose
only the active weapon: sword uses 3, carbine uses 5, and staff uses 6. Sword
retains physical Strength/mass damage and its 14-tic cadence; staff retains
Intelligence damage, Insight accuracy/critical, adjusted Anima cost, and
Eloquence casting speed. Carbine uses 360 tier-one damage without an attribute
damage multiplier, 48 tics, 60 m, 30°/200° accuracy-scaled spread, 0% weapon
critical base, 20 air per reload, physical push, and one bullet per shot.
The confirmed starting loadout grants 100 test bullets. AltFire toggles the
equipped secondary-hand shield; weapon secondary attacks remain reserved.

Tier damage uses the documented 1.00/1.20/1.50 material progression. Weapon
weight uses 1.00/1.50/2.00 and size 0.50/0.75/1.00/1.25/1.50. Test durability
bases are sword 100, staff 80, and carbine 120, followed by the existing
×1/×3/×9 tier rule and size multiplier.

Carry capacity is written directly as
`BaseMass × Type4Percent(Strength) / 100`. Therefore a 200-mass character has
200 capacity at Strength 0 and 600 at Strength 100.

## Carry capacity, magic armor, and equipment testing 4.6.2

**Implemented — pending validation**

Carry capacity is now `Strength Type 4 × (BaseMass / 100)`. Equipment weight
remains excluded from that multiplier and continues to form the numerator of
the load percentage. The tier-one, size-M carbine weight is now 12.

The basic equippable category is now named “magic armor” in
source, UI, tables, and documentation. This is a terminology-only migration:
its stored numeric value remains zero, so existing saves and owned equipment
records stay compatible. It remains separate from the zero-stat base clothing
used when a slot is genuinely empty.

The equipment menu accepts `P` to create its selected object through the pickup
rules. It enters personal inventory when its weight fits or the Magic Box when
it does not; `E`/`Enter` equips, `U`/`Backspace` removes, and `D` drops it.

## Compatibility and equipment HUD 4.6.1

**Implemented — pending validation**

GZDoom 4.14.2 does not accept the two `GetMaximumDurabilityFor` signatures as
overloads. The unused two-argument wrappers were removed; every active caller
uses the size-aware three-argument function.

The right-side HUD now includes carried weight, carry capacity, and percentage
in a dedicated bar. Its fill changes from green to yellow at 50%, orange at the
75% overload threshold, and red at 100% or more.

Removing armor now equips a non-item baseline according to slot: nothing on
head and torso, shirt on hands, and pants on feet. Baseline entries have zero
defense, weight, reinforcement, and durability, are never damaged, and do not
occupy the Magic Box. The existing equippable magic-armor set remains separate.

The short bow catalogue entry is replaced by the tier-one carbine. Its
values are 360 damage, 48 tics, 60 m, 30°/200° spread, 0% base critical chance,
-20 air, and size-M weight 12. Version 4.7 connects this record to its playable
projectile, bullets, inventory ownership, and persistent equipment model.

Status legend:

- **Implemented — pending validation:** compiled into the 4.0 source and ready
  for Damian's GZDoom 4.14.2 test pass.
- **Implemented and previously validated:** retained behavior that had already
  passed manual testing before 4.0.
- **Prepared:** a calculated value exists, but no final gameplay consumer exists.

## 4.0 compatibility repair

**Implemented — pending validation**

- Actor states use unscoped actions compatible with monster state chains. Each
  action casts `self` to `CaelumCombatActor` before accessing custom members.
- Player collision dimensions use GZDoom's `A_SetSize`; `Radius` itself is a
  readonly ZScript field and cannot be assigned directly.
- Effective actor Dexterity and Insight are cached in play scope. The UI overlay
  reads those fields instead of illegally calling play functions.
- The cascading unknown identifiers reported in actor debug page six are
  consequently removed.

## Character creation 4.1

**Implemented — pending validation**

The legacy three-layer creation model is replaced by eight pages. The only
structural character categories are Race and two Class selections; the second
class resolves the resulting profession:

1. Race.
2. First class.
3. Second class and resulting profession.
4. Sex.
5. Height.
6. Four family points.
7. Thirty individual points.
8. Summary and confirmation.

New characters now open this flow automatically. Until confirmation, ordinary
movement and attacks are blocked, resource simulation is paused, and the
unfinished character cannot receive damage. Keyboard controls are Right/Down,
Enter, Space, and Backspace/Left; gamepads use D-pad, A, X, and B. The confirmed
profile and completion flag persist in saves and in an inventory-backed travel
record. Changing maps therefore restores the confirmed character instead of
opening the creator again.

Races contribute Physical / Technical / Social / Mental values:

| Race | Values | Mass tier | Size tier |
|---|---:|---:|---:|
| Beast Man | 5/3/3/1 | +2 | +1 |
| Caelith | 3/5/1/3 | +1 | 0 |
| Human | 3/1/5/3 | 0 | 0 |
| Goblin | 1/3/3/5 | -1 | -1 |

Classes use Warrior 5/3/3/1, Explorer 3/5/1/3, Priest 3/1/5/3 and Mage
1/3/3/5. The two selections are order-independent and resolve to Warrior,
Explorer, Priest, Mage, Mercenary, Cleric, Battle Mage, Pilgrim, Investigator,
or Arcanist.

The family allocation keeps four points and a base limit of 15. Individual
allocation keeps thirty points, at most +5 per attribute and never above twice
the attribute's family base.

## Attributes, Anima, and Eloquence

**Implemented — pending validation**

- The attribute retains its definitive `Resilience` name in source and UI.
  Internal “survival resources” still refer collectively to hunger, thirst,
  and sleep and are not the attribute name.
- `Mana` is renamed `Anima` throughout the executable prototype.
- Eloquence Type 4 increases casting speed. The test staff duration is
  `18 tics × 100 / Type4Percent(Eloquence)`.
- Eloquence Type 2 reduces Anima cost by `n(n+1)/101%`; cost reaches zero at
  level 100 and cannot become negative.
- Eloquence Type 4 ability range and Type 2 dialogue skill are calculated and
  visible on the magic debug page. They are **Prepared** for later abilities
  and dialogue consumers.

## Mass and size tiers

**Implemented — pending validation**

Mass tier is clamped from 1 to 10 and maps to 50, 55, 60, 70, 80, 100, 120,
140, 170, or 200 kg. Size tier is clamped from 1 to 7 and maps to:

| Tier | Height in metres | Actor Height | Actor Radius |
|---:|---:|---:|---:|
| 1 | 1.20 | 37.3 | 10.7 |
| 2 | 1.40 | 43.6 | 12.4 |
| 3 | 1.60 | 49.8 | 14.2 |
| 4 | 1.80 | 56.0 | 16.0 |
| 5 | 2.00 | 62.2 | 17.8 |
| 6 | 2.20 | 68.4 | 19.6 |
| 7 | 2.40 | 74.7 | 21.3 |

The body-mass multiplier is `BaseMassKg / 100`. It affects maximum health,
physical attack power, physical push, carry capacity, air consumption, hunger
loss, and thirst loss. Equipment remains separate and continues to affect
load, movement, evasion, knockback, and additional air use.

Push is live for the player's sword and staff, Caelum actor melee attacks, and
physical or magical Caelum projectiles. Physical attacks use
`Strength Type 1 × body mass`; magical attacks use `Intelligence Type 1`.
The final force is `8 × attack push multiplier × receiver knockback multiplier`.
It only occurs after positive health damage; misses, evasion, and fully
prevented damage do not push. The training dummy's exceptional native mass keeps
it stationary. The combat page displays the last player-attack push force.

The development controls provide separate level-75 and level-100 attribute
overrides. Enabling one disables the other; toggling the active option again
restores the character's ordinary profile.

## Armor and equipped mass

**Implemented — pending validation**

Every armor piece now exposes its documented weight. At size M, full-set totals
for tiers 1/2/3 are 5/7/10 magic armor, 10/15/20 light, 20/30/40 medium, and
40/60/80 heavy. The exact per-piece tier table is applied before the equipment-
size multiplier. Broken pieces retain their weight. Shield and equipped-weapon
weights are included automatically, and debug-added mass is shown separately.

The current loadout is mirrored into an invisible, undroppable GZDoom inventory
record. It preserves profile, allocations, resources, equipped items, ownership,
and the individual durability of every armor/shield type, tier, and size
combination across saves and map travel. Existing pre-size ownership records
migrate automatically to size M.

`CaelumArmorPickup` and `CaelumShieldPickup` are functional world pickups. Map
authors configure armor with args `slot/type/tier/size/durability` and shields
with `type/tier/size/durability`; size zero remains a backwards-compatible M
default. Duplicate pickups retain ownership and repair that stored copy up to
maximum durability. A separate compact equipment interface cycles owned or
unowned previews, equips selected compatible objects, removes armor to its
zero-stat base clothing, and can fully unequip shields. Every change immediately
recalculates attribute bonuses, defense, reinforcement, mass, movement,
evasion, air cost, and shield blocking. A development control spawns the
currently previewed pickup.

## Area damage

**Implemented — pending validation**

Damage carrying `DMG_EXPLOSION` cannot be evaded. GZDoom first supplies the
distance-adjusted radial damage for the actor; Caelum then intersects the
explosion sphere with that actor's authored anatomy volumes. The supplied base
damage is applied once per touched region, and each application independently
resolves natural vulnerability, armor reinforcement, defense, Toughness, and
durability. The resulting health damage is summed into one final hit.

For the humanoid profile this produces at most four applications: head, torso,
arms, and legs. Both arms are one logical region: touching either or both counts
only once. A low explosion may therefore affect only legs, a larger wave from
below may affect legs and torso, and a full-body intersection resolves all four.
Separate authored non-arm regions remain independent, allowing future actors to
define multiple heads, tails, or weak points without changing this pipeline.

Pain and damage-based adrenaline are evaluated once from the total health loss.
A naturally critical region touched by the explosion can reduce lucidity, with
its own armor absorption mitigating that loss. Shields do not currently block
radial damage.

Defense percentages, reinforcement, bonuses, durability loss, and shield
behavior remain **Implemented and previously validated**.

## Predefined hostile characters

**Implemented — pending validation**

The final-value table in the 4.0 specification is authoritative:

| Actor | Profile | Attributes F/T/S/M | Mass / size | Armor | Health |
|---|---|---:|---|---|---:|
| Rulo | Beast Man Warrior, male, tall | 20/18/9/3 | 200 kg / 2.40 m | Heavy | 6200 |
| Ronnie | Caelith Mercenary, male, tall | 20/18/5/7 | 140 kg / 2.00 m | Medium | 4340 |
| Argento | Human Battle Mage, male, tall | 9/7/16/18 | 120 kg / 2.00 m | Light | 1740 |
| Caella | Goblin Cleric, female, tall | 9/7/16/18 | 80 kg / 1.60 m | Magic armor | 1160 |

Physical actor attacks apply body mass; magical attacks do not. Caella owns an
independent profile rather than inheriting Argento's combat setup.

## Equipment sizes and Magic Box 4.6

**Implemented — pending validation**

Equipment now records XS, S, M, L, or XL independently for every owned armor
piece and shield. Weight and maximum durability use the size factors 0.50,
0.75, 1.00, 1.25, and 1.50. Compatibility is exact: XS accepts character size
tiers 1–2, S accepts 2–3, M accepts 3–5, L accepts 5–6, and XL accepts 6–7.
Older ownership records and equipped objects migrate to M once.

Shield tier-one weights are magic 4, buckler 8, kite 12, and tower 16. Shields
then use tier factors 1.00/1.50/2.00 before size. The same tier/size weight rule
is centralized for weapons; the sword contributes base weight 6.
Armor retains its documented per-piece weights and applies size only.

The compact equipment interface is the first functional catalogue view:
armor/shield filters, storage location, current and maximum box slots, size
compatibility, three-decimal item weight, equip/remove, development break, and
drop. Pickups remain on the ground only when their weight exceeds capacity and
the box has no free slot. Dropped objects preserve size and durability. The box formula remains
`2 + floor(Type1Percent(Intelligence) / 50)`; Tarot bonuses remain reserved.

Strength carry capacity uses Type 4 multiplied by `BaseMass / 100`. Agility
jump scaling is Type 1.

## Retained validated systems

**Implemented and previously validated**

- Seven vulnerability grades, localized armor, reinforcement, durability, and
  critical damage-only behavior.
- Natural critical-region lucidity loss, armor absorption mitigation, sleep
  multipliers, dizzy accuracy, stun, and pain-animation immobilization.
- Health-state penalties, Patience mitigation, survival penalties, progressive
  health-bar color, evasion, crouch bonuses, jump scaling, and air costs.
- Adrenaline events, enemy-kill and nearby-ally-death gains, and unchanged
  out-of-combat decay.
- Training dummy, sword, staff, shields, ranged actor attacks, four actor sprite
  sets, and six compact debug pages.

## Required 4.0 test pass

1. Build and start GZDoom 4.14.2; confirm ZScript parses without errors.
2. Open creation and traverse all eight pages in both orders for mixed classes.
3. Confirm four family points and thirty individual points remain mandatory.
4. Cycle race, sex, and height; verify mass/size tiers and player collision size.
5. Compare armor type/tier changes with equipped, inventory, debug, and total
   carried weights shown on character page one.
6. Spend and refill Anima; verify HUD, staff cost reduction, and faster casting
   at higher Eloquence.
7. Spawn all four actors and verify dimensions, health, armor, physical damage,
   magical damage, pain, death, and actor debug page values.
8. Re-run the previously validated shield, armor, lucidity, pain, adrenaline,
   movement, jump, survival, and resource controls to catch regressions.
9. Change maps after confirming a character; verify the creator stays closed
   and profile, resources, armor, shield, durability, and owned counts persist.
10. Compare sword/staff push and Rulo/Ronnie projectiles. Both physical and
    magical confirmed hits should push; misses and evasion should not.
11. Assign the equipment and equipment-pickup test controls. Spawn several
    armor/shield combinations, collect them, equip and remove them, then verify
    individual durability and ownership survive save/load and map travel.
12. Trigger explosions at low, middle, lateral, and full-body positions. Verify
    the armor page's touched-region count and independent piece durability.
13. In equipment, cycle XS through XL and verify incompatible sizes cannot be
    equipped for the current character size tier.
14. Check shield weights at M: magic 4/6/8, buckler 8/12/16, kite 12/18/24,
    and tower 16/24/32 for tiers 1/2/3; then verify size multipliers.
15. Collect objects below capacity and confirm they enter personal inventory
    and increase carried weight without consuming box slots.
    Fire the carbine and confirm that each bullet lowers load by 0.003.
16. Exceed capacity and confirm the next object enters the Magic Box without
    increasing load; fill the box and confirm another overweight pickup stays
    on the ground.
17. Cycle to Weapons, spawn sword/staff/carbine variants, collect them, and
    confirm incompatible sizes cannot be equipped.
18. Equip sword, staff, and carbine simultaneously. Confirm that equipping one
    does not unequip the others; use 3/5/6 to activate sword/carbine/staff and
    Fire to confirm their respective air, bullet, and adjusted Anima costs.
19. Compare carbine fire while standing, running, crouching, and Mareado;
    inspect its visible spread and verify the 48-tic firing limit.
20. Break an equipped weapon and confirm it retains weight but cannot attack;
    then drop/recollect an unequipped weapon and verify durability and size.
21. Save/load and change maps with objects equipped, in personal inventory, and
    in the Magic Box; verify location, load, durability, bullets, and counts.

## Not yet implemented

- Final buffs, debuffs, healing abilities, and dialogue consumers for the new
  Eloquence range/Labia values.
- Save migration from profiles created with the legacy three-layer format.
- Remaining weapon families, material catalogue, Tarot, and final visual
  inventory tabs; armor/shield/weapon Magic Box capacity, filters, and core
  item actions are functional.

## Jewelry crafting — 4.23.4

Implemented universal amulets and elemental seals with tier-based weight, attribute bonuses, Jeweler Bench infrastructure, and MAP01 test placement. Raw gems, copper, tin, and coal are registered for future systems and intentionally have no current recipe function.
