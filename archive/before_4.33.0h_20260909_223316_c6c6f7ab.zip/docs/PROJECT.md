# Caelum Argenteum — Proyecto, estado y plan

Versión documental: 4.33.0g — 2026-09-10.

## Estado actual

Base aceptada: **4.33.0f**. El autor confirmó que todas las pruebas de hablar
con los NPC fueron exitosas. El recorrido jugable de MAP01 termina al cerrar
la prueba de Argento en fase 35, con el Diario indicando **Hablar con Caella**.
4.33.0g cambia audio y documentación. La próxima rama narrativa es Caella.

## Premisas permanentes

1. Código, identificadores y README general en inglés; comentarios explicativos
   y documentación de trabajo en español. Fuentes documentales de texto UTF-8;
   mantener formato monoespaciado en las exportaciones de documentación personal.
2. Preferir funciones nativas estables de GZDoom 4.14.2. Mantener una sola fuente
   autoritativa para datos y una arquitectura compartida entre armas y actores.
3. El producto final debe ser independiente: no distribuir assets de Doom.
   Mantener procedencia, atribuciones y modificaciones de los recursos propios
   o externos. Las dependencias de desarrollo no equivalen a autorización de distribución.
4. No inventar valores de balance, recetas, historia ni decisiones pendientes.
   El diseño del autor y sus correcciones posteriores fijan esos datos.
5. Proteger lo ya aceptado y validar sólo lo afectado por una revisión.
   Distinguir análisis estático, prueba aislada del motor y aceptación del autor.
6. Entregar únicamente archivos nuevos/modificados y una aplicación reproducible.
   No incluir IWAD, ejecutables, fixtures de prueba ni un PK3 completo como si
   fuera la base definitiva cuando sólo se dispone de un delta.
7. **Documentación consolidada y actualizada en cada parche.** README.md es la
   entrada general y se revisa con cada entrega. Mantener estos cinco archivos
   de `docs/`; integrar temas nuevos en sus capítulos antes de crear otro archivo.
   Un nuevo documento permanente sólo se justifica si el autor lo requiere.
8. Cada entrega actualiza versión, estado real, decisiones, próximos pasos y
   resultados de pruebas en el mismo cambio. No duplicar el estado entre un
   README por parche y varios informes temáticos. Las instrucciones temporales
   del ZIP quedan fuera de la instalación; las antiguas van al historial.
9. Conservar historia y contenido único. Antes de retirar un documento, integrar
   su información vigente y preservar el original. No eliminar silenciosamente
   archivos locales ni mantener requisitos obsoletos como instrucciones actuales.

## Mapa de documentos

| Archivo | Responsabilidad |
| --- | --- |
| [README.md](../README.md) | Entrada en inglés, instalación y estado resumido. |
| [PROJECT.md](PROJECT.md) | Premisas, estado, plan y validación actual. |
| [SYSTEMS.md](SYSTEMS.md) | Reglas, controles, crafting, economía, Caja y diálogos. |
| [MAP01.txt](MAP01.txt) | Historia y especificación completa, precedidas por el alcance implementado. |
| [ASSETS.md](ASSETS.md) | Audio, arte, primera persona y referencias de atribución. |
| [HISTORY.md](HISTORY.md) | Registro de decisiones y documentos anteriores. |

Los avisos redistributivos de `src/licenses/` permanecen junto a los assets.
No son duplicados administrativos y la reorganización no los elimina.

## Matriz de implementación

| Sistema | Estado real | Próximo trabajo |
| --- | --- | --- |
| Personaje, atributos, recursos, inventario y equipo | Implementados; núcleo aceptado | Continuar contenido y vigilar regresiones sólo si se modifican. |
| Combate físico/distancia/magia, Block y Channel | Implementados | Aplicar la vista de primera persona a las armas restantes. |
| Primera persona de espada/manos/escudo | Referencia 4.32.0o aceptada | Expansión por familias pendiente. |
| Crafting, eficiencia por capa, reparación/desarme | Base aceptada V4.31/V4.32 | Fuentes narrativas y conocimiento inicial de recetas pendientes. |
| Economía, monedas y transacciones | Infraestructura aceptada | Asignar un comerciante canónico posterior. Palomo no comercia en MAP01. |
| Caja Mágica | Almacenamiento y peso aceptados | La entrega canónica final de MAP01 está pendiente. |
| Registro de misiones/facciones/reputación | Base aceptada; progreso por personaje | Consecuencias narrativas y estado cooperativo compartido pendientes. |
| MAP01: despertar, Voz y Palomo | Aceptados | Conservar misterio y presentación. |
| MAP01: Argento, Rulo, Ronnie y Caella en rama social | Aceptados en 4.33.0f | Fase 35 alcanzable, sin reintentos de tirada al reabrir. |
| MAP01: fachada, ascensor y cueva | Aceptados hasta 4.33.0e | Integrar sus usos en las ramas futuras. |
| MAP01: rama mágica de Caella | Pendiente | Acertijo y pasadizo secreto. |
| MAP01: Ronnie, arma y combate final con Toro | Pendiente narrativo | Recolección, arma, entrenamiento y cierre de combate. |
| MAP01: Palomo final, Caja, El Loco y salida narrativa | Pendiente | Recompensas únicas y transición canónica. |
| MAP02 | Campo de pruebas existente | Las alcantarillas de la historia no están implementadas todavía. |
| Audio de interfaz 4.33.0g | Implementado; validación técnica documentada abajo | Escucha del autor en su instalación completa. |
| Clima, calendario, viajes, biomas, asedios y Tarot/Trucazo completos | Diseño o bases parciales | Implementación posterior según el diseño autoral. |
| Cooperativo/PvP | Objetivo de diseño | No presentar las pruebas individuales como validación multijugador. |

## Orden de trabajo

1. Aceptar los cambios de audio 4.33.0g.
2. Caella: rama mágica, acertijo y activación del pasadizo conforme a MAP01.txt.
3. Ronnie: necesidades, recolección y materiales para el arma inicial.
4. Rulo: preparación del combate y victoria contra el Toro.
5. Palomo final: Caja Mágica, El Loco y cierre de la mansión.
6. Construcción narrativa de las alcantarillas, conservando una vía independiente
   para las pruebas de actores. La expansión visual de armas continúa como
   tarea pendiente, sin volver a modificar la espada aprobada por defecto.

## Validación y aceptación

Confirmaciones del autor: 0e completo aprobado; 0f, todas las pruebas de hablar
con los NPC aprobadas. No atribuirle una nueva prueba técnica específica que no
haya descrito. El código de probabilidades conserva exactamente 0f.

Resultados técnicos finales de 0g:

- GZDoom 4.14.2 cargó las definiciones y MAP01. La prueba aislada pasó
  **19 comprobaciones, cero fallos**: duración de diálogo, 14 alias nativos,
  recurso de intro y tres puntos de la probabilidad social (10, 30 y 31).
- El motor informó `caelum/ui/dialogue_open = 1,000000 s`. La portada informó
  como música en reproducción la ruta de `ca_stock_menu_strings_start.ogg`.
  La llamada al sonido local completó sin error de ejecución.
- El OGG conserva 44.100 muestras a 44.100 Hz, dos canales, Vorbis y el fundido
  de salida previsto. Los dos audios originales permanecen idénticos.
- El aplicador se ejecutó realmente en PowerShell 7.6.2 sobre copias aisladas:
  CheckOnly sin cambios; instalación de los 13 archivos; cinco documentos
  activos; preservación íntegra de una nota local desconocida y del mapa;
  reaplicación sin cambios ni otro respaldo; rechazo de una base alterada
  antes de escribir; fallo de copia inyectado después de tres copias y
  restauración exacta de los archivos previos. La sintaxis pasó el parser real.
- Se verifica versión/enlaces de los documentos, inventario de 74 audios,
  integridad ZIP y huellas de los seis archivos de runtime modificados/nuevos.

Límites: GZDoom se probó con una reconstrucción de las fuentes, Freedoom como
IWAD y dos fixtures por dependencias ajenas al delta que faltan en la base
recuperada. No se entregan esos fixtures ni el motor/IWAD; tampoco sustituyen
la instalación completa 0f del autor. OpenAL usó un dispositivo sin salida:
se validaron carga y referencias, no una escucha humana. El aplicador usó
PowerShell en Linux; su ejecución con Windows PowerShell 5.1 queda para la
instalación del autor. El delta no modifica el esquema de guardado.

Prueba pendiente del autor para 0g:

1. Abrir el juego: escuchar la pieza de cuerdas de portada, completa, en bucle.
   Entrar a MAP01: debe recuperarse su música habitual.
2. Abrir el menú por primera vez; navegar, confirmar, volver y cancelar Salir.
   No deben sonar el interruptor ni el disparo/gritos de Doom en estas acciones.
3. Confirmar Salir y probar también el botón Exit físico de MAP01.
4. Abrir conversaciones con Palomo y los residentes: una señal de arpa de un
   segundo por apertura. Pasar páginas/respuestas no debe repetirla. Cerrar y
   volver a iniciar otra conversación sí debe reproducirla.
5. Confirmar que el Diario mantiene el progreso social y que una tirada agotada
   sigue agotada. No es necesario repetir las combinaciones sociales ya aceptadas.

## Mantenimiento y migración

El aplicador verifica todas las huellas antes de cambiar archivos; conserva la
documentación previa y los archivos de runtime que reemplaza en un único ZIP
bajo `archive/`. Después retira de `docs/` los originales respaldados y deja
los cinco archivos canónicos. Un documento local que no estaba en las fuentes
recuperadas también queda preservado en ese ZIP: no se lo declara auditado.
El aplicador no toca mapas, guardados, configuración ni la rama de primera persona.

La verificación reutilizable `tools/validate_project.py` comprueba la versión
documental, la estructura y los destinos de audio. Debe ejecutarse antes de
preparar una entrega; si falla, actualizar los registros antes de cerrar el ZIP.
