# Caelum Argenteum

An independent dark fantasy FPS-RPG inspired by nineteenth-century Argentina.
Author and game designer: **Damian Curti**. Development target: **GZDoom 4.14.2**
on Windows 11. The final product is intended to be independent of Doom assets.

**Current release: 4.33.0g.** Last accepted gameplay base: **4.33.0f**.
Documentation reviewed: 2026-09-10. The author confirmed all NPC conversation
tests successful. Release 0g adds dialogue/menu audio and consolidates documentation.

## Implemented

- Character creation, attributes, resources, inventory, equipment, crafting,
  repair/disassembly, physical currency and merchant infrastructure.
- Physical, ranged and magical combat, contextual Block/ADS, charged attacks
  and equipped-Seal Channel. The accepted sword/hand/shield rig is the reference
  for the remaining first-person weapon work.
- MAP01 mansion, secret facade, physical moving lift and resource cave.
- Native USDF prologue and Palomo encounter, followed by Argento's social task:
  recruit Rulo, Ronnie and Caella, with persistent outcomes and failure alternatives.
  Returning at 3/3 closes phase 35 and directs the player to Caella.
- One-second harp cue when a conversation opens, stock strings as title music,
  and project sounds for native menu and Exit actions in 0g.

## Planned

Caella's magical trial, Ronnie's survival/material trial, initial weapon
preparation, Rulo's combat trial against the Bull, final Palomo encounter,
Magic Box reward, The Fool and the narrative exit. MAP02 currently remains
the actor test field; story sewers are future work. Palomo is a mysterious
guide, and the canonical opening no longer offers commerce or the Magic Box.

The remaining first-person weapons, broader social consequences, shared
cooperative progression, full weather/calendar, travel, sieges and Tarot/TCG
content remain pending according to the author's design.

## Pending validation

The author still needs to listen to 0g in the complete local installation:
title loop, dialogue opening, first menu opening, Quit and the physical Exit
switch. Technical results and their limits are recorded in
[PROJECT.md](docs/PROJECT.md). Compilation alone is not an audible acceptance test.

## Build and run

Apply the source delta to the complete accepted 4.33.0f project using the
included PowerShell applicator. It checks base hashes, preserves previous
documents and replaced files, and installs only the changed/new project files.
Patch instructions stay in the extracted delivery folder.

From the repository root, use the project's existing builder:

```text
python tools/build_pk3.py src build/caelum_argenteum_dev.pk3
```

Retain the existing Windows build helper if using that workflow. Load the
new PK3 after the same development dependencies used for 0f. The delivered
delta does not contain a replacement IWAD, engine or full development base.
Do not package ZIP directory records as graphics or restore obsolete runtime files.

## Documentation and project rules

**Update this README and the five canonical documents with every release.**
Keep implemented, planned and pending-validation status distinct. Integrate
new subjects into existing chapters and preserve superseded information in
the history, instead of creating a permanent document for every patch.

| File | Purpose |
| --- | --- |
| [PROJECT.md](docs/PROJECT.md) | Principles, implementation status, roadmap and current validation. |
| [SYSTEMS.md](docs/SYSTEMS.md) | Current controls, rules, social odds, crafting, economy and storage. |
| [MAP01.txt](docs/MAP01.txt) | Full authorial story/specification and current implementation boundaries. |
| [ASSETS.md](docs/ASSETS.md) | Audio inventory, art and accepted first-person reference. |
| [HISTORY.md](docs/HISTORY.md) | Consolidated previous records and superseded decisions. |

Use English code/identifiers and Spanish explanatory comments. Prefer native
engine features, reusable logic and explicit author-owned balance. Protect
accepted systems, deliver only changed files and report the validation actually
performed. Keep asset provenance and required license notices alongside the assets.

The development build still uses engine/IWAD facilities; the final independent
distribution must not depend on Doom sprites, textures, audio, fonts or maps.
Do not invent missing lore or balance values. Run `python tools/validate_project.py`
before packaging a release to catch inconsistent documentation and missing audio.
