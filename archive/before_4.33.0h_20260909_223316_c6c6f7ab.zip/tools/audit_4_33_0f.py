#!/usr/bin/env python3
"""Audita el delta 4.33.0f o un árbol completo, sin ejecutar ni modificar el juego."""
from pathlib import Path
import argparse
import hashlib
import json
import re


def parse_usdf(text):
    pattern = re.compile(r'\s+|//[^\n]*|/\*.*?\*/|"(?:[^"\\]|\\.)*"|[A-Za-z_][A-Za-z_0-9]*|-?\d+(?:\.\d+)?|[{}=;]', re.S)
    tokens, end = [], 0
    for match in pattern.finditer(text):
        assert match.start() == end, f"USDF no reconocido en {end}"
        end = match.end()
        value = match.group()
        if not value.isspace() and not value.startswith(('//', '/*')):
            tokens.append(value)
    assert end == len(text)
    index = 0

    def body(nested=False):
        nonlocal index
        result = {}
        while index < len(tokens) and tokens[index] != '}':
            key = tokens[index]
            index += 1
            operator = tokens[index]
            index += 1
            if operator == '{':
                result.setdefault(key, []).append(body(True))
            else:
                assert operator == '='
                raw = tokens[index]
                result[key] = json.loads(raw)
                index += 1
                assert tokens[index] == ';'
                index += 1
        if nested:
            assert tokens[index] == '}'
            index += 1
        return result

    result = body()
    assert index == len(tokens)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', nargs='?', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--baseline', type=Path, help='Raíz completa aceptada de 4.33.0e, opcional')
    args = parser.parse_args()
    root = args.root
    manifest = json.loads((root/'PATCH_MANIFEST_4_33_0f.json').read_text())
    for relative, info in manifest['source_files'].items():
        current = root/relative
        assert hashlib.sha256(current.read_bytes()).hexdigest() == info['sha256'], relative
        if args.baseline:
            old = args.baseline/relative
            if info['base_sha256'] is None:
                assert not old.exists(), f'El archivo nuevo ya existe: {relative}'
            else:
                assert hashlib.sha256(old.read_bytes()).hexdigest() == info['base_sha256'], f'Base distinta: {relative}'
    if args.baseline:
        for relative in ('src/CAPALOMO', 'src/LANGUAGE'):
            assert (root/relative).read_bytes().startswith((args.baseline/relative).read_bytes()), relative
        map_path = args.baseline/'src/maps/MAP01.wad'
        assert hashlib.sha256(map_path.read_bytes()).hexdigest() == manifest['accepted_map01_sha256']

    tree = parse_usdf((root/'src/CAPALOMO').read_text())
    assert tree['namespace'] == 'GZDoom'
    conversations = [c for c in tree['conversation'] if c['id'] in range(43310,43314)]
    assert {c['id'] for c in conversations} == set(range(43310,43314))
    assert len(conversations) == 4
    module = (root/'src/caelum/dialogue/CaelumMainM00SocialDialogue.zs').read_text()
    classes = set(re.findall(r'\bclass\s+(\w+)', module))
    references = set()
    page_count = 0
    for conversation in conversations:
        assert conversation['class'] in classes
        pages = {p['pagename']: p for p in conversation['page']}
        assert len(pages) == len(conversation['page'])
        page_count += len(pages)
        for name, page in pages.items():
            assert page['userstring'] == name
            references.update(page[field][1:] for field in ('name','dialog','goodbye'))
            current, visited = name, set()
            while 'link' in pages[current]:
                assert current not in visited, f'Ciclo automático: {name}'
                visited.add(current)
                gate = pages[current]['ifitem'][0]
                assert gate['item'] in classes and gate['amount'] == 1
                current = pages[current]['link']
                assert current in pages
            for choice in page.get('choice', []):
                assert choice['nextpage'] in pages
                assert choice['closedialog'] is False
                references.add(choice['text'][1:])
                if 'giveitem' in choice:
                    assert choice['giveitem'] in classes
                for kind in ('require', 'exclude'):
                    for condition in choice.get(kind, []):
                        assert condition['item'] in classes and condition['amount'] == 1
    assert page_count == 30
    localized = {'default': set(), 'es': set()}
    section = None
    language = (root/'src/LANGUAGE').read_text()
    for line in language.splitlines():
        header = re.match(r'\[([^]]+)\]', line.strip())
        if header:
            section = header[1]
            if 'default' in section.split():
                section = 'default'
        key = re.match(r'(\w+)\s*=', line.strip())
        if key and section in localized:
            localized[section].add(key[1])
    for section, keys in localized.items():
        assert not references-keys, f'Faltan traducciones {section}: {references-keys}'
    new_language = language.split('// V4.33.0f — Argento social branch.',1)[1]
    new_keys = re.findall(r'^(\w+)\s*=', new_language, re.M)
    assert len(new_keys) == 112 and len(set(new_keys)) == 56
    constants = (root/'src/caelum/core/CaelumConstants.zs').read_text()
    assert 'MAIN_M00_RULO_EMOTION_DIFFICULTY = 120.0' in constants
    assert 'MAIN_M00_CAELLA_PERSUASION_DIFFICULTY = 120.0' in constants
    assert 'MAIN_M00_RONNIE_MINIMUM_LABIA = 1.0' in constants
    assert module.index('CanAttemptMainM00SocialCheck(resident)') < module.index('Random[CaelumM00Social]')
    assert 'CalculateType4Percent(attribute)' in module
    assert 'CalculateType2Percent(user.Attributes.Eloquence)' in module
    loader = (root/'src/ZSCRIPT').read_text()
    assert loader.count('#include "caelum/dialogue/CaelumMainM00SocialDialogue.zs"') == 1
    print(f'OK: {len(manifest["source_files"])} archivos de ejecución, 4 conversaciones, {page_count} páginas, 56 claves EN/ES.')
    print('OK: destinos, condiciones, clases, curvas, tirada única y hashes del delta.')


if __name__ == '__main__':
    main()
