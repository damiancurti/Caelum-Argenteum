# Caelum Argenteum — Proyecto, estado y roadmap

Versión documental: 4.33.0i — 2026-09-10.

## Estado actual

**4.33.0f es la base jugable aceptada.** El autor confirmó todas las pruebas
de conversaciones. La prueba de Argento termina en fase 35: el Diario indica
Hablar con Caella. La geometría de MAP01 está aceptada hasta 0e.

**La migración de archivos de 4.33.0h está aceptada por el autor.** Se conserva
la estructura limpia: constructor/verificador en raíz y fuentes/generadores en
assets. Esta aceptación no se extiende automáticamente a pruebas de audio o
contenido nuevo.

**4.33.0i incorpora la prueba mágica de Caella, fases 40–45.** Sigue a Argento:
Fire, AltFire, User2 y gasto/recuperación de Ánima; después, Tierra → Aire →
Fuego → Agua en cuatro runas de la pared existente. Hay pistas a los dos y
cuatro errores, devolución del préstamo y paso a Hablar con Ronnie. La prueba
de supervivencia de Ronnie comienza en el siguiente bloque, no en esta entrega.

Por pedido del autor, War Drums es la música de portada y menu_strings_start
acompaña Salir/Exit. Se mantiene la frase de arpa de 0h por página de diálogo.

## Premisas permanentes

1. Código, identificadores y README general en inglés; comentarios explicativos
   y documentación de trabajo en español. Fuentes documentales de texto UTF-8;
   mantener formato monoespaciado en las exportaciones de documentación personal.
2. Preferir funciones nativas estables de GZDoom 4.14.2. Mantener una sola fuente
   autoritativa para datos y una arquitectura compartida entre armas y actores.
3. El producto final debe ser independiente: no distribuir assets de Doom.
   Mantener procedencia, atribuciones y modificaciones de los recursos propios
   o externos. Las dependencias de desarrollo no equivalen a autorización de distribución.
4. No inventar valores de balance, recetas, historia ni decisiones pendientes.
   El diseño del autor y sus correcciones posteriores fijan esos datos.
5. Proteger lo ya aceptado y validar sólo lo afectado por una revisión.
   Distinguir análisis estático, prueba aislada del motor y aceptación del autor.
6. Entregar únicamente archivos nuevos/modificados y una aplicación reproducible.
   No incluir IWAD, ejecutables, fixtures de prueba ni un PK3 completo como si
   fuera la base definitiva cuando sólo se dispone de un delta.
7. **Documentación consolidada y actualizada en cada parche.** README.md es la
   entrada general y se revisa con cada entrega. Mantener estos cinco archivos
   de `docs/`; integrar temas nuevos en sus capítulos antes de crear otro archivo.
   Un nuevo documento permanente sólo se justifica si el autor lo requiere.
8. Cada entrega actualiza versión, estado real, decisiones, próximos pasos y
   resultados de pruebas en el mismo cambio. No duplicar el estado entre un
   README por parche y varios informes temáticos. Las instrucciones temporales
   del ZIP quedan fuera de la instalación; las antiguas van al historial.
9. Conservar historia y contenido único. Antes de retirar un documento, integrar
   su información vigente y preservar el original. No eliminar silenciosamente
   archivos locales ni mantener requisitos obsoletos como instrucciones actuales.

10. **Carpetas con una responsabilidad clara.** Antes de retirar archivos,
    comprobar consumidores y procedencia. Conservar fuentes útiles en assets,
    empaquetar sólo src y respaldar retiradas conocidas. Los scripts temporales
    de cada entrega no se acumulan en el proyecto activo. V5.0 reorganiza el
    código mediante cambios pequeños con compatibilidad de guardado.

## Mapa de documentos

| Archivo | Responsabilidad |
| --- | --- |
| [README.md](../README.md) | Entrada en inglés, instalación y estado resumido. |
| [PROJECT.md](PROJECT.md) | Premisas, estado, plan y validación actual. |
| [SYSTEMS.md](SYSTEMS.md) | Reglas, controles, crafting, economía, Caja y diálogos. |
| [MAP01.txt](MAP01.txt) | Historia y especificación completa, precedidas por el alcance implementado. |
| [ASSETS.md](ASSETS.md) | Audio, arte, primera persona y referencias de atribución. |
| [HISTORY.md](HISTORY.md) | Registro de decisiones y documentos anteriores. |

Los avisos redistributivos de `src/licenses/` permanecen junto a los assets.
No son duplicados administrativos y la reorganización no los elimina.


## Roadmap inmediato: terminar MAP01

Cada bloque termina con pruebas enfocadas y aceptación del autor antes de
ampliar el siguiente. La numeración de las correcciones intermedias depende
de lo que arrojen esas pruebas; no son plazos de entrega.

| Orden | Bloque | Alcance restante / criterio de cierre |
| --- | --- | --- |
| 0 | 4.33.0h: limpieza | Migración aceptada. Se mantiene la estructura resultante; las nuevas asignaciones de audio se prueban en 0i. |
| 1 | 4.33.0i: Caella, fases 40–45 | Implementada para validación: práctica real, runas, pistas, préstamo y apertura persistente. Usa el acertijo propuesto; presentación/texto final sujetos a revisión del autor. |
| 2 | Ronnie: supervivencia y recolección, fases 50–55 | Necesidades, recursos de la cueva y materiales; objetivos claros y registro persistente. La geometría y los recursos aceptados se reutilizan. |
| 3 | Preparar el arma inicial, fase 60 | Elegir/desbloquear la receta autorizada, entregar materiales exactos y fabricar/equipar el arma; evitar duplicados y bloqueos del tutorial. |
| 4 | Rulo y Toro, fases 70–75 | Entrenamiento, combate y resolución de la prueba conforme al diseño. Mantener las rutas de armas y daño ya aceptadas. |
| 5 | Palomo final, fase 80 | Aparición y ubicación final, cierre de las cuatro ramas y entrega única de la Caja Mágica. Palomo conserva su papel de guía. |
| 6 | El Loco y salida, fases 90–100 | Captura/recompensa única, misión completada y transición narrativa a MAP02; persistencia del personaje y sus objetos. |
| 7 | Alcantarillas de MAP02 | Construir el siguiente mapa narrativo; mantener disponible un campo independiente de diagnóstico de actores. El MAP02 actual todavía es ese campo. |

La verdad autoral y las revelaciones futuras no deben filtrarse a los NPC del
inicio. MAP01.txt contiene la especificación completa y las correcciones que
prevalecen sobre su primera versión.

## Roadmap general por versiones

Esta es la secuencia ya planificada, reconciliada con lo implementado. Los
registros originales siguen completos en HISTORY.md. “Base implementada”
no significa que todo el contenido de ese sistema esté terminado.

| Hito | Estado y trabajo pendiente |
| --- | --- |
| V4.27: controles de combate | Rutas nativas implementadas: Fire/AltFire, Reload contextual, Zoom Block/ADS y User1–4. Completar/registrar la matriz pendiente por familia cuando corresponda; conservar lo aceptado. |
| V4.28: Channel de Sellos | Efectos actuales sin clima aceptados en 0bp. Extensiones dependientes de clima pasan a V5; no reabrir los efectos cerrados. |
| V4.29–V4.31: crafting y ciclo de equipo | Base de recetas, reservas, lotes, eficiencias independientes, reparación y desarme aceptada. Quedan distribución narrativa de conocimiento, recompensas/hojas/tiendas/descubrimientos y bonos de eficiencia todavía sin valores autorizados. |
| V4.31: recursos, botín y contenedores | Fuentes físicas y alijos tienen base; completar tablas de botín por planta/animal/monstruo, contenido/capacidad/propiedad/robo/reposición de contenedores y adquisición sistemática de materiales. La expansión persistente de biomas va en V5. |
| V4.32: NPC, comercio y primera persona | Use/USDF, transacciones, monedas y Caja aceptados. Falta comerciante canónico posterior y contenido de tiendas. Extender la vista modular de espada/manos/escudo 0o a las demás armas con arte propio. |
| V4.33: misiones, reputación y facciones | Registro por personaje aceptado; terminar MAP01, desarrollar misiones secundarias/cadenas y consecuencias jugables de pertenencia/reputación. Los cuatro dominios técnicos actuales no equivalen a las ocho facciones narrativas completas. |
| V4.34: arquitectura del mundo y viajes | Reutilizar módulos de habitación/escalera ya validados; puertas cerradas/con llave y pisos adicionales. Definir ubicaciones, conexiones, caravanas y puntos de integración de viajes/eventos. No confundir arquitectura de mapas con refactor de código. |
| V4.35: calendario, clima y eventos | Calendario/estaciones, duración del día, clima local y planificación de eventos/viajes. Publicar un estado ambiental común de temperatura, viento, precipitación y humedad. El modelo térmico del personaje llega después. |
| V4.36: entorno móvil y peligros físicos | Rocas que ruedan, objetos que caen y superficies peligrosas; luego avalanchas, arietes, catapultas y sectores móviles mediante el núcleo físico. Extraer Impact Physics como paquete independiente sólo tras cerrar su validación en Caelum. |
| V4.37: Tarot y Trucazo | Activación de cartas poseídas/seleccionadas con User3, costes/cooldowns/persistencia y progresión; después contenido de cartas y minijuego Trucazo sobre inventario/NPC/eventos estables. |
| **V5.0: arquitectura modular del código** | Primer bloque de V5, después de cerrar los bloques V4 pendientes. Separar responsabilidades, reducir CaelumPlayer a coordinación y migrar mediante adaptadores pequeños. Una implementación de inventario/jugador/Tarot; autoridad multijugador transversal. Preservar guardados, entradas y selectores. |
| V5.1: exposición térmica | Modelo de calor/frío basado en clima, zonas, actividad, humedad persistente, viento y equipo real; Resiliencia, consumibles, refugios, secado, descanso y aclimatación. Curvas numéricas pendientes de balance autoral. |
| V5.x: recursos y biomas marinos | Fuentes 3D persistentes, extracción cuerpo a cuerpo cortante/perforante, dureza/rareza/profundidad/región/habilidad, agotamiento y regeneración. Biomas marinos, algas/yodo y aguas no potables; tiendas mantienen acceso a materiales remotos. |

### Todo el alcance transversal pendiente

Estos compromisos no desaparecen por carecer de un número de parche. Su
implementación se ubica cuando estén disponibles sus dependencias.

| Área | Alcance planificado y límites actuales |
| --- | --- |
| Campaña y mundo | Objetivo de 78 cartas (22 Mayores y 56 Menores) y al menos 78 mapas; geografía inspirada en Argentina, costas/Antártida/mar profundo, ciudades aéreas y regiones sobrenaturales. Capítulos, encuentros, desenlaces políticos y revelaciones según canon. La primera entrega sigue concentrada en MAP01. |
| Misiones | Principales/secundarias, requisitos, objetivos, cadenas/dependencias, fracaso y abandono; recompensas de objetos/dinero/reputación/desbloqueos. El registro actual tiene 32 slots, ocho objetivos y cuatro estados; abandono y contenido amplio requieren ampliación. Mayores para principales, Menores para secundarias; encargos/eventos/rumores/contratos no son automáticamente otra carta. No introducir XP por combatir: la progresión canónica depende del Tarot. |
| Facciones y secreto | La Capital, Pueblos Libres, Nativos, Caelith Puros, Híbridos, Gendarmería, Culto del Tarot e Infierno. Siete rangos de reputación, relaciones cambiantes y consecuencias en precios, acceso, misiones, hostilidad y asedios; pertenencia/secreto del Culto como contenido futuro. |
| Diálogo social | Reputación aplicada a las tiradas y umbrales, emociones privadas, interrupción por combate/eventos y conversaciones con varios NPC en secuencia. MAP01 sólo usa los valores aprobados para su tutorial; no asignar facciones ni dificultad nuevas por defecto. |
| Viajes | Carreta, barco, submarino arcaico, aeronave, nave mágica y portales; encuentros, ataques, tormentas y fallos mecánicos. Tiempo global, localizaciones, rutas y cambios permanentes del mundo son dependencias. |
| Supervivencia y descanso | Acción Descansar con alimentos/bebidas y avance temporal; campamentos/propiedades/refugios, recuperación y calidad del descanso. Integrar exposición térmica; límites de oxígeno, altura, agua y futuras capacidades de respiración según las cartas. |
| Agua y simulación fuera de mapa | Extender marcadores de potabilidad a aguas marinas/contaminadas; red de volúmenes a niveles distintos es capacidad técnica aún no construida. Definir compensación de recursos/clima/eventos al volver a mapas descargados mediante calendario global. |
| Percepción y sigilo | PerceptionCore, sensores visuales/acústicos, sigilo, detección/pérdida/reencuentro/memoria y comunicación compartida. El diagnóstico de grupos/percepción no es la IA final; resolver campos de visión, fórmulas angulares, estados/tiempos, ruido por acción/superficie/cadencia y derivación de sigilo antes de asignar valores. |
| Grupos y acompañantes | Formación jugable, pertenencia dinámica, líderes de movimiento, offsets locales, sueño por distancia y memoria compartida. NPC de relleno para party incompleta: acompañar/combatir sin decidir diálogos. La base diagnóstica de grupo 16 no impone tamaño fijo a la formación visual. |
| IA masiva y rendimiento | Mantener presupuesto escalonado de percepción/objetivos y filtros espaciales; resolver locomoción compartida, contactos y pruebas graduales de 1.875 → 3.750 → 7.500 → 15.000 activos según el último gate aprobado. Cargar 15.000 actores pasivos no prueba 15.000 IA completas. |
| Asedios | Director de batalla, refuerzos, tácticas, comandantes, aliados, máquinas/artillería/barricadas, sabotaje y rutas alternativas; límite temporal y consecuencias permanentes sobre ciudades, rutas y facciones. Depende de IA, física, mundo y calendario estables. |
| Física | Completar validación de impactos/contactos múltiples, empuje sostenido, aplastamiento y anatomía/armadura. La futura física de golpes cuerpo a cuerpo requiere velocidad, masa efectiva, área/filo, material, penetración y técnica definidos; no reemplazar el combate aceptado sin ese diseño. |
| Habilidades | Efectos concretos de User1 racial y User4 clase, definidos raza por raza y clase por clase. User2 conserva Sellos; User3 conserva Tarot. No inventar poderes ni valores para llenar los hooks existentes. |
| Tarot | Colección, posesión, selección, activación, bonificaciones y despertar de armas de esencia; cartas con efectos de exploración, respiración y Caja según diseño. Completar las 78, sus misiones y persistencia; no confundir un hook con poderes terminados. |
| Trucazo | Truco con Tarot: Mayores modificadores, Menores jugables/filas, Envido/Truco/Retruco/Vale 4, daño y vida, Sentidos Mágicos, apuestas y consecuencias; casual/ranked y equipos 1v1 a 4v4. Implementar por capas tras reglas base de Tarot y autoridad multijugador. |
| Cooperativo y PvP | Objetivo 2–8 jugadores, autoridad del anfitrión, propiedad/validación/sincronización, misiones y mundo compartidos, viajes, conexión/desconexión y compañeros. La persistencia individual actual no acredita estos modos. |
| Guardado | Mantener guardado nativo e Inventory viajero. Perfil externo independiente, autoguardado narrativo y estado compartido del mundo permanecen pendientes; ensayar compatibilidad antes de retirar adaptadores de V5. |
| Arte, audio e interfaz | Vistas de primera persona restantes, contenido visual de mapas, efectos/emisores por región/hora/clima y adaptación de stock a escenas. Conservar tipografía, iconos y rig aceptados; actualizar inventario y créditos con cada recurso. |
| Distribución independiente | Sustituir toda dependencia final de arte/audio/fuentes/mapas de Doom, completar atribuciones y empaquetado propio, validar arranque/guardado/mapas y modos de juego. El IWAD de desarrollo no entra en los parches. |

### Decisiones que todavía requieren diseño del autor

Balance completo de cartas, habilidades raciales/de clase, economía y recursos;
tablas/reglas de cosecha y botín; contenido y propiedad de contenedores; fuentes
definitivas de recetas/componentes; sensores y sigilo finales; clima regional,
encuentros y consecuencias de facciones; valores térmicos y física cuerpo a
cuerpo. Los documentos históricos contienen propuestas: se comprueba su
vigencia antes de implementarlas. La progresión ya aceptada no se reabre.

## Auditoría de carpetas 4.33.0h

Base: ZIP completo aportado por el autor, 16.626 entradas. Se verificaron CRC,
rutas, inventario y consumidores. La limpieza usa una lista explícita con
SHA-256 por archivo; “no aparece como texto” no alcanza para eliminar un
sprite, fuente, modelo o recurso que el motor resuelve por convención.

| Carpeta / entrada | Archivos de la base | Decisión y motivo |
| --- | ---: | --- |
| Raíz | 4 | README actualizado; build_dev.ps1 pasa a ser el único constructor Windows; run_dev apunta a él; se conserva la configuración del proyecto. validate_project.py se traslada aquí. |
| docs | 5 | Mantener los cinco documentos canónicos, integrar roadmap/auditoría y corregir el estado real de 0g. |
| tools | 74 | Retirar la carpeta activa: conservar constructor/verificador en raíz y tres generadores en assets. Los otros 69 archivos son utilidades de revisiones anteriores o constructores redundantes, preservados en el respaldo. |
| art_source | 20 | Trasladar todos los originales y registros a assets/source/art con las mismas huellas. |
| assets | 13 | Conservar atlas fuente y paquete 05 con README/checksums; añadir arte fuente y generadores. No se empaqueta en runtime. |
| src | 4.276 | Mantener recursos y módulos útiles; sólo se aplican correcciones de audio y créditos, más el observador de portada. La arquitectura del código se reorganiza en V5. |
| build | 1 | PK3 regenerable: reconstruirlo al aplicar. Se conserva el anterior hasta completar el reemplazo atómico; no acumular copias de 77 MB como fuentes. |
| archive | 1 | Conservar el respaldo de 0g y añadir un único respaldo verificado previo a 0h. Los registros históricos tienen utilidad de recuperación. |
| Historial Git | 11.803 | Conservar íntegro: contiene la historia de versiones, no archivos temporales de la entrega. |

Detalle de todos los directorios inmediatos de src, antes del parche:

| Entrada de src | Archivos | Utilidad comprobada / decisión |
| --- | ---: | --- |
| Lumps de raíz | 13 | ZSCRIPT, MAPINFO, SNDINFO, menús, USDF, textos y registros nativos: conservar y ajustar referencias de audio. |
| caelum | 59 | Módulos de gameplay y UI enlazados desde ZSCRIPT; añadir un observador UI, sin dividir/reubicar los módulos existentes. |
| impactphysics | 1 | Núcleo físico incluido por ZSCRIPT; conservar. |
| crafting | 1 | Catálogo de recetas cargado por el sistema; conservar. |
| maps | 2 | MAP01 y campo de pruebas MAP02; hashes invariantes. |
| graphics | 556 | UI, iconos/texturas y registros de gráficos; conservar contenido y convenciones del motor. |
| hires | 1 | Recurso gráfico de alta resolución del proyecto; conservar. |
| sprites | 1.129 | Estados de actores/armas y sprites base de modelos; conservar, incluidos marcadores transparentes necesarios. |
| models | 155 | Geometrías/texturas/modelos enlazados por MODELDEF; conservar. |
| fonts | 2.280 | Glifos y conjuntos tipográficos; su resolución es nativa, no una referencia textual por carácter. Conservar. |
| sounds | 72 | Audio usado y reserva registrada; sustituir únicamente la frase derivada. |
| music | 2 | Música propia de MAP01/MAP02; conservar. |
| licenses | 5 | Avisos redistributivos necesarios, distintos de documentación administrativa; actualizar la modificación del arpa y las rutas de los generadores visuales. |

No se encontró basura temporal inequívoca adicional dentro de src. Los recursos
reservados para contenido futuro no se declaran inútiles. El manifiesto del
aplicador especifica cada retiro/traslado; archivos locales desconocidos se
conservan. Un archivo auditado que cambió desde el ZIP detiene la aplicación
antes de escribir y se informa con su ruta.

## Aplicación y mantenimiento

Extraer el parche fuera del proyecto y ejecutar APLICAR_4_33_0i.cmd, indicando
la carpeta completa 0h ya migrada. Comprueba hashes, conserva un respaldo
verificado en archive, aplica el delta y reconstruye el PK3 con build_dev.ps1.
No vuelve a migrar carpetas. Si una copia o el build fallan, restaura los
archivos originales. Reaplicar una instalación completa no crea otro respaldo.

run_dev.bat conserva las rutas del motor/IWAD del autor. El aplicador y las
instrucciones quedan fuera de la instalación. Los cinco docs y README se
actualizan juntos; el historial conserva la validación anterior de 0h.

## Alcance y decisiones de Caella 4.33.0i

- Usa el texto y el orden elemental ya propuestos en MAP01.txt. Los emblemas
  existentes de Sellos son una presentación jugable para revisar; no se declara
  aprobada una nueva ilustración ni el texto final pendiente del autor.
- Reutiliza la abertura de 96 MU: X=1842, Y=-383 a -287, planta baja. Las cuatro
  runas están delante, en X=1826, Z=38. Al empezar la prueba, la textura central
  adquiere la misma colisión por altura que el resto de la fachada. Al terminar
  desaparece en sus dos caras. El WAD y el ascensor aceptados conservan su hash.
- Una partida anterior que ya esté dentro de la cueva puede regresar: el cierre
  sólo se activa al comenzar la prueba con Caella. Recorrer la cueva antes no
  completa la misión. La Llave de Plata y su destino siguen pendientes.
- Se mantienen Fire/AltFire y el Channel nativo en User2. Channel consume
  Adrenalina; se corrige la referencia antigua a Reload. Para su primera
  demostración se prepara, al activar User2, como máximo la reserva equivalente
  a un segundo del coste nativo del Sello, limitada por el máximo del personaje.
  Después de registrar un tic real de consumo no se vuelve a conceder esa ayuda.
  No cambian costes generales, efectos, cooldown ni estadísticas.
- La práctica observa cinco hechos: primario, secundario, canalización, gasto y
  recuperación de Ánima. Sólo un lanzamiento completado cuenta; fallar por
  falta de recurso o cancelarlo no cuenta. Las cuatro runas usan Usar con un
  implemento mágico activo: el elemento propio de la runa resuena a través de
  él. No se cambia la esencia ni se exige disponer de cuatro armas diferentes.
- Si falta equipo compatible, se prestan instancias T1 del catálogo existente,
  con ItemId único y CA_ITEMFLAG_LIMBO_TEMP. Reabrir/preparar no duplica objetos;
  un préstamo roto se repone en la misma instancia. No puede venderse, soltarse,
  desarmarse ni guardarse en la Caja. Se devuelve al completar Caella o salir de
  MAP01. El equipo propio se conserva; se recupera el arma anterior si procede.
- El Diario resume 5 acciones + 4 runas, 0/9–9/9. Un error reinicia sólo las
  runas; conserva práctica, errores e identidad del equipo. Hints a los 2 y 4
  errores. Finalizar lleva a fase 45 y Hablar con Ronnie, con cierre único.
- El progreso vive en CaelumPersistentCharacterState; se añaden campos y se
  usan flags libres 57–58 sin desplazar los existentes. Los actores y la pared
  reconstruyen su presentación desde ese registro. La validación es individual;
  no acredita todavía el cooperativo planificado para 2–8 jugadores.

## Validación de 4.33.0i

- GZDoom 4.14.2 cargó el runtime completo de 4.278 archivos sin errores ni
  advertencias nuevas. La prueba de Caella pasó 52 comprobaciones: inicio USDF,
  préstamos e identidad, acciones inválidas/canceladas, lanzamientos reales,
  Ánima, canalización, pistas, secuencia, devolución, Diario y apertura única.
- Una segunda prueba ejercitó el recorrido nativo de Usar, no sólo la llamada
  directa al actor. Detectó y corrigió la activación de las runas. Tras guardar
  con dos runas, se activó la tercera, se cargó y se recuperaron índice 2,
  fase 40 y ambos ItemId. Después se activaron Fuego/Agua con Usar, se guardó
  y cargó la fase 45: índice 4, pared abierta y préstamos ausentes. La matriz
  de ese recorrido terminó con 46 comprobaciones y cero fallos. Se inspeccionó
  la imagen del guardado antes y después de abrir: runas visibles y abertura real.
- Compatibilidad: se creó un guardado real con el runtime 0h en fase 35,
  se actualizó esa misma instalación a 0i y se cargó el archivo anterior.
  Conservó Argento 3/3 y fase 35; los nuevos campos empezaron en cero. Caella
  inició fase 40 y asignó ItemId diferentes a ambos préstamos. No hace falta
  reiniciar MAP01 para esta ampliación.
- Audio: 20 comprobaciones de alias/duraciones y reglas sociales conservadas.
  El motor informó War Drums en bucle con manejador activo en los ticks UI 50,
  250 y 500. La captura OpenAL de 21,65 s mantuvo señal en los tres tramos
  0–6, 6–12 y 12–18 s. MAP01 conservó CA_MUS01 en bucle. Los originales de
  War Drums, menu_strings_start y la frase de arpa conservaron sus hashes.
- Aplicador con PowerShell 7.6.2: 12 comprobaciones, cero fallos. CheckOnly,
  ruta con espacios/paréntesis, delta completo, mapas/audio conservados,
  archivo local desconocido, PK3 idéntico a src, respaldo verificado,
  reaplicación, rechazo de conflicto y dos restauraciones exactas ante fallo
  de copia o build. No cambia el aplicador transaccional validado salvo versión
  y mensajes; el manifiesto no contiene retiros ni traslados.
- Se mantienen README y cinco docs, sin enlaces de páginas USDF ni claves de
  localización nuevas ausentes. La revisión final pasa validate_project.py.

Las pruebas usan GZDoom 4.14.2 y Freedoom como dependencia de desarrollo,
no incluidos en el ZIP. Los observadores y guardados de prueba tampoco se
entregan. La salida gráfica y el audio se verificaron en un motor aislado;
quedan la valoración del autor y la ejecución del CMD/PowerShell 5.1 en Windows.

Pruebas breves del autor:

1. Aplicar el CMD sobre 0h; iniciar y esperar más de doce segundos en la portada:
   War Drums debe seguir sonando. Probar Salir/Exit con menu_strings_start.
2. Desde Argento terminado (fase 35), hablar con Caella. Leer sus instrucciones,
   probar Fire y AltFire hasta completar cada lanzamiento y usar User2. Observar
   gasto y recuperación de Ánima; confirmar práctica 5/5 con Caella.
3. Ir a las cuatro runas del extremo este, lado sur de la planta baja. Con el
   implemento activo, usar una secuencia incorrecta dos y cuatro veces; revisar
   las pistas. Guardar con Tierra y Aire activadas, cargar y terminar con Fuego
   y Agua. La pared debe desaparecer y el préstamo devolverse una sola vez.
4. Guardar/cargar después de abrir: el pasadizo continúa abierto, el Diario
   indica 9/9 y Hablar con Ronnie. Recorrer ascensor/cueva; confirmar que se
   conservan el equipo propio y los resultados de Argento. La tarea de recursos
   de Ronnie queda para el siguiente bloque.
